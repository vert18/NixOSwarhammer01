# Zoolander

Zoolander is a Wayland compositor built on the sibling
[`zooland`](../zooland) library. It supports nested, headless, and DRM
backends, rootless Xwayland, Lua configuration, a native overview, spatial
window layouts, server-side decorations, and a local control socket.

This repository is developed as part of the `zoo` workspace. The `zooland`
dependency is a relative path in `otr/otr.toml`.

## Build

Zoolander is written in Otr. `otr/` holds the compositor package, with its
entry point in `otr/native_main.otr`; `otr/svg/` is its SVG icon decoder
package and `otr/tests/` a separate package of integration checks. The
library is `../zooland/otr`. The build needs otr 0.2.2 or newer and a pinned
static LuaJIT. Fetch LuaJIT before the first build, then build from
`otr-out/`, where the compiler caches stay ignored:

```sh
./vendor/fetch-luajit.sh
mkdir -p otr-out && cd otr-out
otr build ../otr/native_main.otr --release --cpu baseline \
    -rpath '$ORIGIN/../lib/zoolander' -o zoolander
otr build ../otr/bell_player.otr ../otr/bell_audio_ffi.c --release --cpu baseline \
    --lib shared --pkg-config libpipewire-0.3 -I ../otr -o libzoolander_bell.so
otr build ../otr/audio_visualizer/capture_lib.otr ../otr/bell_audio_ffi.c ../otr/audio_visualizer/capture_ffi.c --release --cpu baseline \
    --lib shared --pkg-config libpipewire-0.3 -I ../otr -o libzoolander_audio_visualizer.so
```

The executable is `otr-out/zoolander`. `tests/run.sh` runs every test of
zooland and zoolander: each Otr file with `test` blocks through `otr test`, the
generated-code check, and the wire and E2E scripts against fresh compositors.
Anything that starts a compositor or touches DRM, the GPU or a seat runs only in
the test VM: `tests/run.sh --vm` copies both repositories there and runs it all,
`tests/run.sh --unit` runs the rest here. `otr/tests/rig.otr` starts the
production root on the headless backend for in-process E2E tests.

`otr/otr.toml` links `gcc_s`, `drm`, `gbm`, `input`, `seat`, `udev`, `xcb`,
`xcb-xfixes`, `xcb-composite`, `xcb-sync` and `xcb-res`, and takes FreeType, HarfBuzz,
fontconfig, FriBidi, gdk-pixbuf, cairo and xkbcommon from pkg-config. The DRM
path loads `libvulkan.so.1` and needs a Vulkan 1.3 driver for the display's
GPU (radv, NVIDIA 515 or newer, or another driver with dma-buf and
DRM-modifier support). Without one, DRM renders in software.

Titles are shaped with FreeType, HarfBuzz and FriBidi using fonts found
through fontconfig. Named window icons are decoded by `otr/svg` for SVG, by
Zoolander itself for XPM, and by gdk-pixbuf for other formats. The bell is
synthesized in Zoolander and played through PipeWire by
`lib/zoolander/libzoolander_bell.so`, which Zoolander loads on the first
ring, so the bell needs only a running PipeWire server. Without one, or
without that library, Zoolander logs a warning and carries on.

Xwayland is optional. Zoolander tries
`/usr/local/libexec/zoolander/Xwayland`, then `/usr/bin/Xwayland`. It continues
without Xwayland if neither path works. The X display listens from startup,
and Xwayland itself starts when the first X11 client connects to it. It
exits 10 seconds after the last X11 client leaves, and the next X11 client
starts it again. `zl.set_xwayland({ enabled = false })` turns X11 support
off: no X display, and no `DISPLAY` for children.

### Source layout

`otr/comp.otr` builds the root type. Its `hooks` set implements zooland's typed hook areas,
and its table of `pub const` bindings is the root's method surface: feature modules call one
another through the root (`H.window_output(c, id)`) instead of importing each other. The
features live in folders: `backend/`, `capture/`, `color/`, `config/`, `frame/`, `gtk_shell/`, `input/`,
`layer_shell/`, `layout/`, `lua/`, `output/`, `overview/`, `presentation/`, `session/`, `shell/`,
`surface/`, `window/`, `wm/`, `workspace/` and `xwayland/`. A folder's main module may sit
beside it, as `wm.otr` does beside `wm/`. `core_access.otr` is the only path into
zooland's core store.

## Install

`./install-system.sh` builds the Otr compositor, bell library and audio
visualizer library as the invoking user, then uses `sudo` to install `zoolander`,
`lib/zoolander/libzoolander_bell.so`,
`lib/zoolander/libzoolander_audio_visualizer.so`, `zoolanderctl`, `zoolander.desktop`, and
`zoolander-portals.conf` under `/usr/local`. Set `OTR` to use a compiler other
than the `otr` on the path.

Set `DESTDIR` to stage the same installation without `sudo` or system writes:

```sh
DESTDIR="$PWD/stage" ./install-system.sh
```

The staged executable is `stage/usr/local/bin/zoolander`; the bell and audio
visualizer libraries are under `stage/usr/local/lib/zoolander`.

`debian/` builds the same files as the `zoolander` Debian package, under
`/usr` instead of `/usr/local`. `main.sh` is the PikaOS build: it clones the
matching `zooland` tag next to this checkout, fetches LuaJIT and runs
`dpkg-buildpackage`, leaving the package in `output/`. With `zooland` already
beside the checkout and LuaJIT fetched, `dpkg-buildpackage -us -uc -b` builds
it directly.

## Run

```text
Usage: zoolander [OPTIONS] [--spawn CMD [ARGS...]]

Options:
  -h, --help              Show this help and exit
  --headless             Use the headless backend
  --headless-size=WxH    Set the first headless output size (default 64x48)
  --headless-size2=WxH   Add a second headless output
  --drm[=DEVICE]         Use an auto-picked or explicit DRM device; repeated, the
                         later devices only drive their own connectors
  --drm-list             List DRM candidates and exit
  --config=PATH          Load this Lua config
  --spawn CMD [ARGS...]  Start a client; consumes the remaining arguments
```

DRM renders with Vulkan on the GPU that drives the chosen display. Without
`--drm=`, the connectors of every other real GPU are driven too: their outputs
show what the chosen GPU renders, with what changed copied across each frame, so a laptop's
external ports work when they are wired to its second GPU. On NVIDIA the proprietary driver needs `nvidia-drm` with
`modeset=1`. If no scanout modifier is shared by the plane and the driver,
what changed in each frame is copied on the GPU into another buffer of the
display's device, and read back on the CPU only when the driver imports none
of them; the log line `scanout path:` at start says which.

On a laptop with two GPUs the one behind the built-in screen renders, which
is the integrated one. `zl.set_render_gpu("discrete")` in the config makes
the other GPU render from the next start: it has its own cooling, so the
processor runs cooler under load, and it draws more power. `"integrated"` and
`"auto"` (the default) are the other values. An explicit `--drm=DEVICE`
overrides it, and a GPU that drives no connector is never picked.

When DRM renders in software, Zoolander leaves out blur, animations and window
shadows whatever the config says, and `ext-background-effect-v1` offers no
blur: on the CPU a single blurred window costs more per cursor move than a
frame lasts. `zoolanderctl status` shows which renderer is in use.

`--headless` takes precedence over DRM options. An explicit `--drm` request
does not fall back if it fails. Without a backend option, Zoolander uses a
nested backend when `WAYLAND_DISPLAY` is set, otherwise it tries DRM and then
falls back to headless.
When a PCI display device has no DRM card yet and udev is still handling
devices, as early in boot, it first waits up to ten seconds for that GPU.

`--headless-size` and `--headless-size2` accept positive dimensions up to
2147483647. The first headless output defaults to 64x48. `--spawn` accepts the
command plus at most 15 arguments and must be last because it consumes the
rest of the command line.

Examples:

```sh
otr-out/zoolander --headless --headless-size=1280x720
otr-out/zoolander --headless --spawn foot
otr-out/zoolander --drm-list
otr-out/zoolander --drm=/dev/dri/card1
```

Two options print JSON for a settings app and exit without starting a backend,
socket, Xwayland or any child process. `--config-schema` lists every config
setter with its keys, kinds, ranges, enum values and defaults, and in
`starter_dir` the installed starter config directory (null without one).
`--describe-config` (with `--config=PATH` or the default config) runs the
config as the first load does, then its `startup` handlers, and lists each `zl`
call with its arguments, the config lines that made it and, for binds, the
resolved binding; `zl.exec_command` in a handler is recorded and not run. It
exits 0 when the config fails too and reports the error with its file and line.

```sh
otr-out/zoolander --config-schema
otr-out/zoolander --describe-config --config=$HOME/.config/zoolander/init.lua
```

Do not run the DRM backend against a device used by a live desktop session.
Hardware and nested-compositor testing belongs in the project VM.

## Configuration

The default config is `$XDG_CONFIG_HOME/zoolander/init.lua` when
`XDG_CONFIG_HOME` is an absolute path, otherwise
`$HOME/.config/zoolander/init.lua`. Use `--config=PATH` to select another
file.

Zoolander ships a starter config in `share/zoolander/config` below its
install prefix (`/usr/share/zoolander/config` for the package,
`/usr/local/share/zoolander/config` for `install-system.sh`; the repository's
copy is [`config/starter`](config/starter)). It is split into `init.lua`,
`monitors.lua`, `keybinds.lua`, `windows.lua` and `exec.lua`, and comments
every area with examples: layouts, input, looks, animations, outputs and HDR,
bindings, window and layer rules, and startup programs. It loads the shell
profile fragments `shell/keybinds.lua`, `shell/windows.lua` and
`shell/exec.lua` that pika-shell-profiles installs, when they are there, and
starts Otter's wallpaper and bar itself when no profile starts programs.

On first start, when no `--config` is given and the default `init.lua` does
not exist, Zoolander copies every starter file its config directory lacks into
it, logs each file it copied, and loads the copy. It never replaces an
existing file, so a directory holding some of your own files keeps them. If
nothing can be written there, such as with a read-only home, it loads the
starter from where it is installed. If the config that loads is invalid,
Zoolander logs the error and loads an emergency config with basic launch,
close, fullscreen, workspace, and quit bindings. A build run from the source
tree has no starter; try it with `--config=config/starter/init.lua`.

A small config:

```lua
zl.set_keyboard({
    repeat_rate = 30,
    repeat_delay = 400,
    layout = "gb",
})

zl.set_layout("dwindle", 0.6, 1)
zl.set_window_style({
    gaps_in = 4,
    gaps_out = 8,
    border_size = 2,
    active_border = "#7aa2f7",
    inactive_border = "#414868",
})

zl.bind(zl.MOD_LOGO, zl.KEY_RETURN, function()
    return zl.exec_command("foot")
end)

zl.bind(zl.MOD_LOGO + zl.MOD_SHIFT, "q", function()
    return zl.close_window()
end)

zl.on("startup", function()
    zl.exec_command("my-status-bar")
end)
```

See [Lua API](docs/LUA-API.md) for every `zl` function and constant. See
[Spatial window layouts](docs/WINDOW-LAYOUTS.md) for Canvas, Side Shelves,
Islands, Lanes, Accordion, Workbench, Pairs, and Anchors. The repository's
[`config/ferreo`](config/ferreo) profile is a complete multi-file example for
one desktop setup. It is not a built-in profile or a portable default.

Compositor keybindings run before an input-method keyboard grab. A matching
press is consumed with its release, and Escape can still cancel an active
compositor move or resize while an input method holds the keyboard.

Input methods can use input-method v2 (fcitx5, IBus) or input-method v1
(maliit, weston-keyboard). Either serves applications using text-input v1,
v2 or v3, one input method per seat. An input-method v1 keyboard panel is
drawn at the bottom centre of its output while a text field is active, and an
overlay panel at the text cursor. A keysym that keyboard sends to a text-input
v3 application is pressed as the key that types it in the current keymap.

A browser can tear a tab out into a new window during a drag
(xdg-toplevel-drag). The window follows the pointer, is never the drop
target, and stays floating where the drag ends. Applications using
xdg-session-management get their windows' output, workspace, floating rect
and maximized or fullscreen state back after a restart. A newly launched
application keeps the current workspace. The state lives in
`$XDG_STATE_HOME/zoolander/sessions`, one file per session.

### Reload and modules

Zoolander watches the config directory. Saving `init.lua` or a sibling
`.lua` file builds a candidate runtime and replaces the live runtime only if
the whole config succeeds. A failed reload leaves the previous config active.
Modules in subdirectories load normally, but edits below a subdirectory need
an explicit `zoolanderctl reload` because the inotify watch is not recursive.

Config `require` accepts names made from letters, digits, `_`, `-`, and dots.
Dots map to directories. It resolves `name.lua` or `name/init.lua` beneath the
canonical config directory, loads text only, and caches the returned value for
the current runtime. Paths that escape the config directory are rejected.

LuaJIT opens the base, table, string, math, and bit libraries. It removes
`dofile`, `loadfile`, `load`, and `loadstring`, and does not open `io`, `os`,
`package`, `debug`, `jit`, or `ffi`. This limits accidental access from config
code. It is not a process sandbox: `zl.exec_command(command)` deliberately
runs `/bin/sh -c command`, and `zl.set_env` changes the environment of clients
spawned later.

Compositor actions such as `zl.workspace`, `zl.close_window`, and
`zl.exec_command` have no live host during the first top-level config pass.
They return false or do nothing and emit one warning. A reload candidate does
have the live host, so a top-level action runs during each reload attempt that
reaches it, even when a later statement makes the reload fail. Put actions
with side effects in `zl.on("startup", function() ... end)` or a binding.
Config setters belong at top level and are applied transactionally on reload.

## Rules and themes

Window and layer rule patterns are either exact names or anchored forms such
as `^(steam_app_.*)$`. Inside `^(...)$`, `.*` is the only wildcard and `\`
escapes one character. Other regular-expression syntax is rejected. An
unanchored string is always exact; if it looks like a regular expression,
Zoolander accepts it but logs that it will only match literally.

Window rules match a window's app id, title, or the tag a Wayland client sets
through xdg-toplevel-tag, and run again when any of them changes. Every
matching window rule contributes actions. Later matches replace
single-valued actions such as workspace, content type, border size, rounding,
shadow, and decoration. Boolean actions accumulate. Repeating a window rule
adds another rule. Layer rule calls with the same pattern merge into the
first record; later matching patterns win for blur thresholds and animation
styles, while `no_animation` applies if any matching rule enables it.
Environment and workspace-layout entries replace an earlier entry of the same
name. Duplicate output rules are errors.

Color fields accept `#RGB`, `#RGBA`, `#RRGGBB`, or `#RRGGBBAA`. Underscores
may separate hex digits.

When `zl.set_ssd({ follow_theme = true })` is active, Zoolander watches the
Otter theme selected by `$XDG_CONFIG_HOME/otter-shell/theme.conf` or
`$HOME/.config/otter-shell/theme.conf`, with `/etc/otter-shell/theme.conf` as
the system fallback. Its color, layout, and spacing files supply decoration
colors, font, density, and button order. Explicit `set_window_style` border
fields override theme or `set_ssd` border fields. Explicit SSD title fields
apply when theme following is disabled.

## Environment

These variables affect startup or runtime behavior:

| Variable | Use |
| --- | --- |
| `XDG_CONFIG_HOME`, `HOME` | Config path, Otter theme, icons, and cursor search roots. |
| `XDG_RUNTIME_DIR` | Wayland, Xauthority, and control socket files. Without it, the control socket is disabled. |
| `WAYLAND_DISPLAY` | Selects the nested backend when no backend flag is given. Spawned clients receive Zoolander's socket instead. |
| `XDG_SEAT` | DRM seat name; defaults to `seat0`. |
| `XCURSOR_THEME`, `XCURSOR_SIZE`, `XCURSOR_PATH` | Cursor lookup. Values set with `zl.set_env` take precedence for compositor cursor loading and spawned clients. |
| `XDG_DATA_HOME`, `XDG_DATA_DIRS` | Icon and cursor theme search roots. |
| `ZL_ICON_THEME` | Named window icon theme override. |
| `ZOOLAND_VK_VALIDATION` | `1` loads the Khronos Vulkan validation layer, if installed. |
| `ZOOLAND_VK_TIMING` | `1` logs GPU time and frame counters once a second. |

Clients started by `--spawn` and `zl.exec_command` receive Zoolander's
`WAYLAND_DISPLAY` and, when Xwayland is available, its `DISPLAY` and
`XAUTHORITY`. The compositor removes inherited Hyprland, niri, Sway, and i3
IPC variables so clients do not attach to another compositor by accident.
`zl.set_env` can explicitly restore or replace a variable.

Named window icons use `ZL_ICON_THEME`, then the Otter preferred icon theme,
then GTK 4, GTK 3, or KDE settings, and finally `hicolor`. Lookup checks
`~/.icons`, `$XDG_DATA_HOME/icons` (or `~/.local/share/icons`), and the
`icons` directory below each `$XDG_DATA_DIRS` entry. Inherited themes are
followed before the final `hicolor` fallback.

Compositor cursors check each nonempty `$XCURSOR_PATH` entry before those XDG
icon roots. They try the selected `$XCURSOR_THEME`, then `default`, then
`Adwaita`, following inherited themes. `$XCURSOR_SIZE` defaults to 24 logical
pixels and is multiplied by output scale for image selection.

## Control socket

For Wayland socket `wayland-N`, Zoolander listens on
`$XDG_RUNTIME_DIR/zoolander-wayland-N.sock`. The Unix stream protocol is
newline-delimited:

- Server greeting: `ZLCTL 1`
- One command per line
- One `OK ...` or `ERR ...` reply line per command; `monitors`, `clients` and
  `layers` follow their line with a multi-line report, and their `-json` forms
  with one line of JSON
- Maximum command line: 2048 bytes
- Maximum simultaneous clients: 32

Commands:

| Command | Reply or effect |
| --- | --- |
| `ping` | `OK pong` |
| `version` | `OK version 1` |
| `status` | Config reload counts, config state, SSD state, and the renderer (`renderer="vulkan on <GPU> (<driver>, <KMS node>)"` or `renderer="software ..."`). |
| `reload` | Reload the current config and report the result. |
| `workspace NAME` | `OK occupied`, `OK empty`, or `ERR unknown workspace`. |
| `eval LUA` | Run a chunk in the active config runtime and return its first result. |
| `monitors` | `OK N outputs`, then a block per output: EDID make, model and serial; layout position, size, scale and transform; current mode and physical size; scanout format, modifier, bit depth and max bpc; adaptive sync, async flip and content type; HDR state; EDID primaries, gamma and luminance; the renderer's colour transform; and every mode the connector lists. |
| `monitors-json` | `OK json`, then one line of JSON (version 1) with the same state per output, and outputs that are turned off with `"enabled": false`. |
| `clients` | `OK N clients`, then a block per window: its foreign-toplevel identifier, title, app_id, client pid (for X11 windows, the one the X server reports through XRes, else `_NET_WM_PID`), native or Xwayland with an X11 window's WM_CLASS class and instance, workspace and output, global position and size, floating, fullscreen, maximized, minimized, focused, urgent and pinned, its xdg-toplevel tag, and its spatial group and tab group. Windows parked from unplugged outputs come last. |
| `clients-json` | `OK json`, then one line of JSON: an array with an object per window holding the same fields; `class` and `instance` are null for Wayland windows. |
| `layers` | `OK N layers`, then each layer-shell surface under its output and layer (background, bottom, top, overlay): namespace, client pid, global position and size, anchors, exclusive zone, margins, keyboard interactivity, and whether it is mapped. |
| `layers-json` | `OK json`, then one line of JSON: an array with an object per surface holding the same fields. |
| `quit` | Reply `OK bye`, then stop the compositor. |

Any local process running as the user can connect. `eval` has the same powers
as config code, including `zl.exec_command`, so the socket is a trusted local
control interface.

The `zoolanderctl` script sends one command to the socket selected by
`XDG_RUNTIME_DIR` and `WAYLAND_DISPLAY`:

```sh
./zoolanderctl status
./zoolanderctl reload
./zoolanderctl workspace 3
./zoolanderctl monitors
./zoolanderctl clients-json
./zoolanderctl eval 'return zl.window_count()'
```

It needs an `nc` implementation that supports Unix sockets with `-U` and
close-after-stdin with `-N`. `zoolanderctl help` prints its command list.

## Otter Shell

`install-system.sh` installs `zoolander.desktop` under
`share/wayland-sessions` and `zoolander-portals.conf` under
`share/xdg-desktop-portal`. The session file names the desktop `Zoolander`,
and the portal file prefers the `otter` portal backend, then `wlr`, then
`gtk`. A session launcher should export `XDG_CURRENT_DESKTOP=Zoolander` before
starting desktop services. A config can use `zl.set_env` to provide that value
to clients it spawns, as [`config/ferreo/env.lua`](config/ferreo/env.lua) does.

Otter components may query workspace occupancy through the control socket.
Start shell processes from the `startup` event so they receive Zoolander's
socket environment. The native `zl.toggle_overview()` is the supported
workspace-aware overview. `otter-overview` cannot recover Zoolander workspace
membership from the foreign-toplevel protocol and may group windows under the
wrong workspace.

The compositor works without Otter Shell. Without an Otter theme, native
defaults and explicit Lua settings remain active.

Privileged globals, including data control, output management, virtual input,
screencopy, and session lock, are hidden from clients connected through
`security-context-v1`. Ordinary local clients can bind them. Treat access to
the Wayland socket as trusted desktop-session access. [Protocols](docs/PROTOCOLS.md)
lists every global and which ones are privileged.

## Safety and diagnostics

Host-safe development uses the headless backend with `DISPLAY` and
`WAYLAND_DISPLAY` unset. DRM, synthetic input, nested compositor comparison,
and hardware cursor tests run in the project VM. See
[trace-diff](docs/TRACE-DIFF.md) for a VM-only client protocol comparison
workflow.
