#!/usr/bin/env python3
"""Raw-wire checks that client values reaching the output backend cannot
crash the compositor: extreme custom modes and malformed gamma ramps.

Run with WAYLAND_DISPLAY and XDG_RUNTIME_DIR pointing at a compositor in the VM.
Prints PASS, SKIP or FAIL per test; the exit status is non-zero on any failure.
"""
import os
import struct
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from protocol_e2e import Client, ProtocolError, Skip  # noqa: E402

INVALID_CUSTOM_MODE = 3
INVALID_GAMMA = 1


def heads(client):
    manager = client.bind("zwlr_output_manager_v1", 4)
    found = []
    serial = None
    for obj, opcode, body in client.read_events():
        client.note_registry(obj, opcode, body)
        if obj == manager and opcode == 0:
            found.append(struct.unpack_from("<I", body)[0])
        elif obj == manager and opcode == 1:
            serial = struct.unpack_from("<I", body)[0]
            break
    if not found:
        raise Skip("no output heads")
    return manager, found, serial


def custom_mode_extremes():
    modes = [(65535, 65535, 1), (1, 1, 2**31 - 1), (8, 1, 1818182), (8, 1, 1818181), (-1, -1, 0), (0, 0, 0),
             (2**31 - 1, 2**31 - 1, -(2**31)), (65536, 1, 60000), (1, 1, -1), (65535, 1, 2**31 - 1)]
    for width, height, refresh in modes:
        c = Client()
        manager, found, serial = heads(c)
        config = c.new_id()
        c.request(manager, 0, struct.pack("<II", config, serial))
        config_head = c.new_id()
        c.request(config, 0, struct.pack("<II", config_head, found[0]))
        # A configuration must name every live head, so keep the others as they are.
        for other in found[1:]:
            c.request(config, 0, struct.pack("<II", c.new_id(), other))
        c.request(config_head, 1, struct.pack("<iii", width, height, refresh))
        c.request(config, 3)
        try:
            c.wait_for(lambda obj, opcode, _: obj == config and opcode in (0, 1, 2))
        except ProtocolError as err:
            if err.obj != config_head or err.code != INVALID_CUSTOM_MODE:
                raise
    Client().roundtrip()


def gamma_ramps(c, gamma, entries):
    with tempfile.TemporaryFile() as ramp:
        ramp.write(b"\xff\x7f" * entries)
        ramp.seek(0)
        c.request(gamma, 0, fds=(ramp.fileno(),))
        return c.roundtrip()


def gamma_wrong_size():
    c = Client()
    if "zwlr_gamma_control_manager_v1" not in c.globals or not c.outputs:
        raise Skip("no gamma control")
    manager = c.bind("zwlr_gamma_control_manager_v1", 1)
    output = c.bind_name(c.outputs[0], "wl_output", 4)
    gamma = c.new_id()
    c.request(manager, 0, struct.pack("<II", gamma, output))
    size = None
    for obj, opcode, body in c.roundtrip():
        if obj == gamma and opcode == 0:
            size = struct.unpack_from("<I", body)[0]
        if obj == gamma and opcode == 1:
            raise Skip("output has no gamma table")
    if size is None:
        raise Skip("no gamma_size")
    gamma_ramps(c, gamma, 3 * size)
    for entries in (0, 3 * size - 1, 3 * size + 1):
        try:
            gamma_ramps(c, gamma, entries)
        except ProtocolError as err:
            if err.obj != gamma or err.code != INVALID_GAMMA:
                raise
            break
    else:
        raise AssertionError("short and long gamma ramps were accepted")
    Client().roundtrip()


TESTS = [custom_mode_extremes, gamma_wrong_size]


def main():
    wanted = set(sys.argv[1:])
    failed = False
    for test in TESTS:
        if wanted and test.__name__ not in wanted:
            continue
        try:
            test()
            print(f"PASS {test.__name__}")
        except Skip as why:
            print(f"SKIP {test.__name__}: {why}")
        except Exception as err:  # noqa: BLE001
            print(f"FAIL {test.__name__}: {err!r}")
            failed = True
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
