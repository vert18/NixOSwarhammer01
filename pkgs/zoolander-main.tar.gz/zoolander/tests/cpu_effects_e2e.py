#!/usr/bin/env python3
"""ext-background-effect's blur capability against the renderer a live DRM compositor picked.

A display whose GPU cannot render is drawn on the CPU, where zoolander offers no blur; a GPU
display offers it. The renderer comes from the control socket's status reply. Run with
WAYLAND_DISPLAY and XDG_RUNTIME_DIR pointing at zoolander; tests/run.sh starts one inside the
test VM.
"""
import os
import socket
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from protocol_e2e import Client  # noqa: E402

BLUR = 1


def renderer():
    runtime = os.environ["XDG_RUNTIME_DIR"]
    display = os.environ.get("WAYLAND_DISPLAY", "wayland-0")
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as control:
        control.settimeout(5)
        control.connect(os.path.join(runtime, f"zoolander-{display}.sock"))
        control.sendall(b"status\n")
        control.shutdown(socket.SHUT_WR)
        reply = b""
        while chunk := control.recv(4096):
            reply += chunk
    return reply.decode().split('renderer="', 1)[1].split('"', 1)[0]


def main():
    name = renderer()
    client = Client()
    manager = client.bind("ext_background_effect_manager_v1", 1)
    flags = [struct.unpack_from("<I", body)[0] for obj, opcode, body in client.roundtrip() if obj == manager and opcode == 0]
    expected = 0 if name.startswith("software") else BLUR
    ok = flags == [expected]
    print(f"{'PASS' if ok else 'FAIL'}: blur capability {flags}, expected [{expected}] on {name}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
