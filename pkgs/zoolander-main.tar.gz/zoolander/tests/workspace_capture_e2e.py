#!/usr/bin/env python3
"""hyprland_workspace_image_capture_source_manager_v1 checks against a live compositor.

Run with WAYLAND_DISPLAY and XDG_RUNTIME_DIR pointing at zoolander; tests/run.sh
starts one for it inside the test VM. A red window goes on a new workspace, the
first workspace is shown again with a blue window, and the hidden workspace's
source must still show red. Every check uses its own connection.
"""
import mmap
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bind_all_globals import read_string, string  # noqa: E402
from protocol_e2e import Client, expect_error  # noqa: E402

SOURCES = "hyprland_workspace_image_capture_source_manager_v1"
COPY = "ext_image_copy_capture_manager_v1"
WINDOWS_ONLY, EVERYTHING = 0, 1
ACTIVE = 1
RED, BLUE = 0xFFFF0000, 0xFF0000FF
NAME = "wscap-hidden"


class Desktop(Client):
    """A client that tracks ext-workspace state and maps solid-colour windows."""

    def __init__(self):
        super().__init__()
        self.compositor = self.bind("wl_compositor", 4)
        self.wm_base = self.bind("xdg_wm_base", 1)
        self.shm = self.bind("wl_shm", 1)
        self.manager = self.bind("ext_workspace_manager_v1", 1)
        self.groups, self.workspaces, self.names, self.states = set(), {}, {}, {}
        self.settle()

    def settle(self):
        for obj, op, body in self.roundtrip():
            self.note(obj, op, body)

    def note(self, obj, op, body):
        if obj == self.manager and op == 0:
            self.groups.add(struct.unpack("<I", body)[0])
        elif obj == self.manager and op == 1:
            self.workspaces[struct.unpack("<I", body)[0]] = None
        elif obj in self.groups and op == 3:
            self.workspaces[struct.unpack("<I", body)[0]] = obj
        elif obj in self.workspaces and op == 1:
            self.names[obj] = read_string(body, 0)[0]
        elif obj in self.workspaces and op == 3:
            self.states[obj] = struct.unpack("<I", body)[0]
        elif obj in self.workspaces and op == 5:
            del self.workspaces[obj]

    def workspace(self, name):
        return next(w for w, group in self.workspaces.items() if group is not None and self.names.get(w) == name)

    def commit(self, obj, opcode, payload=b""):
        self.request(obj, opcode, payload)
        self.request(self.manager, 0)
        self.settle()

    def shm_pixels(self, width, height, argb=None):
        size = width * height * 4
        fd = os.memfd_create("workspace-capture-e2e")
        os.ftruncate(fd, size)
        pixels = mmap.mmap(fd, size)
        if argb is not None:
            pixels[:] = struct.pack("<I", argb) * (width * height)
        pool, buffer = self.new_id(), self.new_id()
        self.request(self.shm, 0, struct.pack("<Ii", pool, size), [fd])
        os.close(fd)
        self.request(pool, 0, struct.pack("<IiiiiI", buffer, 0, width, height, width * 4, 0))
        return buffer, pixels

    def window(self, argb, fixed=None):
        """Map a window; a fixed size makes it a floating dialog-like window."""
        surface = self.surface(self.compositor)
        xdg_surface, toplevel = self.toplevel(self.wm_base, surface)
        if fixed:
            self.request(toplevel, 7, struct.pack("<ii", fixed, fixed))
            self.request(toplevel, 8, struct.pack("<ii", fixed, fixed))
        self.request(surface, 6)
        events = self.roundtrip()
        serial = next(struct.unpack("<I", body)[0] for obj, op, body in events if obj == xdg_surface and op == 0)
        width, height = next(struct.unpack_from("<ii", body) for obj, op, body in events if obj == toplevel and op == 0)
        self.request(xdg_surface, 4, struct.pack("<I", serial))
        self.request(surface, 1, struct.pack("<Iii", self.shm_pixels(width or fixed or 64, height or fixed or 64, argb)[0], 0, 0))
        self.request(surface, 6)
        self.settle()

    def session(self, workspace, mode):
        sources, copy = self.bind(SOURCES, 1), self.bind(COPY, 1)
        source, session = self.new_id(), self.new_id()
        self.request(sources, 0, struct.pack("<III", source, workspace, mode))
        self.request(copy, 0, struct.pack("<III", session, source, 0))
        size = None
        for obj, op, body in self.roundtrip():
            if obj == session and op == 0:
                size = struct.unpack("<II", body)
            elif obj == session and op == 1:
                assert struct.unpack("<I", body)[0] == 0, "workspace images are argb8888"
            elif obj == session and op == 5:
                raise AssertionError("the session stopped at once")
        assert size, "no buffer_size"
        return session, size

    def frame(self, session, size):
        """Capture one frame; return its pixels, or None when the session stopped."""
        buffer, pixels = self.shm_pixels(*size)
        frame = self.new_id()
        self.request(session, 0, struct.pack("<I", frame))
        self.request(frame, 1, struct.pack("<I", buffer))
        self.request(frame, 2, struct.pack("<iiii", 0, 0, *size))
        self.request(frame, 3)
        result = {}

        def done(obj, op, body):
            if obj == session and op == 5:
                result["stopped"] = True
            if obj == frame and op == 1:
                result["damage"] = struct.unpack("<iiii", body)
            if obj == frame and op == 4:
                result["failed"] = struct.unpack("<I", body)[0]
            return obj == frame and op in (3, 4)

        self.wait_for(done)
        self.request(frame, 0)
        if result.get("failed") == 2 or result.get("stopped"):
            return None
        assert "failed" not in result, f"frame failed with reason {result.get('failed')}"
        assert result.get("damage") == (0, 0, *size), f"damage {result.get('damage')} is not the whole frame"
        return pixels


def pixel(pixels, size, x, y):
    return struct.unpack_from("<I", pixels, (y * size[0] + x) * 4)[0]


def hidden_workspace_shows_its_own_window():
    c = Desktop()
    shown = next(w for w, group in c.workspaces.items() if group is not None and c.states.get(w, 0) & ACTIVE)
    group = c.workspaces[shown]
    c.commit(group, 0, string(NAME))
    hidden = c.workspace(NAME)
    c.commit(hidden, 1)
    c.window(RED, fixed=200)
    c.commit(shown, 1)
    c.window(BLUE)
    assert not c.states[hidden] & ACTIVE and c.states[shown] & ACTIVE, f"states {c.states}"
    centre = {}
    for mode in (WINDOWS_ONLY, EVERYTHING):
        session, size = c.session(hidden, mode)
        pixels = c.frame(session, size)
        assert pixels is not None, "the hidden workspace's session stopped"
        centre[mode] = pixel(pixels, size, size[0] // 2, size[1] // 2)
        corner = pixel(pixels, size, 0, 0)
        print(f"  mode {mode}: {size[0]}x{size[1]}, centre {centre[mode]:#010x}, corner {corner:#010x}")
        assert centre[mode] == RED, f"mode {mode}: centre {centre[mode]:#010x} is not the hidden workspace's red window"
        if mode == WINDOWS_ONLY:
            assert corner == 0, f"windows_only: corner {corner:#010x} is not transparent"
        else:
            assert corner >> 24 == 0xFF and corner != RED, f"everything: corner {corner:#010x} is not the opaque desktop"
    session, size = c.session(shown, WINDOWS_ONLY)
    pixels = c.frame(session, size)
    assert pixel(pixels, size, size[0] // 2, size[1] // 2) == BLUE, "the visible workspace does not show its blue window"


def invalid_mode_is_a_protocol_error():
    c = Desktop()
    sources = c.bind(SOURCES, 1)
    c.request(sources, 0, struct.pack("<III", c.new_id(), next(iter(c.workspaces)), 2))
    expect_error(c, sources, 0)


def removed_workspace_is_empty():
    c = Desktop()
    shown = next(w for w, group in c.workspaces.items() if group is not None and c.states.get(w, 0) & ACTIVE)
    c.commit(c.workspaces[shown], 0, string("wscap-removed"))
    hidden = c.workspace("wscap-removed")
    session, size = c.session(hidden, EVERYTHING)
    assert c.frame(session, size) is not None, "the session stopped before the removal"
    c.commit(hidden, 4)
    assert hidden not in c.workspaces, "the workspace was not removed"
    pixels = c.frame(session, size)
    if pixels is None:
        print("  removed workspace: session stopped")
        return
    print("  removed workspace: transparent frame")
    assert pixels[:] == bytes(len(pixels)), "the removed workspace's frame is not transparent and empty"


TESTS = [hidden_workspace_shows_its_own_window, invalid_mode_is_a_protocol_error, removed_workspace_is_empty]


def main():
    failed = 0
    for test in TESTS:
        try:
            test()
            print(f"PASS {test.__name__}")
        except Exception as err:
            failed += 1
            print(f"FAIL {test.__name__}: {type(err).__name__}: {err}")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
