#!/bin/sh
# Runs every test of zooland and zoolander: each Otr file with test blocks through
# `otr test`, the generated-code check, and the wire and E2E scripts against fresh
# compositors. zooland must be checked out next to zoolander.
#
#   tests/run.sh [--unit] [PATTERN]  run here; without --unit, refuses unless in the VM
#   tests/run.sh --vm [PATTERN]      copy both repos into the VM and run everything there
#   tests/run.sh --gpu [PATTERN]     only the real-GPU checks; refuses unless in a VM with an
#                                    amdgpu card (vm/igpu-test.sh up, then display)
#   tests/run.sh --vm --gpu [PATTERN]  copy both repos into the VM and run those there
#
# PATTERN limits the run to tests whose path or name contains it. Everything that starts
# a compositor, in-process or not, or touches DRM, the GPU or a seat runs only inside the
# test VM, which the --vm launcher marks with ZOO_VM_HARNESS=1. --unit runs only the
# rest. The launcher uses vm/vmctl.sh (VMCTL overrides it), so VM selects the instance;
# GUEST_OTR names the guest's otr when it is not on its PATH, where the scanner tests and
# the generated-code check look for it.
set -u
here=$(cd "$(dirname "$0")" && pwd)
zoolander=$(cd "$here/.." && pwd)
zooland=$(cd "$zoolander/../zooland" && pwd)
otr=${OTR:-otr}
mode=all
gpu=
case "${1:-}" in
--vm) mode=launch; shift ;;
--unit) mode=unit; shift ;;
--gpu) mode=gpu; shift ;;
esac
[ "$mode" = launch ] && [ "${1:-}" = --gpu ] && { gpu=--gpu; shift; }
pattern=${1:-}

# A worktree's vendor/luajit is often a symlink; a dangling one would let the build fall back
# to the system Lua headers, which lack LuaJIT's libraries.
[ -f "$zoolander/vendor/luajit/src/libluajit.a" ] && [ -f "$zoolander/vendor/luajit/src/lualib.h" ] ||
	{ echo "run.sh: $zoolander/vendor/luajit is missing or unbuilt (vendor/fetch-luajit.sh)" >&2; exit 2; }

if [ "$mode" = launch ]; then
	vmctl=${VMCTL:-$zoolander/../vm/vmctl.sh}
	"$vmctl" status | grep -q 'ssh: reachable' || { echo "run.sh: the VM is not up ($vmctl up)" >&2; exit 2; }
	dest=/home/zoo/zoo-tests/run-$(date +%s)
	# tar -h copies the trees behind symlinks; the host's build caches are huge and useless there.
	copy_tree() {
		tar -C "$1" -chzf - --exclude=.otr-cache --exclude=otr-out . |
			"$vmctl" run "mkdir -p $dest/$2 && tar -xzf - -C $dest/$2" || exit 2
	}
	copy_tree "$zooland" zooland
	copy_tree "$zoolander" zoolander
	guest_path=\$PATH
	[ -z "${GUEST_OTR:-}" ] || guest_path=$(dirname "$GUEST_OTR"):\$PATH
	# Each run copies both trees and builds there; left behind, a few runs fill the guest disk and
	# the next one fails with Io errors. Failure logs live in the guest's /tmp, not in the copy.
	exec "$vmctl" run "cd $dest/zoolander && PATH=$guest_path ZOO_VM_HARNESS=1 sh tests/run.sh $gpu '$pattern'; s=\$?; cd / && rm -rf $dest; exit \$s"
fi

in_vm=false
# The host this was written for runs its desktop on NVIDIA; no test VM has that driver.
if [ "${ZOO_VM_HARNESS:-}" = 1 ] && [ ! -e /sys/module/nvidia ]; then in_vm=true; fi

# The Vulkan checks want radv, which only the AMD passthrough VM has; the HDR checks want
# the simulated HDR sink igpu-test.sh display enables.
if [ "$mode" = gpu ]; then
	$in_vm || { echo "run.sh --gpu: only inside the test VM (tests/run.sh --vm --gpu)" >&2; exit 2; }
	amdgpu=false
	for driver in /sys/class/drm/card*/device/driver; do
		[ "$(basename "$(readlink -f "$driver")")" = amdgpu ] && amdgpu=true
	done
	$amdgpu || { echo "run.sh --gpu: no amdgpu card here; boot the AMD VM with vm/igpu-test.sh up" >&2; exit 2; }
	export LIBSEAT_BACKEND=${LIBSEAT_BACKEND:-seatd} SEATD_SOCK=${SEATD_SOCK:-/run/seatd.sock} ZOOLAND_EXPECT_HDR=1
fi

failed=0
refused=0
pass() { echo "ok   $1"; }
fail() { echo "FAIL $1${2:+ ($2)}"; failed=1; }
selected() { [ -z "$pattern" ] || case "$1" in *"$pattern"*) true ;; *) false ;; esac; }

# The checks that need a real GPU, and the DRM checks that only skip without one.
real_gpu() {
	case "$1" in
	*vk_*_check_test.otr|*e2e_drm_smoke_test.otr|*drm_check_test.otr|*gamma_check_test.otr|*plane_color_check_test.otr) true ;;
	*) false ;;
	esac
}

# A file starts a compositor or touches hardware when it is in an integration package
# (a tests/ directory with its own otr.toml) or its name says DRM, Vulkan or spawning.
# Only the path inside the repository counts, so a checkout under a directory named drm or
# tests is not taken for one.
vm_only() {
	rel=${1#"$zooland"/}
	case "${rel#"$zoolander"/}" in
	*/tests/*|*drm*|*vk_*|*spawn*|*runtime_test*) true ;;
	*) false ;;
	esac
}

run_otr_tests() {
	for file in $(grep -rlE '^[[:space:]]*test "' --include='*.otr' "$1" | sort); do
		selected "$file" || continue
		# Lavapipe suites refuse to run outside the sandbox vk-lvp-check.sh builds for them.
		case "$file" in *_lvp_test.otr) continue ;; esac
		# The ABI check compiles against vulkan_core.h, which not every machine has. The other
		# Vulkan checks and the DRM smoke test need a real radv or NVIDIA GPU (the smoke test also
		# an HDR-capable connector), which only the AMD test VM and the user's own machine have:
		# run them there with --gpu.
		if [ "$mode" = gpu ]; then
			real_gpu "$file" || continue
		else
			case "$file" in
			*vk_abi_check_test.otr) [ -f /usr/include/vulkan/vulkan_core.h ] || continue ;;
			*vk_*_check_test.otr|*e2e_drm_smoke_test.otr) continue ;;
			esac
		fi
		if vm_only "$file" && ! $in_vm; then
			refused=$((refused + 1))
			continue
		fi
		[ "$mode" = unit ] && vm_only "$file" && continue
		package=$(dirname "$file")
		while [ ! -f "$package/otr.toml" ]; do package=$(dirname "$package"); done
		# Timing budgets describe optimised builds, so a file with them runs again as one. The
		# dma-buf check runs again under the Khronos validation layer, which must stay silent.
		for variant in "" "--release -D perf_gates" validation one_renderer; do
			flags=$variant vars=
			case "$variant" in
			one_renderer)
				# The VM's first device has no Vulkan driver of its own: with any Vulkan device
				# allowed, the second device presents what that renderer drew.
				case "$file" in *e2e_drm_devices_test.otr) ;; *) continue ;; esac
				flags=
				vars="ZOOLAND_VK_ALLOW_UNMATCHED=1"
				;;
			--release*) grep -q build_options.perf_gates "$file" || continue ;;
			validation)
				case "$mode:$file" in gpu:*vk_dmabuf_check_test.otr) ;; *) continue ;; esac
				flags=
				vars="ZOOLAND_VK_VALIDATION=1 VK_KHRONOS_VALIDATION_DEBUG_ACTION=VK_DBG_LAYER_ACTION_LOG_MSG"
				vars="$vars VK_KHRONOS_VALIDATION_REPORT_FLAGS=error,warn VK_KHRONOS_VALIDATION_VALIDATE_SYNC=true"
				vars="$vars VK_KHRONOS_VALIDATION_LOG_FILENAME=$(mktemp -u)"
				;;
			esac
			log=$(mktemp)
			# shellcheck disable=SC2086
			if (cd "$package" && env $vars "$otr" test $flags "${file#"$package"/}") > "$log" 2>&1; then
				# otr test has no skip state: tests that cannot run here print a SKIP line and pass.
				skipped=$(grep -c '^SKIP' "$log")
				note=
				[ "$skipped" -eq 0 ] || note=" ($skipped skipped)"
				pass "$file${variant:+ ($variant)}: $(tail -n 1 "$log")$note"
				rm -f "$log"
			else
				grep -E 'FAIL|panic|error' "$log" | head -n 20
				fail "$file${variant:+ ($variant)}" "log: $log"
			fi
		done
	done
}

run_otr_tests "$zooland/otr"
run_otr_tests "$zoolander/otr"
if [ "$mode" != gpu ] && selected check-generated; then
	if "$zooland/otr/tools/check-generated.sh" > /dev/null 2>&1; then pass check-generated; else fail check-generated; fi
fi

if [ "$mode" = unit ]; then
	echo "unit run: $refused VM-only test files skipped"
	exit "$failed"
fi
if ! $in_vm; then
	echo "refused $refused VM-only test files and the E2E scripts: run tests/run.sh --vm, or --unit for the rest" >&2
	exit 2
fi

# The E2E scripts drive a real compositor on the VM's seat.
export LIBSEAT_BACKEND=${LIBSEAT_BACKEND:-seatd} SEATD_SOCK=${SEATD_SOCK:-/run/seatd.sock} XDG_SESSION_TYPE=wayland
mkdir -p "$zoolander/otr-out"
if ! (cd "$zoolander/otr-out" &&
	"$otr" build ../otr/native_main.otr --release --cpu baseline -rpath '$ORIGIN/../lib/zoolander' -o zoolander &&
	"$otr" build ../otr/bell_player.otr ../otr/bell_audio_ffi.c --release --cpu baseline \
		--lib shared --pkg-config libpipewire-0.3 -I ../otr -o libzoolander_bell.so &&
	"$otr" build ../otr/audio_visualizer/capture_lib.otr ../otr/bell_audio_ffi.c ../otr/audio_visualizer/capture_ffi.c --release --cpu baseline \
		--lib shared --pkg-config libpipewire-0.3 -I ../otr -o libzoolander_audio_visualizer.so) > /dev/null; then
	fail "build zoolander"
	exit 1
fi
bin=$zoolander/otr-out/zoolander

# Starts a compositor with CONFIG (or none) as its init.lua, runs the rest of the line
# against it, and requires it to survive and stop cleanly.
live() {
	name=$1 config=$2
	shift 2
	selected "$name" || return 0
	run=$(mktemp -d)
	mkdir -m700 "$run/rt"
	mkdir -p "$run/cfg/zoolander"
	[ -z "$config" ] || cp "$config" "$run/cfg/zoolander/init.lua"
	XDG_RUNTIME_DIR="$run/rt" XDG_CONFIG_HOME="$run/cfg" "$bin" > "$run/log" 2>&1 &
	compositor=$!
	for _ in $(seq 40); do [ -S "$run/rt/wayland-0" ] && break; sleep 0.5; done
	XDG_RUNTIME_DIR="$run/rt" WAYLAND_DISPLAY=wayland-0 ZL_PID=$compositor timeout 900 "$@" > "$run/test.log" 2>&1
	rc=$?
	if kill -0 "$compositor" 2> /dev/null; then
		kill -TERM "$compositor"
		wait "$compositor" || rc=1
	else
		wait "$compositor"
		rc=1
	fi
	grep -q panic "$run/log" && rc=1
	if [ "$rc" -eq 0 ]; then
		pass "$name$(grep -m 1 '^SKIP' "$run/test.log" | sed 's/.*/ (&)/')"
		rm -rf "$run"
	else
		tail -n 5 "$run/test.log"
		fail "$name" "logs: $run"
	fi
}

# Scripts that start their own compositors.
own() {
	name=$1
	shift
	selected "$name" || return 0
	log=$(mktemp)
	if timeout 1800 "$@" > "$log" 2>&1; then
		pass "$name"
		rm -f "$log"
	else
		tail -n 5 "$log"
		fail "$name" "log: $log"
	fi
}

# Real GL and Vulkan clients on the GPU's own driver: their buffers carry the fences a software run never sees.
if [ "$mode" = gpu ]; then
	live gpu_clients "" python3 "$here/gpu_clients_e2e.py"
	exit "$failed"
fi
own lavapipe sh "$zooland/otr/tools/vk-lvp-check.sh"
own protocol_e2e "$here/protocol_e2e.sh" "$bin"
own config_e2e python3 "$here/config_e2e.py" "$bin"
own starter_config python3 "$here/starter_config_e2e.py" "$bin" "$zoolander/config/starter"
own render_parity python3 "$here/render_parity.py" --compositor "$bin"
own workspace_protocol "$here/run_workspace_protocol.sh" "$bin"
own dormant_output python3 "$here/dormant_output_e2e.py" "$bin"
own rule_mode python3 "$here/rule_mode_e2e.py" "$bin"
own xwayland_wm "$here/xwayland_wm.sh" "$bin"
own mouselook_e2e "$here/mouselook_e2e.sh" "$bin"
own wsi_layer "$here/wsi_layer_e2e.sh" "$bin"
live backend_limits "" python3 "$here/backend_limits_e2e.py"
live wire_fuzz "" python3 "$here/wire_fuzz.py"
live cpu_effects "" python3 "$here/cpu_effects_e2e.py"
live drm_power_flip "" python3 "$here/drm_power_flip.py"
live focus_e2e "$here/focus_e2e.lua" python3 "$here/focus_e2e.py"
live workspace_capture "" python3 "$here/workspace_capture_e2e.py"
for case in dpms occluded overview; do
	live "sync_e2e $case" "" python3 "$here/sync_e2e.py" "$case"
done
# Reading back the scanout needs CAP_SYS_ADMIN: GETFB2 hides framebuffer handles from non-masters.
live "sync_e2e format" "" sudo -n --preserve-env=XDG_RUNTIME_DIR,WAYLAND_DISPLAY python3 "$here/sync_e2e.py" format
live "sync_e2e partial" "" sudo -n --preserve-env=XDG_RUNTIME_DIR,WAYLAND_DISPLAY python3 "$here/sync_e2e.py" partial
live syncobj_acquire "" python3 "$here/syncobj_acquire_e2e.py" 8
# GPU-style dma-bufs with implicit and explicit sync, from vgem; fails loudly without vgem. The software
# renderer offers dma-bufs only when asked: it can read vgem's memory but not a virgl client's.
export ZOOLAND_SW_DMABUF=1
live client_buffers "" python3 "$here/client_buffers_e2e.py"
live "client_buffers scanout" "$here/scanout_e2e.lua" python3 "$here/client_buffers_e2e.py" scanout-plain scanout-tagged-own scanout-tagged-other scanout-no-plane-colour
unset ZOOLAND_SW_DMABUF
exit "$failed"
