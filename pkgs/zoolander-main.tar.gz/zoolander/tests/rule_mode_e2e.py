#!/usr/bin/env python3
"""A rule's mode lights a DRM output once, in that mode, with no modeset at the
preferred mode before it: every modeset blanks the monitor.

Runs in the test VM: picks the first connected connector and a listed mode of
another size than its preferred one. Usage: rule_mode_e2e.py ZOOLANDER
"""
import glob
import os
import subprocess
import sys
import tempfile
import time

binary = sys.argv[1]
target = None
for status in sorted(glob.glob("/sys/class/drm/card*-*/status")):
    connector = os.path.dirname(status)
    if open(status).read().strip() != "connected":
        continue
    modes = [line.strip() for line in open(os.path.join(connector, "modes")) if line.strip()]
    other = next((m for m in modes if m != modes[0]), None)
    if other:
        target = (os.path.basename(connector).split("-", 1)[1], *map(int, other.split("x")))
        break
if target is None:
    print("SKIP no connected output lists a second mode")
    sys.exit(0)
name, width, height = target

with tempfile.TemporaryDirectory() as run:
    runtime = os.path.join(run, "rt")
    os.mkdir(runtime, 0o700)
    os.makedirs(os.path.join(run, "cfg", "zoolander"))
    with open(os.path.join(run, "cfg", "zoolander", "init.lua"), "w") as config:
        config.write(f'zl.output_rule({{ output = "{name}", width = {width}, height = {height}, refresh = 60 }})\n')
    log_path = os.path.join(run, "log")
    env = dict(os.environ, XDG_RUNTIME_DIR=runtime, XDG_CONFIG_HOME=os.path.join(run, "cfg"))
    env.pop("WAYLAND_DISPLAY", None)
    with open(log_path, "w") as log:
        compositor = subprocess.Popen([binary], env=env, stdout=log, stderr=subprocess.STDOUT)
    try:
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline and "modeset:" not in open(log_path).read():
            time.sleep(0.1)
        # A second modeset, when there is one, follows within the same start-up.
        time.sleep(2)
    finally:
        compositor.terminate()
        compositor.wait(timeout=10)
    modesets = [line.strip() for line in open(log_path) if "modeset:" in line]

print("\n".join(modesets))
if len(modesets) != 1 or f" {width}x{height}@" not in modesets[0]:
    print(f"FAIL want one modeset, at {width}x{height} on {name}; got {len(modesets)}")
    sys.exit(1)
print(f"ok one modeset, at {width}x{height} on {name}")
