#!/usr/bin/env python3
"""Raw-wire protocol checks against a live compositor.

Run with WAYLAND_DISPLAY and XDG_RUNTIME_DIR pointing at it:
    protocol_e2e.py [test-name ...]
Each test uses fresh connections and prints PASS, SKIP or FAIL. The exit status
is non-zero if any test failed. protocol_e2e.sh runs each test against its own
compositor.

Tests that unplug an output need ZL_E2E_CONNECTOR, the sysfs directory of a
connected DRM connector the compositor drives (/sys/class/drm/card0-Virtual-2),
and passwordless sudo to force it off.
"""
import array
import fcntl
import os
import socket
import struct
import subprocess
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bind_all_globals import DISPLAY, REGISTRY, message, read_string, string  # noqa: E402

XRGB8888 = 1
I32_MAX, I32_MIN = 2**31 - 1, -2**31
BTN_LEFT = 0x110


class Skip(Exception):
    pass


class ProtocolError(Exception):
    def __init__(self, obj, code, text):
        super().__init__(f"protocol error on object {obj} code {code}: {text}")
        self.obj, self.code = obj, code


def fixed(value):
    return struct.pack("<i", round(value * 256))


class Client:
    def __init__(self, path=None):
        if path is None:
            path = os.path.join(os.environ["XDG_RUNTIME_DIR"], os.environ.get("WAYLAND_DISPLAY", "wayland-0"))
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(5)
        self.sock.connect(path)
        self.buffer = b""
        self.next_id = REGISTRY + 1
        self.globals = {}
        self.outputs = []
        self.removed = set()
        self.send(message(DISPLAY, 1, struct.pack("<I", REGISTRY)))
        self.roundtrip()

    def new_id(self):
        self.next_id += 1
        return self.next_id - 1

    def send(self, data, fds=()):
        try:
            if fds:
                self.sock.sendmsg([data], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, struct.pack(f"{len(fds)}i", *fds))])
            else:
                self.sock.sendall(data)
        except BrokenPipeError:
            # The compositor closed after posting an error; report that error instead.
            for obj, opcode, body in self.read_events():
                if obj == DISPLAY and opcode == 0:
                    failed, code = struct.unpack_from("<II", body)
                    raise ProtocolError(failed, code, read_string(body, 8)[0]) from None

    def request(self, obj, opcode, payload=b"", fds=()):
        self.send(message(obj, opcode, payload), fds)

    def bind(self, interface, version):
        name, advertised = self.globals[interface]
        obj = self.new_id()
        self.request(REGISTRY, 0, struct.pack("<I", name) + string(interface) + struct.pack("<II", min(version, advertised), obj))
        return obj

    def read_events(self):
        while True:
            while len(self.buffer) >= 8:
                obj, word = struct.unpack_from("<II", self.buffer)
                size = word >> 16
                if len(self.buffer) < size:
                    break
                body, self.buffer = self.buffer[8:size], self.buffer[size:]
                yield obj, word & 0xFFFF, body
            data, ancillary, _, _ = self.sock.recvmsg(65536, socket.CMSG_SPACE(28 * 4))
            for level, kind, payload in ancillary:
                if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                    for fd in struct.unpack(f"{len(payload) // 4}i", payload[:len(payload) - len(payload) % 4]):
                        os.close(fd)
            if not data:
                raise ConnectionError("compositor closed the connection")
            self.buffer += data

    def roundtrip(self):
        """Sync, returning every other event that arrived before the callback."""
        callback = self.new_id()
        self.request(DISPLAY, 0, struct.pack("<I", callback))
        seen = []
        for obj, opcode, body in self.read_events():
            if obj == DISPLAY and opcode == 0:
                failed, code = struct.unpack_from("<II", body)
                raise ProtocolError(failed, code, read_string(body, 8)[0])
            if obj == callback and opcode == 0:
                return seen
            self.note_registry(obj, opcode, body)
            seen.append((obj, opcode, body))

    def note_registry(self, obj, opcode, body):
        if obj == REGISTRY and opcode == 0:
            (name,) = struct.unpack_from("<I", body)
            interface, at = read_string(body, 4)
            self.globals[interface] = (name, struct.unpack_from("<I", body, at)[0])
            if interface == "wl_output":
                self.outputs.append(name)
        elif obj == REGISTRY and opcode == 1:
            self.removed.add(struct.unpack_from("<I", body)[0])

    def wait_for(self, matches):
        """Read events until one satisfies `matches`; return the ones before it.
        Events after it stay buffered for the next read."""
        seen = []
        for obj, opcode, body in self.read_events():
            if obj == DISPLAY and opcode == 0:
                failed, code = struct.unpack_from("<II", body)
                raise ProtocolError(failed, code, read_string(body, 8)[0])
            self.note_registry(obj, opcode, body)
            if matches(obj, opcode, body):
                return seen
            seen.append((obj, opcode, body))

    def bind_name(self, name, interface, version):
        obj = self.new_id()
        self.request(REGISTRY, 0, struct.pack("<I", name) + string(interface) + struct.pack("<II", version, obj))
        return obj

    def surface(self, compositor):
        obj = self.new_id()
        self.request(compositor, 0, struct.pack("<I", obj))
        return obj

    def toplevel(self, wm_base, surface):
        xdg_surface, toplevel = self.new_id(), self.new_id()
        self.request(wm_base, 2, struct.pack("<II", xdg_surface, surface))
        self.request(xdg_surface, 1, struct.pack("<I", toplevel))
        return xdg_surface, toplevel

    def map_toplevel(self, compositor, wm_base, fullscreen_on=None):
        surface = self.surface(compositor)
        xdg_surface, toplevel = self.toplevel(wm_base, surface)
        if fullscreen_on is not None:
            self.request(toplevel, 11, struct.pack("<I", fullscreen_on))
        self.request(surface, 6)
        events = self.roundtrip()
        serial = next(struct.unpack("<I", body)[0] for obj, op, body in events if obj == xdg_surface and op == 0)
        width, height = next(struct.unpack_from("<ii", body) for obj, op, body in events if obj == toplevel and op == 0)
        self.request(xdg_surface, 4, struct.pack("<I", serial))
        self.request(surface, 1, struct.pack("<Iii", self.shm_buffer(width or 64, height or 64), 0, 0))
        self.request(surface, 6)
        return surface, toplevel

    def shm_buffer(self, width, height):
        shm = self.bind("wl_shm", 1)
        fd = os.memfd_create("protocol-e2e")
        os.ftruncate(fd, width * height * 4)
        pool, buffer = self.new_id(), self.new_id()
        self.request(shm, 0, struct.pack("<Ii", pool, width * height * 4), [fd])
        os.close(fd)
        self.request(pool, 0, struct.pack("<IiiiiI", buffer, 0, width, height, width * 4, XRGB8888))
        return buffer


def connector_output(client):
    """Bind every wl_output and return (global name, object) of the unplug connector's."""
    connector = os.environ.get("ZL_E2E_CONNECTOR")
    if not connector:
        raise Skip("ZL_E2E_CONNECTOR is not set")
    wanted = os.path.basename(connector).split("-", 1)[1]
    bound = {client.bind_name(name, "wl_output", 4): name for name in client.outputs}
    for obj, op, body in client.roundtrip():
        if obj in bound and op == 4 and read_string(body, 0)[0] == wanted:
            return bound[obj], obj
    raise AssertionError(f"no wl_output named {wanted}")


def unplug(client, name):
    """Force the connector off, then wait until `client` sees its output global go."""
    connector = os.environ["ZL_E2E_CONNECTOR"]
    card = os.path.join(os.path.dirname(connector), os.path.basename(connector).split("-", 1)[0])
    subprocess.run(["sudo", "sh", "-c", f"echo off > {connector}/status && udevadm trigger --action=change {card}"], check=True)
    client.wait_for(lambda obj, op, body: obj == REGISTRY and op == 1 and struct.unpack_from("<I", body)[0] == name)


def expect_error(client, obj, code):
    try:
        client.roundtrip()
    except ProtocolError as err:
        if (err.obj, err.code) != (obj, code):
            raise AssertionError(f"expected error {code} on {obj}, got {err}") from None
        return
    raise AssertionError(f"expected error {code} on {obj}, the round trip succeeded")


def held_commit_full_buffer():
    """A damage run ending exactly at a full receive buffer, then a damage and an
    incomplete near-maximum request, must not stall the reader on a full buffer."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    wm_base = c.bind("xdg_wm_base", 1)
    damaged = c.surface(compositor)
    _, toplevel = c.toplevel(wm_base, c.surface(compositor))
    c.roundtrip()
    damage = message(damaged, 2, struct.pack("<iiii", 0, 0, 1, 1))
    commit = message(damaged, 6, b"")
    run = (damage + commit) * (4096 // (len(damage) + len(commit)))
    assert len(run) == 4096
    title = message(toplevel, 2, string("t" * 4064))
    assert len(title) == 4080
    c.send(run + damage + title)
    c.roundtrip()


def xdg_surface_not_constructed():
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    wm_base = c.bind("xdg_wm_base", 1)
    surface = c.surface(compositor)
    xdg_surface = c.new_id()
    c.request(wm_base, 2, struct.pack("<II", xdg_surface, surface))
    c.request(surface, 6)
    expect_error(c, xdg_surface, 1)


def viewport_bad_size():
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    surface = c.surface(compositor)
    viewporter = c.bind("wp_viewporter", 1)
    viewport = c.new_id()
    c.request(viewporter, 1, struct.pack("<II", viewport, surface))
    c.request(viewport, 1, fixed(0) + fixed(0) + fixed(10.5) + fixed(10))
    c.roundtrip()
    c.request(surface, 6)
    expect_error(c, viewport, 1)


def viewport_out_of_buffer():
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    surface = c.surface(compositor)
    viewporter = c.bind("wp_viewporter", 1)
    viewport = c.new_id()
    c.request(viewporter, 1, struct.pack("<II", viewport, surface))
    c.request(viewport, 1, fixed(0) + fixed(0) + fixed(8) + fixed(8))
    c.request(surface, 1, struct.pack("<Iii", c.shm_buffer(4, 4), 0, 0))
    c.roundtrip()
    c.request(surface, 6)
    expect_error(c, viewport, 2)


def maximize_single_configure():
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    wm_base = c.bind("xdg_wm_base", 6)
    surface = c.surface(compositor)
    xdg_surface, toplevel = c.toplevel(wm_base, surface)
    c.request(surface, 6)
    configures = [body for obj, op, body in c.roundtrip() if obj == xdg_surface and op == 0]
    assert len(configures) == 1, f"initial commit sent {len(configures)} configures"
    c.request(xdg_surface, 4, configures[0])
    c.roundtrip()
    c.request(toplevel, 9)
    seen = c.roundtrip()
    # A configure the policy defers to after this dispatch arrives before the second callback.
    seen += c.roundtrip()
    count = sum(1 for obj, op, _ in seen if obj == xdg_surface and op == 0)
    assert count == 1, f"set_maximized sent {count} configures"


def wm_capabilities_match_policy():
    """The advertised window-management capabilities are the requests the policy acts on."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    wm_base = c.bind("xdg_wm_base", 5)
    surface = c.surface(compositor)
    xdg_surface, toplevel = c.toplevel(wm_base, surface)
    c.request(surface, 6)
    events = c.roundtrip()
    caps = [body for obj, op, body in events if obj == toplevel and op == 3]
    assert len(caps) == 1, f"initial commit sent {len(caps)} wm_capabilities"
    (size,) = struct.unpack_from("<I", caps[0])
    advertised = list(struct.unpack_from(f"<{size // 4}I", caps[0], 4))
    # request_window_menu is ignored, so GTK keeps its own titlebar menu.
    assert advertised == [2, 3, 4], f"advertised {advertised}"
    serial = next(struct.unpack("<I", body)[0] for obj, op, body in events if obj == xdg_surface and op == 0)
    c.request(xdg_surface, 4, struct.pack("<I", serial))
    c.request(surface, 1, struct.pack("<Iii", c.shm_buffer(64, 64), 0, 0))
    c.request(surface, 6)
    c.roundtrip()
    for opcode, state in ((9, 1), (11, 2)):
        c.request(toplevel, opcode, struct.pack("<I", 0) if opcode == 11 else b"")
        seen = c.roundtrip() + c.roundtrip()
        states = []
        for obj, op, body in seen:
            if obj == toplevel and op == 0:
                (length,) = struct.unpack_from("<I", body, 8)
                states = list(struct.unpack_from(f"<{length // 4}I", body, 12))
        assert state in states, f"request {opcode} left states {states}"


def security_context_hides_manager():
    c = Client()
    manager = c.bind("wp_security_context_manager_v1", 1)
    folder = tempfile.mkdtemp(dir=os.environ["XDG_RUNTIME_DIR"])
    path = os.path.join(folder, "sandbox")
    listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    listener.bind(path)
    listener.listen()
    listener.setblocking(False)
    close_read, close_write = os.pipe()
    context = c.new_id()
    c.request(manager, 1, struct.pack("<I", context), [listener.fileno(), close_read])
    os.close(close_read)
    c.request(context, 2, string("protocol.e2e"))
    c.request(context, 4)
    c.roundtrip()
    sandboxed = Client(path)
    assert "wl_compositor" in sandboxed.globals, "sandboxed client sees no globals"
    assert "wp_security_context_manager_v1" not in sandboxed.globals, "sandboxed client sees the security-context manager"
    assert "zwlr_output_manager_v1" not in sandboxed.globals, "sandboxed client sees output management"
    assert "zwlr_output_manager_v1" in c.globals, "unsandboxed client lost output management"
    os.close(close_write)


def xdg_output_on_removed_output():
    c = Client()
    manager = c.bind("zxdg_output_manager_v1", 3)
    name, output = connector_output(c)
    unplug(c, name)
    xdg_output = c.new_id()
    c.request(manager, 1, struct.pack("<II", xdg_output, output))
    events = [op for obj, op, _ in c.roundtrip() if obj == xdg_output]
    assert not events, f"xdg_output of a removed output sent events {events}"
    c.request(xdg_output, 0)
    c.roundtrip()


def screencopy_on_removed_output():
    c = Client()
    manager = c.bind("zwlr_screencopy_manager_v1", 3)
    name, output = connector_output(c)
    unplug(c, name)
    frame = c.new_id()
    c.request(manager, 0, struct.pack("<IiI", frame, 0, output))
    events = [op for obj, op, _ in c.roundtrip() if obj == frame]
    assert not events, f"screencopy frame of a removed output sent events {events}"
    c.request(frame, 1)
    c.roundtrip()


def output_power_on_removed_output():
    c = Client()
    manager = c.bind("zwlr_output_power_manager_v1", 1)
    name, output = connector_output(c)
    unplug(c, name)
    power = c.new_id()
    c.request(manager, 0, struct.pack("<II", power, output))
    c.request(power, 0, struct.pack("<I", 1))
    events = [op for obj, op, _ in c.roundtrip() if obj == power]
    assert not events, f"output power of a removed output sent events {events}"
    c.request(power, 1)
    c.roundtrip()


def foreign_toplevel_done_needs_leave():
    """Removing an output sends done only to handles that also got output_leave.
    The window moves to the remaining output but keeps its workspace, which that
    output does not show, so it enters no output and no handle gets another done."""
    window = Client()
    name, output = connector_output(window)
    surface, _ = window.map_toplevel(window.bind("wl_compositor", 6), window.bind("xdg_wm_base", 1), output)
    window.wait_for(lambda obj, op, body: obj == surface and op == 0 and body == struct.pack("<I", output))
    watchers = {}
    for binds_outputs in (False, True):
        c = Client()
        if binds_outputs:
            connector_output(c)
        manager = c.bind("zwlr_foreign_toplevel_manager_v1", 3)
        handles = []
        c.wait_for(lambda obj, op, body: obj == manager and op == 0 and not handles.append(struct.unpack("<I", body)[0]))
        c.wait_for(lambda obj, op, body: obj == handles[0] and op == 5)
        watchers[binds_outputs] = (c, handles[0])
    unplug(window, name)
    bound, handle = watchers[True]
    ops = []
    for _ in range(2):
        bound.wait_for(lambda obj, op, body: obj == handle and not ops.append(op))
    ops += [op for obj, op, _ in bound.roundtrip() if obj == handle]
    assert ops == [3, 5], f"a handle on both outputs got {ops}, not leave, done"
    blind, handle = watchers[False]
    ops = [op for obj, op, _ in blind.roundtrip() if obj == handle]
    assert not ops, f"a handle bound to no output got {ops}, not nothing"


def pointer_on_toplevel(c, compositor):
    """Map a toplevel and move a virtual pointer onto it.
    Returns (surface, toplevel, seat, pointer, virtual pointer, enter serial)."""
    surface, toplevel = c.map_toplevel(compositor, c.bind("xdg_wm_base", 1))
    seat = c.bind("wl_seat", 9)
    manager = c.bind("zwlr_virtual_pointer_manager_v1", 2)
    pointer, virtual = c.new_id(), c.new_id()
    c.request(seat, 0, struct.pack("<I", pointer))
    c.request(manager, 0, struct.pack("<II", 0, virtual))
    c.request(virtual, 1, struct.pack("<IIIII", 0, 500, 400, 1000, 800))
    c.request(virtual, 4)
    enter = []
    c.wait_for(lambda obj, op, body: obj == pointer and op == 0 and not enter.append(struct.unpack_from("<I", body)[0]))
    return surface, toplevel, seat, pointer, virtual, enter[0]


def press(c, pointer, virtual):
    """Press the left button through `virtual` and return the wl_pointer.button serial."""
    c.request(virtual, 2, struct.pack("<III", 0, BTN_LEFT, 1))
    c.request(virtual, 4)
    serial = []
    c.wait_for(lambda obj, op, body: obj == pointer and op == 3 and not serial.append(struct.unpack_from("<I", body)[0]))
    return serial[0]


def move(c, virtual, dx, dy):
    c.request(virtual, 0, struct.pack("<Iii", 0, dx * 256, dy * 256))
    c.request(virtual, 4)
    c.roundtrip()


def subsurface_at_i32_limits():
    """A subsurface placed at either i32 limit is drawn without overflowing the output mapping."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    subcompositor = c.bind("wl_subcompositor", 1)
    parent, _ = c.map_toplevel(compositor, c.bind("xdg_wm_base", 1))
    child, subsurface = c.surface(compositor), c.new_id()
    c.request(subcompositor, 1, struct.pack("<III", subsurface, child, parent))
    c.request(subsurface, 5)
    c.request(child, 1, struct.pack("<Iii", c.shm_buffer(64, 64), 0, 0))
    c.request(child, 6)
    for position in (I32_MAX, I32_MIN):
        c.request(subsurface, 1, struct.pack("<ii", position, position))
        frame = c.new_id()
        c.request(parent, 3, struct.pack("<I", frame))
        c.request(parent, 1, struct.pack("<Iii", c.shm_buffer(64, 64), 0, 0))
        c.request(parent, 2, struct.pack("<iiii", 0, 0, 64, 64))
        c.request(parent, 6)
        c.wait_for(lambda obj, op, body: obj == frame and op == 0)


def cursor_hotspot_at_i32_limits():
    """A cursor surface whose hotspot sits at an i32 limit keeps the pointer working."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    _, _, _, pointer, virtual, enter = pointer_on_toplevel(c, compositor)
    cursor = c.surface(compositor)
    c.request(cursor, 1, struct.pack("<Iii", c.shm_buffer(16, 16), 0, 0))
    c.request(cursor, 6)
    for hotspot in (I32_MIN, I32_MAX):
        c.request(pointer, 0, struct.pack("<IIii", enter, cursor, hotspot, hotspot))
        move(c, virtual, 3, 3)


def drag_icon_at_i32_limits():
    """A drag icon offset to an i32 limit follows the pointer without overflowing."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    surface, _, seat, pointer, virtual, _ = pointer_on_toplevel(c, compositor)
    serial = press(c, pointer, virtual)
    manager = c.bind("wl_data_device_manager", 3)
    device, source = c.new_id(), c.new_id()
    c.request(manager, 1, struct.pack("<II", device, seat))
    c.request(manager, 0, struct.pack("<I", source))
    c.request(source, 0, string("text/plain"))
    c.request(source, 2, struct.pack("<I", 1))
    icon = c.surface(compositor)
    c.request(icon, 1, struct.pack("<Iii", c.shm_buffer(8, 8), 0, 0))
    c.request(icon, 6)
    c.request(device, 0, struct.pack("<IIII", source, surface, icon, serial))
    for offset in (I32_MAX, I32_MIN, I32_MIN):
        c.request(icon, 10, struct.pack("<ii", offset, offset))
        c.request(icon, 6)
        move(c, virtual, 3, 3)


def toplevel_drag_offset_at_i32_limits():
    """A toplevel drag attached at an i32 offset moves the window without overflowing."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    surface, toplevel, seat, pointer, virtual, _ = pointer_on_toplevel(c, compositor)
    serial = press(c, pointer, virtual)
    manager = c.bind("wl_data_device_manager", 3)
    drags = c.bind("xdg_toplevel_drag_manager_v1", 1)
    device, source, drag = c.new_id(), c.new_id(), c.new_id()
    c.request(manager, 1, struct.pack("<II", device, seat))
    c.request(manager, 0, struct.pack("<I", source))
    c.request(drags, 1, struct.pack("<II", drag, source))
    c.request(drag, 1, struct.pack("<Iii", toplevel, I32_MAX, I32_MIN))
    c.request(device, 0, struct.pack("<IIII", source, surface, 0, serial))
    move(c, virtual, 50, 50)


def pointer_over_huge_viewport():
    """Surface-local pointer coordinates beyond wl_fixed's range saturate instead of overflowing."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    surface, _, _, _, virtual, _ = pointer_on_toplevel(c, compositor)
    viewporter = c.bind("wp_viewporter", 1)
    viewport = c.new_id()
    c.request(viewporter, 1, struct.pack("<II", viewport, surface))
    c.request(viewport, 2, struct.pack("<ii", I32_MAX, I32_MAX))
    c.request(surface, 1, struct.pack("<Iii", c.shm_buffer(64, 64), 0, 0))
    c.request(surface, 6)
    c.roundtrip()
    move(c, virtual, 5, 5)


def map_sized(c, compositor, wm_base, sizing):
    """Map a server-side decorated toplevel after `sizing(toplevel)` sets its hints or parent,
    with its window geometry at the i32 limit. Returns (surface, xdg_surface)."""
    decorations = c.bind("zxdg_decoration_manager_v1", 1)
    surface = c.surface(compositor)
    xdg_surface, toplevel = c.toplevel(wm_base, surface)
    decoration = c.new_id()
    c.request(decorations, 1, struct.pack("<II", decoration, toplevel))
    c.request(decoration, 1, struct.pack("<I", 2))
    sizing(toplevel)
    c.request(surface, 6)
    for _ in range(2):
        for obj, op, body in c.roundtrip():
            if obj == xdg_surface and op == 0:
                c.request(xdg_surface, 4, body)
        c.request(xdg_surface, 3, struct.pack("<iiii", 0, 0, I32_MAX, I32_MAX))
        c.request(surface, 1, struct.pack("<Iii", c.shm_buffer(64, 64), 0, 0))
        c.request(surface, 6)
    c.roundtrip()
    return surface, xdg_surface


def dialog_at_i32_size():
    """Dialogs sized at the i32 limit, by fixed size hints or by window geometry, float and
    then resize to their geometry without overflowing their frame."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    wm_base = c.bind("xdg_wm_base", 1)
    _, parent = c.map_toplevel(compositor, wm_base)
    for limit in (I32_MAX, 0):
        def sizing(toplevel, limit=limit):
            c.request(toplevel, 1, struct.pack("<I", parent))
            c.request(toplevel, 7, struct.pack("<ii", limit, limit))
            c.request(toplevel, 8, struct.pack("<ii", limit, limit))
        map_sized(c, compositor, wm_base, sizing)


def float_at_i32_min_size():
    """Floating a tiled window whose minimum size is the i32 limit keeps it within the output."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    map_sized(c, compositor, c.bind("xdg_wm_base", 1), lambda toplevel: c.request(toplevel, 8, struct.pack("<ii", I32_MAX, I32_MAX)))
    control = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    control.settimeout(5)
    control.connect(os.path.join(os.environ["XDG_RUNTIME_DIR"], f"zoolander-{os.environ.get('WAYLAND_DISPLAY', 'wayland-0')}.sock"))
    control.sendall(b"eval return zl.toggle_floating()\n")
    reply = b""
    while reply.count(b"\n") < 2:
        chunk = control.recv(4096)
        assert chunk, f"control socket closed after {reply!r}"
        reply += chunk
    assert reply.split(b"\n")[1] == b"OK true", f"toggle_floating replied {reply!r}"
    c.roundtrip()


def subsurface_tree_teardown():
    """A client that disconnects with a live subsurface tree leaves the compositor serving others."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    subcompositor = c.bind("wl_subcompositor", 1)
    parent = c.surface(compositor)
    for _ in range(2):
        child, subsurface = c.surface(compositor), c.new_id()
        c.request(subcompositor, 1, struct.pack("<III", subsurface, child, parent))
        c.request(subsurface, 5)
        parent = child
    c.roundtrip()
    c.sock.close()
    Client().roundtrip()


def shm_error_codes():
    """Each wl_shm failure posts the code the protocol assigns to it."""
    def pool(size, fd=None):
        c = Client()
        shm, obj = c.bind("wl_shm", 1), c.new_id()
        if fd is None:
            fd = os.memfd_create("protocol-e2e")
            os.ftruncate(fd, 64)
        c.request(shm, 0, struct.pack("<Ii", obj, size), [fd])
        os.close(fd)
        return c, shm, obj

    c, shm, _ = pool(0)
    expect_error(c, shm, 1)
    unmappable, writer = os.pipe()
    os.close(writer)
    c, shm, _ = pool(4096, unmappable)
    expect_error(c, shm, 2)
    c, _, obj = pool(64)
    c.request(obj, 0, struct.pack("<IiiiiI", c.new_id(), 0, 8, 8, 32, XRGB8888))
    expect_error(c, obj, 1)
    c, _, obj = pool(64)
    c.request(obj, 2, struct.pack("<i", 32))
    expect_error(c, obj, 1)


def shm_truncated_pool():
    """A pool file truncated beneath a committed buffer posts invalid_fd on that
    buffer when the compositor next reads it, instead of crashing on SIGBUS."""
    c = Client()
    compositor, wm_base, shm = c.bind("wl_compositor", 6), c.bind("xdg_wm_base", 1), c.bind("wl_shm", 1)
    surface = c.surface(compositor)
    xdg_surface, _ = c.toplevel(wm_base, surface)
    c.request(surface, 6)
    serial = next(struct.unpack("<I", body)[0] for obj, op, body in c.roundtrip() if obj == xdg_surface and op == 0)
    c.request(xdg_surface, 4, struct.pack("<I", serial))
    fd = os.memfd_create("protocol-e2e")
    os.ftruncate(fd, 64 * 64 * 4)
    pool, buffer = c.new_id(), c.new_id()
    c.request(shm, 0, struct.pack("<Ii", pool, 64 * 64 * 4), [fd])
    c.request(pool, 0, struct.pack("<IiiiiI", buffer, 0, 64, 64, 64 * 4, XRGB8888))
    c.request(surface, 1, struct.pack("<Iii", buffer, 0, 0))
    c.request(surface, 6)
    c.roundtrip()
    os.ftruncate(fd, 0)
    os.close(fd)
    c.request(surface, 1, struct.pack("<Iii", buffer, 0, 0))
    c.request(surface, 9, struct.pack("<iiii", 0, 0, 64, 64))
    c.request(surface, 6)
    # Frame callbacks can complete before the upload, so poll until the
    # compositor has rendered and read the pool.
    deadline = time.monotonic() + 3
    while time.monotonic() < deadline:
        try:
            c.roundtrip()
        except ProtocolError as err:
            assert (err.obj, err.code) == (buffer, 2), f"expected error 2 on {buffer}, got {err}"
            return
        time.sleep(0.05)
    raise AssertionError("no error after reading the truncated pool")


def syncobj_error_codes():
    """Each invalid explicit-sync state posts the code the protocol assigns to it."""
    try:
        drm = os.open("/dev/dri/renderD128", os.O_RDWR | os.O_CLOEXEC)
        created = fcntl.ioctl(drm, 0xC00864BF, struct.pack("<II", 0, 0))  # DRM_IOCTL_SYNCOBJ_CREATE
        exported = fcntl.ioctl(drm, 0xC01064C1, created + struct.pack("<iI", -1, 0))  # DRM_IOCTL_SYNCOBJ_HANDLE_TO_FD
        # Signal the acquire point up front so no commit waits on it.
        handle, point = array.array("I", created[:4]), array.array("Q", [1])
        signal = struct.pack("<QQII", handle.buffer_info()[0], point.buffer_info()[0], 1, 0)
        fcntl.ioctl(drm, 0xC01864CD, signal)  # DRM_IOCTL_SYNCOBJ_TIMELINE_SIGNAL
    except OSError as err:
        raise Skip(f"no DRM syncobj to share: {err}") from None
    timeline_fd = struct.unpack_from("<i", exported, 8)[0]

    def companion():
        c = Client()
        compositor, manager = c.bind("wl_compositor", 6), c.bind("wp_linux_drm_syncobj_manager_v1", 1)
        surface, sync, timeline = c.surface(compositor), c.new_id(), c.new_id()
        c.request(manager, 1, struct.pack("<II", sync, surface))
        c.request(manager, 2, struct.pack("<I", timeline), [timeline_fd])
        return c, surface, sync, timeline

    c, surface, sync, timeline = companion()
    c.request(surface, 0)
    c.request(sync, 1, struct.pack("<III", timeline, 0, 1))
    expect_error(c, sync, 1)
    c, surface, sync, timeline = companion()
    c.request(surface, 1, struct.pack("<Iii", c.shm_buffer(4, 4), 0, 0))
    c.request(sync, 1, struct.pack("<III", timeline, 0, 1))
    c.request(sync, 2, struct.pack("<III", timeline, 0, 2))
    c.request(surface, 6)
    expect_error(c, sync, 2)
    c, surface, sync, timeline = companion()
    c.request(sync, 1, struct.pack("<III", timeline, 0, 1))
    c.request(sync, 2, struct.pack("<III", timeline, 0, 2))
    c.request(surface, 6)
    expect_error(c, sync, 3)
    c, surface, sync, timeline = companion()
    c.request(surface, 1, struct.pack("<Iii", c.shm_buffer(4, 4), 0, 0))
    c.request(sync, 2, struct.pack("<III", timeline, 0, 2))
    c.request(surface, 6)
    expect_error(c, sync, 4)
    c, surface, sync, timeline = companion()
    c.request(surface, 1, struct.pack("<Iii", c.shm_buffer(4, 4), 0, 0))
    c.request(sync, 1, struct.pack("<III", timeline, 0, 1))
    c.request(surface, 6)
    expect_error(c, sync, 5)
    c, surface, sync, timeline = companion()
    c.request(surface, 1, struct.pack("<Iii", c.shm_buffer(4, 4), 0, 0))
    c.request(sync, 1, struct.pack("<III", timeline, 0, 1))
    c.request(sync, 2, struct.pack("<III", timeline, 0, 1))
    c.request(surface, 6)
    expect_error(c, sync, 6)
    os.close(timeline_fd)
    os.close(drm)


def lock_surface_pointer_enter():
    """While the session is locked, the pointer enters the lock surface of the
    output it is on, at output-local coordinates and whatever its input region."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    seat = c.bind("wl_seat", 5)
    pointer = c.new_id()
    c.request(seat, 0, struct.pack("<I", pointer))
    outputs = [c.bind_name(name, "wl_output", 4) for name in c.outputs]
    manager = c.bind("ext_session_lock_manager_v1", 1)
    lock = c.new_id()
    c.request(manager, 1, struct.pack("<I", lock))
    surfaces = {}
    empty = c.new_id()
    c.request(compositor, 1, struct.pack("<I", empty))
    for output in outputs:
        surface, lock_surface = c.surface(compositor), c.new_id()
        c.request(surface, 5, struct.pack("<I", empty))
        c.request(lock, 1, struct.pack("<III", lock_surface, surface, output))
        surfaces[lock_surface] = surface
    seen = c.roundtrip()
    sizes = {}
    for obj, op, body in seen:
        if obj in surfaces and op == 0:
            serial, width, height = struct.unpack("<III", body)
            c.request(obj, 1, struct.pack("<I", serial))
            c.request(surfaces[obj], 1, struct.pack("<Iii", c.shm_buffer(width, height), 0, 0))
            c.request(surfaces[obj], 6)
            sizes[surfaces[obj]] = (width, height)
    seen += c.roundtrip()
    if not any(obj == lock and op == 0 for obj, op, _ in seen):
        seen += c.wait_for(lambda obj, op, body: obj == lock and op == 0)
    target = surfaces[list(surfaces)[-1]]
    pointers = c.bind("zwlr_virtual_pointer_manager_v1", 2)
    virtual = c.new_id()
    c.request(pointers, 2, struct.pack("<III", 0, outputs[-1], virtual))
    c.request(virtual, 1, struct.pack("<IIIII", 1, 250, 250, 1000, 1000))
    c.request(virtual, 4)
    seen += c.roundtrip()
    entered = [struct.unpack_from("<I", body, 4)[0] for obj, op, body in seen if obj == pointer and op == 0]
    assert entered and entered[-1] == target, f"the pointer entered {entered}, not the lock surface {target}"
    sx, sy = next(struct.unpack_from("<ii", body, 8 if op == 0 else 4) for obj, op, body in reversed(seen) if obj == pointer and op in (0, 2))
    width, height = sizes[target]
    assert abs(sx / 256 - width / 4) <= 1 and abs(sy / 256 - height / 4) <= 1, f"pointer at {sx / 256},{sy / 256} on a {width}x{height} output"
    c.request(lock, 2)
    c.roundtrip()


def primary_selection_across_clients():
    """A primary selection set by one client reaches the next focused client as
    an offer in that client's own namespace, and leaves it with the source."""
    def focused_app():
        c = Client()
        compositor, wm_base, seat = c.bind("wl_compositor", 6), c.bind("xdg_wm_base", 1), c.bind("wl_seat", 5)
        keyboard = c.new_id()
        c.request(seat, 1, struct.pack("<I", keyboard))
        manager = c.bind("zwp_primary_selection_device_manager_v1", 1)
        device = c.new_id()
        c.request(manager, 1, struct.pack("<II", device, seat))
        c.map_toplevel(compositor, wm_base)
        seen = []
        for event in c.read_events():
            seen.append(event)
            if event[0] == keyboard and event[1] == 1:
                break
        return c, manager, device, struct.unpack_from("<I", seen[-1][2])[0], seen + c.roundtrip()

    a, manager, device, serial, _ = focused_app()
    source = a.new_id()
    a.request(manager, 0, struct.pack("<I", source))
    a.request(source, 0, string("text/plain"))
    a.request(device, 0, struct.pack("<II", source, serial))
    a.roundtrip()
    b, _, b_device, _, seen = focused_app()
    offers = [struct.unpack("<I", body)[0] for obj, op, body in seen if obj == b_device and op == 0]
    selections = [struct.unpack("<I", body)[0] for obj, op, body in seen if obj == b_device and op == 1]
    assert offers and offers[-1] >= 0xFF000000, f"no server-created offer for the focused client: {offers}"
    assert selections and selections[-1] == offers[-1], f"selection {selections} does not name the offer {offers[-1]}"
    a.request(source, 1)
    a.roundtrip()
    seen = b.roundtrip()
    assert (b_device, 1, struct.pack("<I", 0)) in seen, "the selection outlived its destroyed source"


def sync_on_live_id():
    """wl_display.sync naming a live object is invalid_object, not an implement on someone else's resource."""
    c = Client()
    c.request(DISPLAY, 0, struct.pack("<I", REGISTRY))
    expect_error(c, DISPLAY, 0)
    Client().roundtrip()


def wm_base_destroyed_before_xdg_surface():
    """xdg_wm_base.destroy with a live xdg_surface is defunct_surfaces; tearing that client down
    releases each xdg_surface's base reference once."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    wm_base = c.bind("xdg_wm_base", 1)
    surface = c.surface(compositor)
    c.request(wm_base, 2, struct.pack("<II", c.new_id(), surface))
    c.request(wm_base, 0)
    expect_error(c, wm_base, 1)
    Client().roundtrip()


def xdg_teardown_in_mixed_orders():
    """Disconnecting with a positioner, a mapped toplevel, an unmapped one, a bare xdg_surface and one
    whose wl_surface died first drops every xdg_wm_base reference exactly once."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    wm_base = c.bind("xdg_wm_base", 1)
    c.request(wm_base, 1, struct.pack("<I", c.new_id()))
    c.map_toplevel(compositor, wm_base)
    c.toplevel(wm_base, c.surface(compositor))
    for destroy_surface in (False, True):
        surface = c.surface(compositor)
        c.request(wm_base, 2, struct.pack("<II", c.new_id(), surface))
        if destroy_surface:
            c.request(surface, 0)
    c.roundtrip()
    c.sock.close()
    Client().roundtrip()


def idle_inhibitors_outlive_their_surface():
    """Counted inhibitors whose surface dies first, then a disconnect with more of them live: the
    inhibit count only ever drops for inhibitors that raised it."""
    c = Client()
    compositor = c.bind("wl_compositor", 6)
    wm_base = c.bind("xdg_wm_base", 1)
    manager = c.bind("zwp_idle_inhibit_manager_v1", 1)
    surface, toplevel = c.map_toplevel(compositor, wm_base)
    inhibitors = [c.new_id(), c.new_id()]
    for inhibitor in inhibitors:
        c.request(manager, 1, struct.pack("<II", inhibitor, surface))
    c.roundtrip()
    c.request(toplevel, 0)
    c.request(surface, 0)
    c.roundtrip()
    for inhibitor in inhibitors:
        c.request(inhibitor, 0)
    surface, _ = c.map_toplevel(compositor, wm_base)
    unmapped = c.surface(compositor)
    for target in (surface, surface, unmapped):
        c.request(manager, 1, struct.pack("<II", c.new_id(), target))
    c.request(manager, 0)
    c.request(surface, 1, struct.pack("<III", 0, 0, 0))
    c.request(surface, 6)
    c.roundtrip()
    c.sock.close()
    Client().roundtrip()


def background_effect_twice_on_surface():
    """A second effect object on one surface is background_effect_exists, not a duplicate attachment."""
    c = Client()
    if "ext_background_effect_manager_v1" not in c.globals:
        raise Skip("no ext_background_effect_manager_v1 global")
    compositor = c.bind("wl_compositor", 6)
    manager = c.bind("ext_background_effect_manager_v1", 1)
    surface = c.surface(compositor)
    c.request(manager, 1, struct.pack("<II", c.new_id(), surface))
    c.request(manager, 1, struct.pack("<II", c.new_id(), surface))
    expect_error(c, manager, 0)
    Client().roundtrip()


# zwlr_output_manager_v1 events / requests
OM_HEAD, OM_DONE = 0, 1
OM_CREATE_CONFIGURATION = 0
# zwlr_output_head_v1 events
HEAD_NAME, HEAD_ENABLED, HEAD_FINISHED = 0, 4, 9
# zwlr_output_configuration_v1 requests / events
CONFIG_ENABLE_HEAD, CONFIG_DISABLE_HEAD, CONFIG_APPLY = 0, 1, 2
CONFIG_SUCCEEDED = 0
# ext_workspace_manager_v1 events / requests
WS_GROUP, WS_WORKSPACE = 0, 1
WS_COMMIT = 0
# ext_workspace_group_handle_v1 events / requests
GROUP_REMOVED = 5
GROUP_CREATE_WORKSPACE = 0
# ext_workspace_handle_v1 events / requests
WORKSPACE_REMOVED = 5
WORKSPACE_ACTIVATE, WORKSPACE_DEACTIVATE, WORKSPACE_ASSIGN, WORKSPACE_REMOVE = 1, 2, 3, 4


class WorkspaceTracker:
    """Follows the output-management heads and ext-workspace handles one client sees."""

    def __init__(self, c, manager, workspaces):
        self.c, self.manager, self.workspaces = c, manager, workspaces
        self.serial = None
        self.heads = {}
        self.groups = set()
        self.handles = set()

    def feed(self, events):
        for obj, op, body in events:
            if obj == self.manager and op == OM_HEAD:
                self.heads[struct.unpack_from("<I", body)[0]] = {"name": None, "enabled": None}
            elif obj == self.manager and op == OM_DONE:
                self.serial = struct.unpack_from("<I", body)[0]
            elif obj in self.heads and op == HEAD_NAME:
                self.heads[obj]["name"] = body[4:4 + struct.unpack_from("<I", body)[0] - 1].decode()
            elif obj in self.heads and op == HEAD_ENABLED:
                self.heads[obj]["enabled"] = struct.unpack_from("<i", body)[0] != 0
            elif obj in self.heads and op == HEAD_FINISHED:
                del self.heads[obj]
            elif obj == self.workspaces and op == WS_GROUP:
                self.groups.add(struct.unpack_from("<I", body)[0])
            elif obj == self.workspaces and op == WS_WORKSPACE:
                self.handles.add(struct.unpack_from("<I", body)[0])
            elif obj in self.groups and op == GROUP_REMOVED:
                self.groups.discard(obj)
            elif obj in self.handles and op == WORKSPACE_REMOVED:
                self.handles.discard(obj)

    def roundtrip(self):
        events = self.c.roundtrip()
        self.feed(events)
        return events

    def configure(self, disabled):
        """Applies a configuration that disables `disabled` heads and keeps every other one on."""
        config = self.c.new_id()
        self.c.request(self.manager, OM_CREATE_CONFIGURATION, struct.pack("<II", config, self.serial))
        for head in self.heads:
            if head in disabled:
                self.c.request(config, CONFIG_DISABLE_HEAD, struct.pack("<I", head))
            else:
                self.c.request(config, CONFIG_ENABLE_HEAD, struct.pack("<II", self.c.new_id(), head))
        self.c.request(config, CONFIG_APPLY)
        events = self.roundtrip()
        return any(obj == config and op == CONFIG_SUCCEEDED for obj, op, _ in events)

    def poke_workspaces(self, groups):
        """Every ext-workspace request at every workspace and group, each batch committed."""
        for handle in sorted(self.handles):
            for request in (WORKSPACE_ACTIVATE, WORKSPACE_DEACTIVATE):
                self.c.request(handle, request)
                self.c.request(self.workspaces, WS_COMMIT)
                self.roundtrip()
        for handle in sorted(self.handles):
            for group in sorted(groups):
                self.c.request(handle, WORKSPACE_ASSIGN, struct.pack("<I", group))
                self.c.request(self.workspaces, WS_COMMIT)
                self.roundtrip()
        for group in sorted(groups):
            self.c.request(group, GROUP_CREATE_WORKSPACE, string("dormant"))
            self.c.request(self.workspaces, WS_COMMIT)
            self.roundtrip()
        for handle in sorted(self.handles):
            self.c.request(handle, WORKSPACE_REMOVE)
            self.c.request(self.workspaces, WS_COMMIT)
            self.roundtrip()


def two_toplevels():
    c = Client()
    compositor = c.bind("wl_compositor", 4)
    wm_base = c.bind("xdg_wm_base", 1)
    c.map_toplevel(compositor, wm_base)
    c.map_toplevel(compositor, wm_base)
    return c


def workspace_requests_on_disabled_output():
    c = two_toplevels()
    tracker = WorkspaceTracker(c, c.bind("zwlr_output_manager_v1", 4), c.bind("ext_workspace_manager_v1", 1))
    tracker.roundtrip()
    if tracker.serial is None or not tracker.heads:
        raise Skip("output management sent no heads")
    head = next(h for h, info in tracker.heads.items() if info["enabled"])
    groups = set(tracker.groups)
    if not tracker.configure({head}):
        raise Skip("the compositor refused to disable the output")
    tracker.poke_workspaces(groups | tracker.groups)
    # Whether a head comes back without a mode is the compositor's call; surviving it is not.
    tracker.configure(set())
    tracker.poke_workspaces(tracker.groups)
    if head in tracker.heads:
        tracker.configure({head})
        tracker.configure(set())
    Client().roundtrip()


def workspace_requests_after_unplug():
    c = two_toplevels()
    workspaces = c.bind("ext_workspace_manager_v1", 1)
    tracker = WorkspaceTracker(c, None, workspaces)
    tracker.roundtrip()
    name, _ = connector_output(c)
    groups = set(tracker.groups)
    unplug(c, name)
    tracker.roundtrip()
    tracker.poke_workspaces(groups | tracker.groups)
    Client().roundtrip()


TESTS = [held_commit_full_buffer, xdg_surface_not_constructed, viewport_bad_size, viewport_out_of_buffer,
         maximize_single_configure, wm_capabilities_match_policy, security_context_hides_manager, xdg_output_on_removed_output,
         screencopy_on_removed_output, output_power_on_removed_output, foreign_toplevel_done_needs_leave,
         subsurface_tree_teardown, shm_error_codes, shm_truncated_pool, syncobj_error_codes,
         subsurface_at_i32_limits, cursor_hotspot_at_i32_limits, drag_icon_at_i32_limits,
         toplevel_drag_offset_at_i32_limits, pointer_over_huge_viewport, dialog_at_i32_size, float_at_i32_min_size,
         lock_surface_pointer_enter, primary_selection_across_clients, sync_on_live_id,
         wm_base_destroyed_before_xdg_surface, xdg_teardown_in_mixed_orders, idle_inhibitors_outlive_their_surface,
         background_effect_twice_on_surface, workspace_requests_on_disabled_output, workspace_requests_after_unplug]


def main():
    wanted = sys.argv[1:]
    failed = 0
    for test in TESTS:
        if wanted and test.__name__ not in wanted:
            continue
        try:
            test()
            print(f"PASS {test.__name__}")
        except Skip as why:
            print(f"SKIP {test.__name__}: {why}")
        except Exception as err:
            failed += 1
            print(f"FAIL {test.__name__}: {type(err).__name__}: {err}")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
