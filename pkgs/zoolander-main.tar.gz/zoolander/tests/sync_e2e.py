#!/usr/bin/env python3
"""Raw-wire checks of zoolander's repaint and frame-callback scheduling.

Run against a live compositor: WAYLAND_DISPLAY and XDG_RUNTIME_DIR must point
at it, and ZL_PID must hold the compositor's pid.

  sync_e2e.py dpms       an output switched off by wlr-output-power takes no
                         repaint retries until it is switched back on
  sync_e2e.py occluded   a window hidden whole behind an opaque one gets no
                         frame callbacks from frame-only commits
  sync_e2e.py overview   with the overview open, a minimized window (which the
                         overview does not show) gets no frame callbacks
  sync_e2e.py format     a buffer whose bytes match the last one but whose
                         format adds alpha repaints the whole window even with
                         one pixel of damage (needs root: it reads the
                         scanout framebuffer back through KMS)
  sync_e2e.py partial    two frames that each change a different spot both
                         reach the screen: the buffer shown after the second
                         also carries the first (needs root, as format)
"""
import fcntl
import mmap
import array
import os
import re
import socket
import struct
import subprocess
import sys
import time

DISPLAY, REGISTRY = 1, 2
ARGB8888, XRGB8888 = 0, 1


def message(obj, opcode, payload=b""):
    return struct.pack("<II", obj, (8 + len(payload)) << 16 | opcode) + payload


def string(text):
    raw = text.encode() + b"\0"
    return struct.pack("<I", len(raw)) + raw + b"\0" * (-len(raw) % 4)


def read_string(body, at):
    (size,) = struct.unpack_from("<I", body, at)
    return body[at + 4:at + 3 + size].decode(), at + 4 + size + (-size % 4)


class Client:
    def __init__(self):
        path = os.path.join(os.environ["XDG_RUNTIME_DIR"], os.environ.get("WAYLAND_DISPLAY", "wayland-0"))
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect(path)
        self.buffer = b""
        self.next_id = 3
        self.handlers = {}
        self.globals = {}
        self.send(message(DISPLAY, 1, struct.pack("<I", REGISTRY)))
        self.on(REGISTRY, self._global)
        self.roundtrip()
        self.wm = self.bind("xdg_wm_base", 1)
        self.on(self.wm, lambda op, body: self.send(message(self.wm, 3, body[:4])) if op == 0 else None)
        self.compositor = self.bind("wl_compositor", 4)
        self.shm = self.bind("wl_shm", 1)

    def _global(self, opcode, body):
        if opcode != 0:
            return
        name, = struct.unpack_from("<I", body)
        interface, at = read_string(body, 4)
        version, = struct.unpack_from("<I", body, at)
        self.globals.setdefault(interface, (name, version))

    def new_id(self):
        self.next_id += 1
        return self.next_id - 1

    def on(self, obj, handler):
        self.handlers[obj] = handler

    def send(self, data, fds=()):
        if fds:
            self.sock.sendmsg([data], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array("i", fds))])
        else:
            self.sock.sendall(data)

    def bind(self, interface, version):
        name, advertised = self.globals[interface]
        obj = self.new_id()
        self.send(message(REGISTRY, 0, struct.pack("<I", name) + string(interface) + struct.pack("<II", min(version, advertised), obj)))
        return obj

    def dispatch(self, timeout):
        """Handle events for up to `timeout` seconds; returns after the first batch."""
        self.sock.settimeout(timeout)
        try:
            fds = array.array("i")
            data, ancillary, _, _ = self.sock.recvmsg(65536, socket.CMSG_SPACE(28 * fds.itemsize))
        except socket.timeout:
            return
        for level, kind, payload in ancillary:
            if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                fds.frombytes(payload[:len(payload) - len(payload) % fds.itemsize])
        for fd in fds:
            os.close(fd)
        if not data:
            raise ConnectionError("compositor closed the connection")
        self.buffer += data
        while len(self.buffer) >= 8:
            obj, word = struct.unpack_from("<II", self.buffer)
            size = word >> 16
            if len(self.buffer) < size:
                break
            body, self.buffer = self.buffer[8:size], self.buffer[size:]
            if obj == DISPLAY and word & 0xFFFF == 0:
                failed, code = struct.unpack_from("<II", body)
                raise RuntimeError(f"protocol error on object {failed} code {code}: {read_string(body, 8)[0]}")
            if obj in self.handlers:
                self.handlers[obj](word & 0xFFFF, body)

    def wait(self, done, timeout=5.0):
        end = time.monotonic() + timeout
        while not done():
            left = end - time.monotonic()
            if left <= 0:
                raise TimeoutError("timed out waiting for the compositor")
            self.dispatch(left)

    def roundtrip(self):
        callback = self.new_id()
        state = {"done": False}
        self.on(callback, lambda op, body: state.update(done=True))
        self.send(message(DISPLAY, 0, struct.pack("<I", callback)))
        self.wait(lambda: state["done"])

    def buffer_of(self, width, height, color, format=XRGB8888):
        stride = width * 4
        fd = os.memfd_create("sync-e2e")
        os.ftruncate(fd, stride * height)
        os.pwrite(fd, struct.pack("<I", color) * (width * height), 0)
        pool = self.new_id()
        self.send(message(self.shm, 0, struct.pack("<Ii", pool, stride * height)), [fd])
        os.close(fd)
        buffer = self.new_id()
        self.send(message(pool, 0, struct.pack("<IiiiiI", buffer, 0, width, height, stride, format)))
        self.send(message(pool, 1))
        return buffer

    def buffer_with(self, width, height, color, patches):
        """An XRGB buffer of `color` with each (x, y, w, h, patch_color) of `patches` painted over it."""
        pixels = array.array("I", [color] * (width * height))
        for x, y, w, h, patch in patches:
            for row in range(y, y + h):
                pixels[row * width + x:row * width + x + w] = array.array("I", [patch] * w)
        stride = width * 4
        fd = os.memfd_create("sync-e2e")
        os.ftruncate(fd, stride * height)
        os.pwrite(fd, pixels.tobytes(), 0)
        pool = self.new_id()
        self.send(message(self.shm, 0, struct.pack("<Ii", pool, stride * height)), [fd])
        os.close(fd)
        buffer = self.new_id()
        self.send(message(pool, 0, struct.pack("<IiiiiI", buffer, 0, width, height, stride, XRGB8888)))
        self.send(message(pool, 1))
        self.on(buffer, lambda op, body: None)
        return buffer

    def frame(self, surface, counter, key):
        callback = self.new_id()
        self.on(callback, lambda op, body: counter.__setitem__(key, counter[key] + 1))
        self.send(message(surface, 3, struct.pack("<I", callback)))


class Window:
    def __init__(self, client, app_id, width, height, color):
        self.client = client
        self.surface = client.new_id()
        client.send(message(client.compositor, 0, struct.pack("<I", self.surface)))
        self.xdg = client.new_id()
        client.send(message(client.wm, 2, struct.pack("<II", self.xdg, self.surface)))
        self.toplevel = client.new_id()
        client.send(message(self.xdg, 1, struct.pack("<I", self.toplevel)))
        client.send(message(self.toplevel, 3, string(app_id)))
        self.serial = None
        client.on(self.xdg, self._configure)
        client.on(self.toplevel, lambda op, body: None)
        client.send(message(self.surface, 6))
        client.wait(lambda: self.serial is not None)
        client.send(message(self.xdg, 4, struct.pack("<I", self.serial)))
        self.buffer = client.buffer_of(width, height, color)
        client.on(self.buffer, lambda op, body: None)
        self.redraw()
        client.roundtrip()

    def _configure(self, opcode, body):
        if opcode == 0:
            self.serial, = struct.unpack_from("<I", body)

    def redraw(self):
        self.client.send(message(self.surface, 1, struct.pack("<Iii", self.buffer, 0, 0)))
        self.client.send(message(self.surface, 9, struct.pack("<iiii", 0, 0, 0x7FFFFFFF, 0x7FFFFFFF)))
        self.client.send(message(self.surface, 6))


def context_switches(pid):
    total = 0
    for task in os.listdir(f"/proc/{pid}/task"):
        with open(f"/proc/{pid}/task/{task}/status") as status:
            for line in status:
                if "ctxt_switches:" in line:
                    total += int(line.split()[-1])
    return total


def switch_rate(pid, seconds):
    before = context_switches(pid)
    time.sleep(seconds)
    return (context_switches(pid) - before) / seconds


def dpms():
    pid = int(os.environ["ZL_PID"])
    client = Client()
    window = Window(client, "sync-dpms", 320, 240, 0xFF3366AA)
    output = client.bind("wl_output", 1)
    manager = client.bind("zwlr_output_power_manager_v1", 1)
    power = client.new_id()
    modes = []
    client.on(power, lambda op, body: modes.append(struct.unpack_from("<I", body)[0] if op == 0 else "failed"))
    client.send(message(manager, 0, struct.pack("<II", power, output)))
    client.wait(lambda: modes)
    idle = switch_rate(pid, 1.0)
    client.send(message(power, 0, struct.pack("<I", 0)))
    client.roundtrip()
    for _ in range(3):
        window.redraw()
        client.roundtrip()
    off = switch_rate(pid, 2.0)
    frames = {"n": 0}
    client.frame(window.surface, frames, "n")
    client.send(message(power, 0, struct.pack("<I", 1)))
    window.redraw()
    client.wait(lambda: frames["n"] == 1)
    print(f"context switches/s: idle {idle:.0f}, output off with owed repaint {off:.0f}; frame after power-on: {frames['n']}")
    if off > idle + 100:
        print("FAIL: the compositor spins while the output is off")
        return 1
    print("PASS")
    return 0


def occluded():
    # Tiled windows sit side by side; floated ones open centred at their own
    # size under the pointer, so the larger cover hides the smaller window whole.
    control('eval zl.add_window_rule("app_id", "^(sync-occluded-.*)$", { float = true })')
    client = Client()
    hidden = Window(client, "sync-occluded-hidden", 160, 120, 0xFF3366AA)
    Window(client, "sync-occluded-cover", 480, 360, 0xFFAA6633)
    time.sleep(0.5)
    client.roundtrip()
    frames = {"n": 0}
    end = time.monotonic() + 1.5
    commits = 0
    while time.monotonic() < end:
        client.frame(hidden.surface, frames, "n")
        client.send(message(hidden.surface, 6))
        commits += 1
        client.dispatch(0.02)
    client.roundtrip()
    print(f"hidden window: {commits} frame-only commits, {frames['n']} frame callbacks")
    if frames["n"] > 2:
        print("FAIL: an occluded window keeps getting frame callbacks")
        return 1
    print("PASS")
    return 0


def drm_iowr(nr, size):
    return 3 << 30 | size << 16 | ord("d") << 8 | nr


def scanout_pixel(x, y):
    """The XRGB word at (x, y) of the framebuffer the first active CRTC scans out."""
    fd = os.open("/dev/dri/card0", os.O_RDWR)
    try:
        res = bytearray(64)
        fcntl.ioctl(fd, drm_iowr(0xA0, 64), res)
        crtcs = struct.unpack_from("<I", res, 36)[0]
        ids = array.array("I", [0] * crtcs)
        struct.pack_into("<Q", res, 8, ids.buffer_info()[0])
        struct.pack_into("<IIII", res, 32, 0, crtcs, 0, 0)
        fcntl.ioctl(fd, drm_iowr(0xA0, 64), res)
        for crtc in ids:
            info = bytearray(104)
            struct.pack_into("<I", info, 12, crtc)
            fcntl.ioctl(fd, drm_iowr(0xA1, 104), info)
            fb = struct.unpack_from("<I", info, 16)[0]
            if fb:
                break
        else:
            raise RuntimeError("no CRTC scans out a framebuffer")
        cmd = bytearray(104)
        struct.pack_into("<I", cmd, 0, fb)
        fcntl.ioctl(fd, drm_iowr(0xCE, 104), cmd)
        width, height = struct.unpack_from("<II", cmd, 4)
        handle, = struct.unpack_from("<I", cmd, 20)
        if not handle:
            # The kernel hands framebuffer handles only to the DRM master or CAP_SYS_ADMIN.
            raise PermissionError("GETFB2 returned no handle: reading the scanout needs root")
        pitch, = struct.unpack_from("<I", cmd, 36)
        offset, = struct.unpack_from("<I", cmd, 52)
        dumb = bytearray(struct.pack("<IIQ", handle, 0, 0))
        try:
            fcntl.ioctl(fd, drm_iowr(0xB3, 16), dumb)
        except PermissionError:
            # amdgpu refuses CPU maps of VRAM-only scanout buffers; the output capture reads the same frame back.
            ppm = subprocess.run(["grim", "-g", f"{x},{y} 1x1", "-t", "ppm", "-"], check=True, capture_output=True).stdout
            return ppm[-3] << 16 | ppm[-2] << 8 | ppm[-1], (width, height)
        with mmap.mmap(fd, pitch * height, mmap.MAP_SHARED, mmap.PROT_READ, offset=struct.unpack_from("<Q", dumb, 8)[0]) as image:
            return struct.unpack_from("<I", image, offset + y * pitch + x * 4)[0] & 0xFFFFFF, (width, height)
    finally:
        os.close(fd)


def alpha_format():
    client = Client()
    # The same bytes read as opaque XRGB first, then as fully transparent ARGB.
    window = Window(client, "sync-format", 320, 240, 0x003366AA)
    transparent = client.buffer_of(320, 240, 0x003366AA, ARGB8888)
    time.sleep(1.0)
    client.roundtrip()
    before, (width, height) = scanout_pixel(640, 400)
    client.send(message(window.surface, 1, struct.pack("<Iii", transparent, 0, 0)))
    client.send(message(window.surface, 9, struct.pack("<iiii", 0, 0, 1, 1)))
    client.send(message(window.surface, 6))
    client.roundtrip()
    time.sleep(0.5)
    after, _ = scanout_pixel(width // 2, height // 2)
    print(f"window centre on the {width}x{height} scanout: XRGB {before:06x}, same bytes as ARGB {after:06x}")
    if before != 0x3366AA:
        print("FAIL: the window does not cover the output centre")
        return 1
    if after == before:
        print("FAIL: the alpha-format change kept the client's one-pixel damage and left stale pixels")
        return 1
    print("PASS")
    return 0


def partial():
    client = Client()
    base, first, second = 0x003366AA, 0x00CC4422, 0x0022AA44
    window = Window(client, "sync-partial", 320, 240, base)
    time.sleep(1.0)
    client.roundtrip()
    centre, _ = scanout_pixel(640, 400)
    if centre != base:
        print(f"FAIL: the window does not cover the output centre ({centre:06x})")
        return 1
    # Where the window is drawn: tiled, its 320x240 buffer is scaled to the window's size.
    listing = control("clients").split('app_id: "sync-partial"', 1)[1]
    left, top, shown_w, shown_h = map(int, re.search(r"at: (-?\d+),(-?\d+) size: (\d+)x(\d+)", listing).groups())

    def on_screen(x, y):
        return left + (x * shown_w) // 320, top + (y * shown_h) // 240

    a, b = (40, 40, 16, 16), (240, 160, 16, 16)
    steps = [
        (client.buffer_with(320, 240, base, [(*a, first)]), a),
        (client.buffer_with(320, 240, base, [(*a, first), (*b, second)]), b),
    ]
    for buffer, (x, y, w, h) in steps:
        client.send(message(window.surface, 1, struct.pack("<Iii", buffer, 0, 0)))
        client.send(message(window.surface, 9, struct.pack("<iiii", x, y, w, h)))
        client.send(message(window.surface, 6))
        client.roundtrip()
        time.sleep(0.5)
    shown_a, _ = scanout_pixel(*on_screen(a[0] + 8, a[1] + 8))
    shown_b, _ = scanout_pixel(*on_screen(b[0] + 8, b[1] + 8))
    print(f"after two partial frames the scanout shows {shown_a:06x} at the first spot, {shown_b:06x} at the second")
    if shown_b != second:
        print("FAIL: the second frame's change is not on screen")
        return 1
    if shown_a != first:
        print("FAIL: the buffer shown after the second frame lacks the first frame's change")
        return 1
    print("PASS")
    return 0


def control(command):
    path = os.path.join(os.environ["XDG_RUNTIME_DIR"], "zoolander-" + os.environ.get("WAYLAND_DISPLAY", "wayland-0") + ".sock")
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
        sock.connect(path)
        sock.sendall(command.encode() + b"\n")
        sock.shutdown(socket.SHUT_WR)
        reply = b""
        while chunk := sock.recv(4096):
            reply += chunk
    if b"OK" not in reply:
        raise RuntimeError(f"control command {command!r} failed: {reply!r}")
    return reply.decode()


def overview():
    client = Client()
    minimized = Window(client, "sync-minimized", 320, 240, 0xFF3366AA)
    shown = Window(client, "sync-shown", 320, 240, 0xFFAA6633)
    client.send(message(minimized.toplevel, 13))
    client.roundtrip()
    time.sleep(0.5)
    control("eval zl.toggle_overview()")
    time.sleep(0.5)
    frames = {"n": 0, "shown": 0}
    client.frame(minimized.surface, frames, "n")
    client.send(message(minimized.surface, 6))
    end = time.monotonic() + 1.5
    while time.monotonic() < end:
        client.frame(shown.surface, frames, "shown")
        shown.redraw()
        client.dispatch(0.02)
    client.roundtrip()
    print(f"during overview: minimized window {frames['n']} frame callbacks, shown window {frames['shown']}")
    if frames["n"] or not frames["shown"]:
        print("FAIL: the overview hands frame callbacks to a window it does not show, or none to one it does")
        return 1
    print("PASS")
    return 0


if __name__ == "__main__":
    sys.exit({"dpms": dpms, "occluded": occluded, "overview": overview, "format": alpha_format, "partial": partial}[sys.argv[1]]())
