#!/bin/sh
# Builds the WSI layer and wsi_layer_client.c, then runs the client under ZOOLANDER's Xwayland with the
# layer registered through VK_ADD_IMPLICIT_LAYER_PATH, so nothing is installed:
# - with a force_game_hdr rule its X11 surface offers HDR10, DXVK_HDR is set, its frames reach the
#   compositor through the bypass wl_surface tagged PQ, and the SDR output shows PQ 0.439 converted;
# - without the rule the layer passes through: no HDR10, no DXVK_HDR, X11 presentation, 0x70 on screen;
# - with the rule matched by a native game's class, a swapchain made before the window maps is HDR;
# - with the rule and an sRGB swapchain, as a game with HDR off, the bypass shows its sRGB unchanged;
# - with the rule and ZOOLANDER_WSI_DISABLE=1 the loader leaves the layer out.
# usage: wsi_layer_e2e.sh ZOOLANDER
set -eu
bin=${1:?usage: wsi_layer_e2e.sh ZOOLANDER}
here=$(cd "$(dirname "$0")" && pwd)
work=$(mktemp -d)
mkdir -p "$work/layers"
(cd "$work" &&
	otr build "$here/../wsi/layer.otr" --release --lib shared -l wayland-client -l xcb -l X11-xcb -o libVkLayer_zoolander_wsi.so > /dev/null &&
	otr run "$here/../wsi/manifest.otr" -- "$work/libVkLayer_zoolander_wsi.so" > "$work/layers/zoolander_wsi.json")
cc -O2 "$here/wsi_layer_client.c" -o "$work/client" -lvulkan -lxcb

failed=0
check() { # name, condition result
	if [ "$2" = yes ]; then echo "ok   $1"; else echo "FAIL $1"; failed=1; fi
}
yes_if() { if "$@"; then echo yes; else echo no; fi }
# Whether case $1's client printed (out) or sent on Wayland (traffic) a line matching $2.
out() { grep -q -- "$2" "$work/$1/client.out"; }
traffic() { grep -q -- "$2" "$work/$1/client.err"; }
lacks() { ! traffic "$@"; }
# The grey of the output's centre pixel, from grim's PPM.
centre() {
	WAYLAND_DISPLAY=$WAYLAND_DISPLAY grim -g "640,400 1x1" -t ppm - | tail -c 3 | od -An -tu1 | awk '{print $1}'
}
near() { [ "$1" -ge $(($2 - $3)) ] && [ "$1" -le $(($2 + $3)) ]; }

run_case() { # name, rule actions, extra env[, app_id pattern]
	name=$1 actions=$2 extra=$3 pattern=${4:-^(steam_app_4242)\$}
	case_dir="$work/$name"
	mkdir -m 700 -p "$case_dir/rt"
	mkdir -p "$case_dir/cfg/zoolander"
	cat > "$case_dir/cfg/zoolander/init.lua" <<EOF
zl.output_rule({ output = "Virtual-1", width = 1280, height = 800, refresh = 60, scale = 1 })
zl.add_window_rule("app_id", "$pattern", { $actions })
zl.on("startup", function() zl.exec_command('env > "\$XDG_RUNTIME_DIR/child-env.tmp" && mv "\$XDG_RUNTIME_DIR/child-env.tmp" "\$XDG_RUNTIME_DIR/child-env"') end)
EOF
	XDG_RUNTIME_DIR="$case_dir/rt" XDG_CONFIG_HOME="$case_dir/cfg" "$bin" > "$case_dir/zoolander.log" 2>&1 &
	pid=$!
	for _ in $(seq 100); do test -f "$case_dir/rt/child-env" && break; sleep 0.1; done
	env_of() { sed -n "s/^$1=//p" "$case_dir/rt/child-env"; }
	check "$name: children get ZOOLANDER_WSI=1" "$(yes_if [ "$(env_of ZOOLANDER_WSI)" = 1 ])"
	export XDG_RUNTIME_DIR="$case_dir/rt" WAYLAND_DISPLAY="$(env_of WAYLAND_DISPLAY)"
	# eval, so an extra variable may quote a value with spaces.
	eval "env DISPLAY=\"$(env_of DISPLAY)\" XAUTHORITY=\"$(env_of XAUTHORITY)\" ZOOLANDER_WSI=1 SteamAppId=4242 \
		VK_ADD_IMPLICIT_LAYER_PATH=\"$work/layers\" WAYLAND_DEBUG=client $extra \
		\"$work/client\"" > "$case_dir/client.out" 2> "$case_dir/client.err" &
	client=$!
	for _ in $(seq 100); do grep -q PRESENTING "$case_dir/client.out" 2> /dev/null && break; sleep 0.1; done
	# Past the fullscreen resize and its new swapchain.
	sleep 2
	grey=$(centre || echo 0)
	wait "$client" || true
	kill "$pid" 2> /dev/null || true
	wait "$pid" 2> /dev/null || true
	unset XDG_RUNTIME_DIR WAYLAND_DISPLAY
	if grep -q panic "$case_dir/zoolander.log"; then check "$name: compositor without panic" no; fi
	cat "$case_dir/client.out"
	echo "centre grey: $grey"
}

run_case hdr "force_game_hdr = true, fullscreen = true" ""
check "hdr: DXVK_HDR set before the game reads it" "$(yes_if out hdr '^DXVK_HDR=1$')"
check "hdr: X11 surface offers HDR10 ST2084" "$(yes_if out hdr '^HDR10=1')"
check "hdr: HDR10 swapchain created" "$(yes_if out hdr 'colorspace=1000104008 .*result=0$')"
check "hdr: content goes through the bypass wl_surface" "$(yes_if traffic hdr 'zoolander_xwayland_bypass_window_v1#[0-9]*\.set_content')"
check "hdr: the bypass surface is tagged PQ" "$(yes_if traffic hdr 'wp_color_management_surface_v1#[0-9]*\.set_image_description')"
check "hdr: PQ 0.439 shows converted to SDR (0xbe)" "$(yes_if near "$grey" 190 4)"
check "hdr: client ran to the end" "$(yes_if out hdr '^DONE$')"

run_case hdr_off_in_game "force_game_hdr = true, fullscreen = true" "WSI_CLIENT_SDR=1"
check "hdr_off_in_game: sRGB swapchain created" "$(yes_if out hdr_off_in_game 'colorspace=0 .*result=0$')"
check "hdr_off_in_game: content goes through the bypass wl_surface" "$(yes_if traffic hdr_off_in_game '\.set_content')"
check "hdr_off_in_game: sRGB content shows 0x70" "$(yes_if near "$grey" 112 2)"

# War Thunder's case: a native game that picks its swapchain before its window maps, matched by the
# exact class the user's rule names.
run_case early "force_game_hdr = true, fullscreen = true" \
	"WSI_CLIENT_EARLY=1 WSI_CLIENT_CLASS='War Thunder (Vulkan, 64bit)' ZOOLANDER_WSI_DEBUG=\$case_dir/wsi.log" \
	"War Thunder (Vulkan, 64bit)"
check "early: HDR10 offered before the window maps" "$(yes_if out early '^HDR10=1')"
check "early: HDR10 swapchain created before the window maps" "$(yes_if out early 'colorspace=1000104008 .*result=0$')"
check "early: content goes through the bypass wl_surface" "$(yes_if traffic early '\.set_content')"
check "early: PQ 0.439 shows converted to SDR (0xbe)" "$(yes_if near "$grey" 190 4)"
check "early: client ran to the end" "$(yes_if out early '^DONE$')"
logged() { grep -q -- "$1" "$work/early/wsi.log"; }
check "early: debug log shows HDR10 offered" "$(yes_if logged 'formats from the Wayland surface, HDR10 offered')"
check "early: debug log shows the bypass swapchain" "$(yes_if logged 'colour space 1000104008 .* on the Wayland surface: 0')"

run_case sdr "fullscreen = true" ""
check "sdr: DXVK_HDR left unset" "$(yes_if out sdr '^DXVK_HDR=unset$')"
check "sdr: no HDR10 formats" "$(yes_if out sdr '^HDR10=0')"
check "sdr: sRGB swapchain created" "$(yes_if out sdr 'colorspace=0 .*result=0$')"
check "sdr: no bypass surface" "$(yes_if lacks sdr 'set_content')"
check "sdr: X11 presentation shows 0x70" "$(yes_if near "$grey" 112 2)"
check "sdr: client ran to the end" "$(yes_if out sdr '^DONE$')"

run_case disabled "force_game_hdr = true, fullscreen = true" "ZOOLANDER_WSI_DISABLE=1"
check "disabled: the loader skips the layer" "$(yes_if lacks disabled 'zoolander_xwayland_bypass')"
check "disabled: no HDR10 formats" "$(yes_if out disabled '^HDR10=0')"
check "disabled: X11 presentation shows 0x70" "$(yes_if near "$grey" 112 2)"

if [ "$failed" -ne 0 ]; then
	echo "logs kept in $work"
	exit 1
fi
rm -rf "$work"
