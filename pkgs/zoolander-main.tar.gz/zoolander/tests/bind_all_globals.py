#!/usr/bin/env python3
"""Bind every global zoolander advertises, at its advertised version, then
require a clean wl_display.sync round trip.

Run against a live compositor: WAYLAND_DISPLAY (and XDG_RUNTIME_DIR) must
point at it. Exits non-zero if the compositor posts an error, drops the
connection, or never answers the sync.
"""
import array
import os
import socket
import struct
import sys

DISPLAY, REGISTRY = 1, 2


def message(obj, opcode, payload):
    return struct.pack("<II", obj, (8 + len(payload)) << 16 | opcode) + payload


def string(text):
    raw = text.encode() + b"\0"
    return struct.pack("<I", len(raw)) + raw + b"\0" * (-len(raw) % 4)


def read_string(body, at):
    (size,) = struct.unpack_from("<I", body, at)
    return body[at + 4:at + 3 + size].decode(), at + 4 + size + (-size % 4)


class Connection:
    def __init__(self):
        path = os.path.join(os.environ["XDG_RUNTIME_DIR"], os.environ.get("WAYLAND_DISPLAY", "wayland-0"))
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(5)
        self.sock.connect(path)
        self.buffer = b""

    def send(self, data):
        self.sock.sendall(data)

    def events(self):
        while True:
            while len(self.buffer) >= 8:
                obj, word = struct.unpack_from("<II", self.buffer)
                size = word >> 16
                if len(self.buffer) < size:
                    break
                body, self.buffer = self.buffer[8:size], self.buffer[size:]
                yield obj, word & 0xFFFF, body
            fds = array.array("i")
            data, ancillary, _, _ = self.sock.recvmsg(65536, socket.CMSG_SPACE(28 * fds.itemsize))
            for level, kind, payload in ancillary:
                if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                    fds.frombytes(payload[:len(payload) - len(payload) % fds.itemsize])
            for fd in fds:
                os.close(fd)
            if not data:
                raise ConnectionError("compositor closed the connection")
            self.buffer += data

    def roundtrip(self, callback, on_event):
        self.send(message(DISPLAY, 0, struct.pack("<I", callback)))
        for obj, opcode, body in self.events():
            if obj == DISPLAY and opcode == 0:
                failed, code = struct.unpack_from("<II", body)
                text, _ = read_string(body, 8)
                raise RuntimeError(f"protocol error on object {failed} code {code}: {text}")
            if obj == callback and opcode == 0:
                return
            on_event(obj, opcode, body)


def main():
    conn = Connection()
    globals_ = []

    def collect(obj, opcode, body):
        if obj == REGISTRY and opcode == 0:
            (name,) = struct.unpack_from("<I", body)
            interface, at = read_string(body, 4)
            (version,) = struct.unpack_from("<I", body, at)
            globals_.append((name, interface, version))

    conn.send(message(DISPLAY, 1, struct.pack("<I", REGISTRY)))
    conn.roundtrip(3, collect)
    if not globals_:
        raise RuntimeError("compositor advertised no globals")

    next_id = 4
    for name, interface, version in globals_:
        conn.send(message(REGISTRY, 0, struct.pack("<I", name) + string(interface) + struct.pack("<II", version, next_id)))
        next_id += 1
    conn.roundtrip(next_id, lambda *_: None)
    print(f"bound {len(globals_)} globals: " + " ".join(f"{i}@{v}" for _, i, v in globals_))


if __name__ == "__main__":
    try:
        main()
    except Exception as err:
        print(f"FAIL: {err}", file=sys.stderr)
        sys.exit(1)
