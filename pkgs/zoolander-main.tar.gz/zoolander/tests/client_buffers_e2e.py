#!/usr/bin/env python3
"""GPU-style client buffers against a live compositor, without a GPU.

A software-rendered compositor only ever sees shm buffers that are ready the moment they are
committed. Real clients hand it dma-bufs whose rendering may still be running, guarded by an
implicit fence on the dma-buf or by explicit-sync (linux-drm-syncobj) timeline points. vgem stands
in for the GPU here: its buffers are linear dma-bufs the software renderer can read, and its fences
are signalled by hand. Each case checks that every frame reaches the screen (zwlr_screencopy),
that frame callbacks keep coming, and that the client is never left waiting:

  implicit-later      the fence signals after the commit
  implicit-before     the fence has signalled when the commit arrives
  implicit-reorder    three frames in flight, fences signalled out of order
  explicit-later      acquire points signal after the commit
  explicit-before     acquire points have signalled when the commit arrives
  fifo                a client paced by frame callbacks keeps producing frames for 3 seconds
  resize              a maximize configure acked with a new buffer size, then plain frames

With direct scanout on (scanout_e2e.lua), the scanout cases check what `zoolanderctl monitors` reports
(a buffer the KMS driver refuses counts as reaching the plane: the compositor let it through):

  scanout-plain       a fullscreen dma-buf goes straight to the plane
  scanout-tagged-own  so does one tagged with the output's own encoding
  scanout-tagged-other  one tagged with another encoding composites, for its colour
  scanout-no-plane-colour  without a plane colour pipeline (virtio-gpu, vkms) nothing claims one,
                      nothing is converted on the plane, and other encodings still composite

Run against a live compositor: WAYLAND_DISPLAY and XDG_RUNTIME_DIR must point at it. Needs vgem
loaded with its card node usable by this user and /dev/dri/renderD128 for timelines; anything
missing is a failure, never a skip.

  client_buffers_e2e.py [CASE...]
"""
import array
import fcntl
import json
import mmap
import os
import socket
import struct
import sys
import time

DISPLAY, REGISTRY = 1, 2
XRGB8888 = 0x34325258
SHM_XRGB8888 = 1


def message(obj, opcode, payload=b""):
    return struct.pack("<II", obj, (8 + len(payload)) << 16 | opcode) + payload


def string(text):
    raw = text.encode() + b"\0"
    return struct.pack("<I", len(raw)) + raw + b"\0" * (-len(raw) % 4)


def read_string(body, at):
    (size,) = struct.unpack_from("<I", body, at)
    return body[at + 4:at + 3 + size].decode(), at + 4 + size + (-size % 4)


def ioc(direction, kind, nr, size):
    return direction << 30 | size << 16 | ord(kind) << 8 | nr


def iowr(nr, size, kind="d"):
    return ioc(3, kind, nr, size)


SYNCOBJ_CREATE = iowr(0xBF, 8)
SYNCOBJ_HANDLE_TO_FD = iowr(0xC1, 16)
SYNCOBJ_FD_TO_HANDLE = iowr(0xC2, 16)
SYNCOBJ_TRANSFER = iowr(0xCC, 32)
SYNCOBJ_QUERY = iowr(0xCB, 24)
VERSION = iowr(0x00, 64)
MODE_CREATE_DUMB = iowr(0xB2, 32)
PRIME_HANDLE_TO_FD = iowr(0x2D, 12)
VGEM_FENCE_ATTACH = iowr(0x41, 16)
VGEM_FENCE_SIGNAL = ioc(1, "d", 0x42, 8)
DMA_BUF_EXPORT_SYNC_FILE = iowr(0x02, 8, "b")


def ioctl(fd, request, fmt, *values):
    data = bytearray(struct.pack(fmt, *values))
    fcntl.ioctl(fd, request, data)
    return struct.unpack(fmt, data)


class Missing(Exception):
    pass


def open_vgem():
    for name in sorted(os.listdir("/dev/dri")):
        if not name.startswith("card"):
            continue
        try:
            fd = os.open(f"/dev/dri/{name}", os.O_RDWR | os.O_CLOEXEC)
        except OSError:
            continue
        name_buf = array.array("b", bytes(16))
        data = bytearray(struct.pack("<iiiiQQQQQQ", 0, 0, 0, 0, len(name_buf), name_buf.buffer_info()[0], 0, 0, 0, 0))
        try:
            fcntl.ioctl(fd, VERSION, data)
        except OSError:
            os.close(fd)
            continue
        if name_buf.tobytes().split(b"\0")[0] == b"vgem":
            return fd
        os.close(fd)
    raise Missing("no usable vgem card node: load vgem and give this user access to it (see vm/ provisioning)")


class Gpu:
    """vgem buffers and fences, and DRM timelines on the render node."""

    def __init__(self):
        self.vgem = open_vgem()
        try:
            self.drm = os.open("/dev/dri/renderD128", os.O_RDWR | os.O_CLOEXEC)
        except OSError as err:
            raise Missing(f"no /dev/dri/renderD128 for timelines: {err}") from None

    def buffer(self, width, height):
        _, _, _, _, handle, pitch, size = ioctl(self.vgem, MODE_CREATE_DUMB, "<IIIIIIQ", height, width, 32, 0, 0, 0, 0)
        fd = ioctl(self.vgem, PRIME_HANDLE_TO_FD, "<IIi", handle, os.O_CLOEXEC | os.O_RDWR, -1)[2]
        return Bo(self, handle, fd, pitch, size, width, height)

    def fence(self, bo):
        """An unfinished GPU write into `bo`; returns its fence id."""
        return ioctl(self.vgem, VGEM_FENCE_ATTACH, "<IIII", bo.handle, 1, 0, 0)[2]

    def finish(self, fence):
        ioctl(self.vgem, VGEM_FENCE_SIGNAL, "<II", fence, 0)

    def timeline(self):
        handle = ioctl(self.drm, SYNCOBJ_CREATE, "<II", 0, 0)[0]
        fd = ioctl(self.drm, SYNCOBJ_HANDLE_TO_FD, "<IIiiQ", handle, 0, -1, 0, 0)[2]
        return handle, fd

    def submit(self, bo, timeline, point):
        """Puts an unfinished GPU job on `timeline` at `point`; returns the fence that finishes it."""
        fence = self.fence(bo)
        sync_file = ioctl(bo.fd, DMA_BUF_EXPORT_SYNC_FILE, "<Ii", 3, -1)[1]
        binary = ioctl(self.drm, SYNCOBJ_CREATE, "<II", 0, 0)[0]
        ioctl(self.drm, SYNCOBJ_FD_TO_HANDLE, "<IIiiQ", binary, 1, sync_file, 0, 0)
        os.close(sync_file)
        ioctl(self.drm, SYNCOBJ_TRANSFER, "<IIQQII", binary, timeline, 0, point, 0, 0)
        return fence

    def signalled(self, timeline):
        points = array.array("Q", [0])
        handles = array.array("I", [timeline])
        ioctl(self.drm, SYNCOBJ_QUERY, "<QQII", handles.buffer_info()[0], points.buffer_info()[0], 1, 0)
        return points[0]


class Bo:
    def __init__(self, gpu, handle, fd, pitch, size, width, height):
        self.gpu, self.handle, self.fd, self.pitch = gpu, handle, fd, pitch
        self.width, self.height = width, height
        self.map = mmap.mmap(fd, size, mmap.MAP_SHARED, mmap.PROT_READ | mmap.PROT_WRITE)
        self.wl = None

    def paint(self, color):
        row = struct.pack("<I", color) * self.width
        for y in range(self.height):
            self.map[y * self.pitch:y * self.pitch + len(row)] = row


CLIENTS = []


class Client:
    def __init__(self):
        path = os.path.join(os.environ["XDG_RUNTIME_DIR"], os.environ.get("WAYLAND_DISPLAY", "wayland-0"))
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect(path)
        CLIENTS.append(self)
        self.buffer = b""
        self.next_id = 3
        self.handlers = {}
        self.globals = {}
        self.outputs = []
        self.send(message(DISPLAY, 1, struct.pack("<I", REGISTRY)))
        self.on(REGISTRY, self._global)
        self.roundtrip()
        for interface in ("zwp_linux_dmabuf_v1", "zwlr_screencopy_manager_v1"):
            if interface not in self.globals:
                raise Missing(f"the compositor offers no {interface}")
        self.wm = self.bind("xdg_wm_base", 1)
        self.on(self.wm, lambda op, body: self.send(message(self.wm, 3, body[:4])) if op == 0 else None)
        self.compositor = self.bind("wl_compositor", 4)
        self.shm = self.bind("wl_shm", 1)
        self.dmabuf = self.bind("zwp_linux_dmabuf_v1", 3)
        self.on(self.dmabuf, lambda op, body: None)
        self.screencopy = self.bind("zwlr_screencopy_manager_v1", 3)
        self.output = self.bind_name(self.outputs[0], "wl_output", 1)
        self.on(self.output, lambda op, body: None)
        self.syncobj = self.bind("wp_linux_drm_syncobj_manager_v1", 1) if "wp_linux_drm_syncobj_manager_v1" in self.globals else None
        self.roundtrip()

    def _global(self, opcode, body):
        if opcode != 0:
            return
        (name,) = struct.unpack_from("<I", body)
        interface, at = read_string(body, 4)
        (version,) = struct.unpack_from("<I", body, at)
        self.globals.setdefault(interface, (name, version))
        if interface == "wl_output":
            self.outputs.append(name)

    def new_id(self):
        self.next_id += 1
        return self.next_id - 1

    def on(self, obj, handler):
        self.handlers[obj] = handler

    def send(self, data, fds=()):
        if fds:
            self.sock.sendmsg([data], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array("i", fds))])
        else:
            self.sock.sendall(data)

    def bind_name(self, name, interface, version):
        obj = self.new_id()
        self.send(message(REGISTRY, 0, struct.pack("<I", name) + string(interface) + struct.pack("<II", version, obj)))
        return obj

    def bind(self, interface, version):
        name, advertised = self.globals[interface]
        return self.bind_name(name, interface, min(version, advertised))

    def dispatch(self, timeout):
        self.sock.settimeout(timeout)
        try:
            fds = array.array("i")
            data, ancillary, _, _ = self.sock.recvmsg(65536, socket.CMSG_SPACE(28 * fds.itemsize))
        except socket.timeout:
            return
        for level, kind, payload in ancillary:
            if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                fds.frombytes(payload[:len(payload) - len(payload) % fds.itemsize])
        for fd in fds:
            os.close(fd)
        if not data:
            raise ConnectionError("compositor closed the connection")
        self.buffer += data
        while len(self.buffer) >= 8:
            obj, word = struct.unpack_from("<II", self.buffer)
            size = word >> 16
            if len(self.buffer) < size:
                break
            body, self.buffer = self.buffer[8:size], self.buffer[size:]
            if obj == DISPLAY and word & 0xFFFF == 0:
                failed, code = struct.unpack_from("<II", body)
                raise RuntimeError(f"protocol error on object {failed} code {code}: {read_string(body, 8)[0]}")
            if obj in self.handlers:
                self.handlers[obj](word & 0xFFFF, body)

    def wait(self, done, timeout, what):
        end = time.monotonic() + timeout
        while not done():
            left = end - time.monotonic()
            if left <= 0:
                raise TimeoutError(f"stalled: {what}")
            self.dispatch(left)

    def roundtrip(self):
        callback = self.new_id()
        state = {"done": False}
        self.on(callback, lambda op, body: state.update(done=True))
        self.send(message(DISPLAY, 0, struct.pack("<I", callback)))
        self.wait(lambda: state["done"], 5.0, "roundtrip")

    def wl_buffer(self, bo, fourcc=XRGB8888):
        params = self.new_id()
        self.send(message(self.dmabuf, 1, struct.pack("<I", params)))
        self.send(message(params, 0 + 1, struct.pack("<IIIII", 0, 0, bo.pitch, 0, 0)), [bo.fd])
        buffer = self.new_id()
        self.send(message(params, 3, struct.pack("<IiiII", buffer, bo.width, bo.height, fourcc, 0)))
        self.send(message(params, 0))
        self.on(buffer, lambda op, body: None)
        bo.wl = buffer
        return buffer

    def capture(self):
        """The output's pixels as XRGB words, through zwlr_screencopy into shm."""
        frame = self.new_id()
        info = {}
        self.on(frame, lambda op, body: info.update({op: body}))
        self.send(message(self.screencopy, 0, struct.pack("<IiI", frame, 0, self.output)))
        self.wait(lambda: 6 in info or 3 in info, 5.0, "screencopy buffer info")
        if 3 in info:
            raise RuntimeError("screencopy failed")
        fmt, width, height, stride = struct.unpack_from("<IIII", info[0])
        fd = os.memfd_create("client-buffers-capture")
        os.ftruncate(fd, stride * height)
        pool = self.new_id()
        self.send(message(self.shm, 0, struct.pack("<Ii", pool, stride * height)), [fd])
        buffer = self.new_id()
        self.send(message(pool, 0, struct.pack("<IiiiiI", buffer, 0, width, height, stride, fmt)))
        self.on(buffer, lambda op, body: None)
        self.send(message(frame, 0, struct.pack("<I", buffer)))
        self.wait(lambda: 2 in info or 3 in info, 5.0, "screencopy ready")
        if 3 in info:
            raise RuntimeError("screencopy copy failed")
        data = os.pread(fd, stride * height, 0)
        os.close(fd)
        self.send(message(buffer, 0))
        self.send(message(pool, 1))
        self.send(message(frame, 1))
        return {struct.unpack_from("<I", data, y * stride + x * 4)[0] & 0xFFFFFF
                for y in range(0, height, 4) for x in range(0, width, 4)}


class Window:
    def __init__(self, client, gpu, width, height, explicit):
        self.client, self.gpu = client, gpu
        self.surface = client.new_id()
        client.send(message(client.compositor, 0, struct.pack("<I", self.surface)))
        self.xdg = client.new_id()
        client.send(message(client.wm, 2, struct.pack("<II", self.xdg, self.surface)))
        self.toplevel = client.new_id()
        client.send(message(self.xdg, 1, struct.pack("<I", self.toplevel)))
        client.send(message(self.toplevel, 3, string("client-buffers-e2e")))
        self.serial = None
        self.size = (0, 0)
        client.on(self.xdg, self._configure)
        client.on(self.toplevel, self._toplevel)
        self.sync = None
        if explicit:
            if client.syncobj is None:
                raise Missing("the compositor offers no wp_linux_drm_syncobj_manager_v1")
            self.sync = client.new_id()
            client.send(message(client.syncobj, 1, struct.pack("<II", self.sync, self.surface)))
            self.acquire, self.release = self._timeline(), self._timeline()
        client.send(message(self.surface, 6))
        client.wait(lambda: self.serial is not None, 5.0, "initial configure")
        client.send(message(self.xdg, 4, struct.pack("<I", self.serial)))
        self.serial = None
        self.point = 0
        self.bos = [gpu.buffer(width, height) for _ in range(3)]
        for bo in self.bos:
            client.wl_buffer(bo)

    def _timeline(self):
        handle, fd = self.gpu.timeline()
        proxy = self.client.new_id()
        self.client.send(message(self.client.syncobj, 2, struct.pack("<I", proxy)), [fd])
        os.close(fd)
        return handle, proxy

    def _configure(self, opcode, body):
        if opcode == 0:
            self.serial, = struct.unpack_from("<I", body)

    def _toplevel(self, opcode, body):
        if opcode == 0:
            self.size = struct.unpack_from("<ii", body)

    def commit(self, index, color, finish_before):
        """Draws `color` into buffer `index` behind a GPU fence and commits it; returns the frame
        callback state and the fence still to finish, if any."""
        bo = self.bos[index]
        bo.paint(color)
        c = self.client
        done = {"done": False}
        callback = c.new_id()
        c.on(callback, lambda op, body: done.update(done=True))
        c.send(message(self.surface, 3, struct.pack("<I", callback)))
        c.send(message(self.surface, 1, struct.pack("<Iii", bo.wl, 0, 0)))
        c.send(message(self.surface, 9, struct.pack("<iiii", 0, 0, 0x7FFFFFFF, 0x7FFFFFFF)))
        if self.sync is None:
            fence = self.gpu.fence(bo)
        else:
            self.point += 1
            fence = self.gpu.submit(bo, self.acquire[0], self.point)
            c.send(message(self.sync, 1, struct.pack("<III", self.acquire[1], 0, self.point)))
            c.send(message(self.sync, 2, struct.pack("<III", self.release[1], 0, self.point)))
        if finish_before:
            self.gpu.finish(fence)
            fence = None
        c.send(message(self.surface, 6))
        return done, fence


# Refilled for each case with colours no earlier case drew, so a window left over from one cannot pass for
# another's frame.
COLORS = []


def expect_shown(c, color, what):
    end = time.monotonic() + 3.0
    while color not in (seen := c.capture()):
        if time.monotonic() > end:
            shown = ", ".join(f"{value:06x}" for value in sorted(seen)[:8])
            raise AssertionError(f"{what}: colour {color:06x} never reached the screen (it shows {shown})")
        c.dispatch(0.02)


def frames(explicit, finish_before):
    c, gpu = Client(), Gpu()
    w = Window(c, gpu, 64, 64, explicit)
    for i in range(12):
        done, fence = w.commit(i % 3, COLORS[i], finish_before)
        if fence is not None:
            c.roundtrip()
            assert not done["done"], f"frame {i}: its frame callback came before its fence signalled"
            assert COLORS[i] not in c.capture(), f"frame {i}: shown before its fence signalled"
            gpu.finish(fence)
        c.wait(lambda: done["done"], 3.0, f"frame callback of frame {i}")
        expect_shown(c, COLORS[i], f"frame {i}")
    if explicit:
        c.roundtrip()
        assert gpu.signalled(w.release[0]) >= w.point - 2, "release points stopped being signalled"
    print(f"12 frames shown, every frame callback came ({'explicit' if explicit else 'implicit'}, "
          f"fences {'finished before' if finish_before else 'finished after'} the commit)")


def reorder():
    c, gpu = Client(), Gpu()
    w = Window(c, gpu, 64, 64, False)
    pending = [w.commit(i, COLORS[i], False) for i in range(3)]
    c.roundtrip()
    for i in (0, 2, 1):
        gpu.finish(pending[i][1])
        c.roundtrip()
    for i, (done, _) in enumerate(pending):
        c.wait(lambda: done["done"], 3.0, f"frame callback of frame {i}")
    expect_shown(c, COLORS[2], "newest of three out-of-order frames")
    done, fence = w.commit(0, COLORS[3], False)
    gpu.finish(fence)
    c.wait(lambda: done["done"], 3.0, "frame after the out-of-order ones")
    expect_shown(c, COLORS[3], "frame after the out-of-order ones")
    print("three frames in flight with fences finished out of order: the newest showed, nothing stalled")


def fifo():
    c, gpu = Client(), Gpu()
    w = Window(c, gpu, 64, 64, False)
    end = time.monotonic() + 3.0
    count = 0
    while time.monotonic() < end:
        done, fence = w.commit(count % 3, COLORS[count % len(COLORS)], False)
        c.roundtrip()
        gpu.finish(fence)
        c.wait(lambda: done["done"], 2.0, f"frame callback {count} of the paced loop")
        count += 1
    expect_shown(c, COLORS[(count - 1) % len(COLORS)], "last frame of the paced loop")
    assert count >= 30, f"only {count} frames in 3 seconds"
    print(f"a frame-callback-paced client drew {count} frames in 3 seconds, the last one on screen")


def resize():
    c, gpu = Client(), Gpu()
    w = Window(c, gpu, 64, 64, False)
    done, fence = w.commit(0, COLORS[0], False)
    gpu.finish(fence)
    c.wait(lambda: done["done"], 3.0, "first frame")
    c.send(message(w.toplevel, 9))
    c.wait(lambda: w.serial is not None, 3.0, "maximize configure")
    width, height = w.size
    assert width > 0 and height > 0, f"maximize configure had no size: {w.size}"
    w.bos = [gpu.buffer(width, height) for _ in range(3)]
    for bo in w.bos:
        c.wl_buffer(bo)
    c.send(message(w.xdg, 4, struct.pack("<I", w.serial)))
    for i in range(1, 6):
        done, fence = w.commit(i % 3, COLORS[i], False)
        c.roundtrip()
        gpu.finish(fence)
        c.wait(lambda: done["done"], 3.0, f"frame {i} after the resize")
        expect_shown(c, COLORS[i], f"frame {i} after the resize")
    print(f"resized to {width}x{height} with a new buffer, then 4 plain frames: all shown")


def monitors():
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.settimeout(10)
    sock.connect(os.path.join(os.environ["XDG_RUNTIME_DIR"], f"zoolander-{os.environ.get('WAYLAND_DISPLAY', 'wayland-0')}.sock"))
    sock.sendall(b"monitors-json\n")
    sock.shutdown(socket.SHUT_WR)
    data = b""
    while chunk := sock.recv(1 << 20):
        data += chunk
    sock.close()
    return json.loads(data.decode().split("\n", 2)[2])["outputs"]


def tag(c, surface, tf):
    """Gives `surface` an sRGB-primaries image description with the named transfer `tf`."""
    manager = c.bind("wp_color_manager_v1", 1)
    c.on(manager, lambda op, body: None)
    managed = c.new_id()
    c.send(message(manager, 2, struct.pack("<II", managed, surface)))
    creator = c.new_id()
    c.send(message(manager, 5, struct.pack("<I", creator)))
    c.send(message(creator, 1, struct.pack("<I", tf)))
    c.send(message(creator, 3, struct.pack("<I", 1)))
    description = c.new_id()
    state = {}
    c.on(description, lambda op, body: state.update({op: body}))
    c.send(message(creator, 0, struct.pack("<I", description)))
    c.wait(lambda: state, 5.0, "image description")
    if 0 in state:
        raise RuntimeError(f"image description failed: {read_string(state[0], 4)[0]}")
    c.send(message(managed, 1, struct.pack("<II", description, 0)))


def scanout(fourcc, tf, expected):
    """A fullscreen window showing one opaque dma-buf the size of the mode; `expected` is the block reason
    `zoolanderctl monitors` gives its output, or None for a buffer on the plane."""
    c, gpu = Client(), Gpu()
    w = Window(c, gpu, 64, 64, False)
    c.send(message(w.toplevel, 11, struct.pack("<I", 0)))
    c.wait(lambda: w.serial is not None and w.size[0] > 64, 5.0, "fullscreen configure")
    c.send(message(w.xdg, 4, struct.pack("<I", w.serial)))
    bo = gpu.buffer(*w.size)
    bo.paint(COLORS[0])
    c.wl_buffer(bo, fourcc)
    if tf is not None:
        tag(c, w.surface, tf)
    # virtio-gpu cannot put a vgem buffer on its plane, so in the VM a buffer that passes every gate
    # reaches the backend and comes back rejected; on real KMS it is active.
    want = {"active", "rejected"} if expected is None else {expected}
    end = time.monotonic() + 3.0
    while True:
        # Fresh commits keep repainting, so the first frames' fullscreen animation cannot hold the answer.
        c.send(message(w.surface, 1, struct.pack("<Iii", bo.wl, 0, 0)))
        c.send(message(w.surface, 9, struct.pack("<iiii", 0, 0, 0x7FFFFFFF, 0x7FFFFFFF)))
        c.send(message(w.surface, 6))
        c.roundtrip()
        states = [o["direct_scanout"] for o in monitors() if "direct_scanout" in o]
        seen = ["active" if s["active"] else s["blocked"] for s in states]
        if want & set(seen):
            print(f"  {w.size[0]}x{w.size[1]} fourcc {fourcc:08x}: outputs report {seen}")
            return
        if time.monotonic() > end:
            raise AssertionError(f"expected direct scanout {want}, outputs report {seen}")
        time.sleep(0.05)


CASES = {
    "implicit-later": lambda: frames(False, False),
    "implicit-before": lambda: frames(False, True),
    "implicit-reorder": reorder,
    "explicit-later": lambda: frames(True, False),
    "explicit-before": lambda: frames(True, True),
    "fifo": fifo,
    "resize": resize,
}
def no_plane_colour():
    scanout(XRGB8888, 2, "color")
    states = [o["direct_scanout"] for o in monitors() if "direct_scanout" in o]
    if not states or any(s["plane_color_capable"] or s["converted"] for s in states):
        raise AssertionError(f"expected no plane colour pipeline in use, outputs report {states}")


SCANOUT = {
    "scanout-plain": lambda: scanout(XRGB8888, None, None),
    "scanout-tagged-own": lambda: scanout(XRGB8888, 1, None),
    "scanout-tagged-other": lambda: scanout(XRGB8888, 2, "color"),
    "scanout-no-plane-colour": no_plane_colour,
}


def main():
    names = sys.argv[1:] or list(CASES)
    failed = False
    for n, name in enumerate(names):
        COLORS[:] = [(0x204080 + (n * 64 + i) * 0x010203) & 0xFFFFFF for i in range(64)]
        try:
            (CASES | SCANOUT)[name]()
            print(f"PASS {name}")
        except Missing as err:
            print(f"FAIL {name}: missing facility: {err}")
            failed = True
        except Exception as err:
            print(f"FAIL {name}: {type(err).__name__}: {err}")
            failed = True
        # The next case starts on a screen without this one's windows.
        for client in CLIENTS:
            client.sock.close()
        CLIENTS.clear()
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
