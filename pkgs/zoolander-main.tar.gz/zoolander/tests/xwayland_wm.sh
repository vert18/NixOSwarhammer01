#!/bin/sh
# Starts ZOOLANDER in a throwaway session and runs xwayland_wm.py against it.
# Needs a seat (for example LIBSEAT_BACKEND=seatd), Xwayland and python-xlib.
# usage: xwayland_wm.sh ZOOLANDER [TEST...]
set -eu
bin=${1:?usage: xwayland_wm.sh ZOOLANDER [TEST...]}
shift
here=$(cd "$(dirname "$0")" && pwd)
work=$(mktemp -d)
mkdir -m 700 "$work/rt"
mkdir -p "$work/cfg/zoolander"
cat > "$work/cfg/zoolander/init.lua" <<'EOF'
zl.set_xwayland({ force_zero_scaling = true })
zl.output_rule({ output = "Virtual-1", width = 1280, height = 800, refresh = 60, scale = 2 })
zl.output_rule({ output = "Virtual-2", width = 1280, height = 800, refresh = 60, x = 640, y = 0, scale = 1 })
zl.on("startup", function() zl.exec_command('env > "$XDG_RUNTIME_DIR/child-env.tmp" && mv "$XDG_RUNTIME_DIR/child-env.tmp" "$XDG_RUNTIME_DIR/child-env"') end)
EOF
export XDG_RUNTIME_DIR="$work/rt" XDG_CONFIG_HOME="$work/cfg"
"$bin" > "$work/zoolander.log" 2>&1 &
pid=$!
trap 'kill $pid 2>/dev/null; wait $pid 2>/dev/null; rm -rf "$work"' EXIT
for _ in $(seq 100); do test -f "$work/rt/child-env" && break; sleep 0.1; done
for name in DISPLAY XAUTHORITY WAYLAND_DISPLAY; do
    value=$(sed -n "s/^$name=//p" "$work/rt/child-env")
    test -n "$value" || { echo "zoolander gave children no $name" >&2; cat "$work/zoolander.log" >&2; exit 1; }
    export "$name=$value"
done
python3 "$here/xwayland_wm.py" "$@"
