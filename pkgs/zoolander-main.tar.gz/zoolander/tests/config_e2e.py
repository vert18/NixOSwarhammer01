#!/usr/bin/env python3
"""Config, layout and output-lifecycle behaviour checks against a real
zoolander on the headless backend.

usage: config_e2e.py ZOOLANDER [CASE...]

Each case starts its own compositor with a generated config, drives it over
raw Wayland and the control socket, and checks what `zl.layout_info()`,
`zl.monitor_count()` and the config's own event handlers report. Run it in
the test VM only.
"""
import array
import json
import mmap
import os
import signal
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time

DISPLAY, REGISTRY = 1, 2


def message(obj, opcode, payload=b""):
    return struct.pack("<II", obj, (8 + len(payload)) << 16 | opcode) + payload


def string(text):
    raw = text.encode() + b"\0"
    return struct.pack("<I", len(raw)) + raw + b"\0" * (-len(raw) % 4)


def read_string(body, at):
    (size,) = struct.unpack_from("<I", body, at)
    return body[at + 4:at + 3 + size].decode(), at + 4 + size + (-size % 4)


class Client:
    """One Wayland connection; a reader thread answers pings and configures."""

    def __init__(self, runtime, display):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect(os.path.join(runtime, display))
        self.lock = threading.Lock()
        self.buffer = b""
        self.next_id = REGISTRY
        self.globals = {}
        self.handlers = {}
        self.error = None
        self.callbacks = set()
        self.synced = set()
        self.cond = threading.Condition()
        self.send(message(DISPLAY, 1, struct.pack("<I", REGISTRY)))
        self.handlers[REGISTRY] = self.on_registry
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()
        self.roundtrip()

    def new_id(self):
        self.next_id += 1
        return self.next_id

    def send(self, data, fds=()):
        with self.lock:
            if fds:
                self.sock.sendmsg([data], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array("i", fds))])
            else:
                self.sock.sendall(data)

    def on_registry(self, opcode, body):
        if opcode == 0:
            (name,) = struct.unpack_from("<I", body)
            interface, at = read_string(body, 4)
            (version,) = struct.unpack_from("<I", body, at)
            self.globals[interface] = (name, version)

    def bind(self, interface, version):
        name, advertised = self.globals[interface]
        obj = self.new_id()
        version = min(version, advertised)
        self.send(message(REGISTRY, 0, struct.pack("<I", name) + string(interface) + struct.pack("<II", version, obj)))
        return obj

    def run(self):
        try:
            while True:
                data, ancillary, _, _ = self.sock.recvmsg(65536, socket.CMSG_SPACE(28 * 4))
                for level, kind, payload in ancillary:
                    if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                        fds = array.array("i")
                        fds.frombytes(payload[:len(payload) - len(payload) % 4])
                        for fd in fds:
                            os.close(fd)
                if not data:
                    raise ConnectionError("compositor closed the connection")
                self.buffer += data
                while len(self.buffer) >= 8:
                    obj, word = struct.unpack_from("<II", self.buffer)
                    size = word >> 16
                    if len(self.buffer) < size:
                        break
                    body, self.buffer = self.buffer[8:size], self.buffer[size:]
                    self.dispatch(obj, word & 0xFFFF, body)
        except (OSError, ConnectionError) as err:
            with self.cond:
                if self.error is None:
                    self.error = err
                self.cond.notify_all()

    def dispatch(self, obj, opcode, body):
        if obj == DISPLAY and opcode == 0:
            failed, code = struct.unpack_from("<II", body)
            text, _ = read_string(body, 8)
            with self.cond:
                self.error = RuntimeError(f"protocol error on object {failed} code {code}: {text}")
                self.cond.notify_all()
            return
        handler = self.handlers.get(obj)
        if handler:
            handler(opcode, body)
        with self.cond:
            if obj in self.callbacks:
                self.synced.add(obj)
            self.cond.notify_all()

    def roundtrip(self, timeout=5):
        callback = self.new_id()
        self.callbacks.add(callback)
        self.send(message(DISPLAY, 0, struct.pack("<I", callback)))
        self.wait(lambda: callback in self.synced, timeout)

    def wait(self, predicate, timeout=5):
        deadline = time.monotonic() + timeout
        with self.cond:
            while not predicate():
                if self.error:
                    raise self.error
                left = deadline - time.monotonic()
                if left <= 0:
                    raise TimeoutError("timed out waiting for the compositor")
                self.cond.wait(left)

    def close(self):
        self.sock.close()


class Toplevel(Client):
    """An xdg_toplevel showing a 64x64 shm buffer."""

    def __init__(self, runtime, display, title, app_id=None, server_side=False):
        super().__init__(runtime, display)
        self.configures = []
        compositor = self.bind("wl_compositor", 4)
        shm = self.bind("wl_shm", 1)
        self.wm_base = self.bind("xdg_wm_base", 1)
        self.handlers[self.wm_base] = self.on_wm_base
        fd = os.memfd_create("toplevel")
        os.ftruncate(fd, 64 * 64 * 4)
        mmap.mmap(fd, 64 * 64 * 4)[:] = b"\x80" * (64 * 64 * 4)
        pool = self.new_id()
        self.send(message(shm, 0, struct.pack("<Ii", pool, 64 * 64 * 4)), [fd])
        os.close(fd)
        self.buffer_id = self.new_id()
        self.send(message(pool, 0, struct.pack("<Iiiiii", self.buffer_id, 0, 64, 64, 256, 0)))
        self.surface = self.new_id()
        self.send(message(compositor, 0, struct.pack("<I", self.surface)))
        self.xdg_surface = self.new_id()
        self.send(message(self.wm_base, 2, struct.pack("<II", self.xdg_surface, self.surface)))
        self.handlers[self.xdg_surface] = self.on_xdg_surface
        self.toplevel = self.new_id()
        self.send(message(self.xdg_surface, 1, struct.pack("<I", self.toplevel)))
        self.handlers[self.toplevel] = self.on_toplevel
        self.send(message(self.toplevel, 2, string(title)))
        self.send(message(self.toplevel, 3, string(app_id or title)))
        if server_side:
            decorations = self.bind("zxdg_decoration_manager_v1", 1)
            decoration = self.new_id()
            self.send(message(decorations, 1, struct.pack("<II", decoration, self.toplevel)))
            self.send(message(decoration, 1, struct.pack("<I", 2)))
        self.mapped = False
        self.send(message(self.surface, 6))
        self.wait(lambda: self.mapped)
        self.roundtrip()

    def on_wm_base(self, opcode, body):
        if opcode == 0:
            self.send(message(self.wm_base, 3, body[:4]))

    def on_toplevel(self, opcode, body):
        if opcode == 0:
            width, height = struct.unpack_from("<ii", body)
            self.configures.append((width, height))

    def on_xdg_surface(self, opcode, body):
        if opcode != 0:
            return
        self.send(message(self.xdg_surface, 4, body[:4]))
        if not self.mapped:
            self.send(message(self.surface, 1, struct.pack("<Iii", self.buffer_id, 0, 0)))
            self.send(message(self.surface, 2, struct.pack("<iiii", 0, 0, 64, 64)))
        self.send(message(self.surface, 6))
        self.mapped = True


class LayerSurface(Client):
    """A zwlr_layer_surface_v1 on the default output showing an shm buffer of the size it is given."""

    def __init__(self, runtime, display, namespace, layer, anchor, height, exclusive, margin):
        super().__init__(runtime, display)
        compositor = self.bind("wl_compositor", 4)
        shm = self.bind("wl_shm", 1)
        shell = self.bind("zwlr_layer_shell_v1", 4)
        self.size = None
        self.surface = self.new_id()
        self.send(message(compositor, 0, struct.pack("<I", self.surface)))
        self.layer = self.new_id()
        self.handlers[self.layer] = self.on_layer
        self.send(message(shell, 0, struct.pack("<IIII", self.layer, self.surface, 0, layer) + string(namespace)))
        self.send(message(self.layer, 0, struct.pack("<II", 0, height)))
        self.send(message(self.layer, 1, struct.pack("<I", anchor)))
        self.send(message(self.layer, 2, struct.pack("<i", exclusive)))
        self.send(message(self.layer, 3, struct.pack("<iiii", *margin)))
        self.send(message(self.surface, 6))
        self.wait(lambda: self.size is not None)
        width, height = self.size
        fd = os.memfd_create("layer")
        os.ftruncate(fd, width * height * 4)
        pool = self.new_id()
        self.send(message(shm, 0, struct.pack("<Ii", pool, width * height * 4)), [fd])
        os.close(fd)
        buffer = self.new_id()
        self.send(message(pool, 0, struct.pack("<Iiiiii", buffer, 0, width, height, width * 4, 0)))
        self.send(message(self.surface, 1, struct.pack("<Iii", buffer, 0, 0)))
        self.send(message(self.surface, 6))
        self.roundtrip()

    def on_layer(self, opcode, body):
        if opcode == 0:
            serial, width, height = struct.unpack_from("<III", body)
            self.send(message(self.layer, 6, struct.pack("<I", serial)))
            self.size = (width, height)


class OutputManager(Client):
    """zwlr_output_manager_v1: lists heads and disables one."""

    def __init__(self, runtime, display):
        super().__init__(runtime, display)
        self.heads = {}
        self.serial = None
        self.result = None
        self.manager = self.bind("zwlr_output_manager_v1", 1)
        self.handlers[self.manager] = self.on_manager
        self.wait(lambda: self.serial is not None)

    def on_manager(self, opcode, body):
        if opcode == 0:
            (head,) = struct.unpack_from("<I", body)
            self.heads[head] = None
            self.handlers[head] = lambda op, data, head=head: self.on_head(head, op, data)
        elif opcode == 1:
            (self.serial,) = struct.unpack_from("<I", body)

    def on_head(self, head, opcode, body):
        if opcode == 0:
            self.heads[head] = read_string(body, 0)[0]

    def disable(self, name):
        return self.apply({name})

    def apply(self, disabled):
        """Disables the heads named in `disabled` and enables every other one."""
        config = self.new_id()
        self.result = None
        self.handlers[config] = self.on_configuration
        self.send(message(self.manager, 0, struct.pack("<II", config, self.serial)))
        for head, head_name in self.heads.items():
            if head_name in disabled:
                self.send(message(config, 1, struct.pack("<I", head)))
            else:
                self.send(message(config, 0, struct.pack("<II", self.new_id(), head)))
        self.send(message(config, 2))
        self.wait(lambda: self.result is not None)
        return self.result

    def on_configuration(self, opcode, body):
        self.result = ("succeeded", "failed", "cancelled")[opcode]


class Compositor:
    def __init__(self, binary, config, extra_args=()):
        self.dir = tempfile.mkdtemp(prefix="zl-config-e2e-")
        self.runtime = os.path.join(self.dir, "rt")
        os.mkdir(self.runtime, 0o700)
        self.theme = os.path.join(self.dir, "cfg", "otter-shell")
        os.makedirs(self.theme)
        self.config_path = os.path.join(self.dir, "init.lua")
        with open(self.config_path, "w") as f:
            f.write(config.replace("@DIR@", self.dir))
        env = dict(os.environ, XDG_RUNTIME_DIR=self.runtime, XDG_CONFIG_HOME=os.path.join(self.dir, "cfg"), HOME=self.dir)
        env.pop("WAYLAND_DISPLAY", None)
        env.pop("DISPLAY", None)
        self.log = open(os.path.join(self.dir, "compositor.log"), "w")
        self.proc = subprocess.Popen([binary, "--headless", "--headless-size=1280x720", "--headless-size2=1024x768", f"--config={self.config_path}", *extra_args],
                                     env=env, stdout=self.log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 15
        self.display = None
        while time.monotonic() < deadline:
            names = [n for n in os.listdir(self.runtime) if n.startswith("wayland-") and not n.endswith(".lock")]
            control = [n for n in os.listdir(self.runtime) if n.startswith("zoolander-")]
            if names and control:
                self.display = names[0]
                break
            if self.proc.poll() is not None:
                break
            time.sleep(0.1)
        if self.display is None:
            raise RuntimeError("compositor did not start:\n" + self.output())
        self.clients = []

    def output(self):
        self.log.flush()
        with open(self.log.name) as f:
            return f.read()

    def control(self, line):
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(10)
        sock.connect(os.path.join(self.runtime, f"zoolander-{self.display}.sock"))
        sock.sendall(line.encode() + b"\n")
        data = b""
        while data.count(b"\n") < 2:
            chunk = sock.recv(1 << 20)
            if not chunk:
                break
            data += chunk
        sock.close()
        lines = data.decode().split("\n")
        if not lines[0].startswith("ZLCTL") or len(lines) < 2:
            raise RuntimeError(f"bad control reply {data!r}")
        status, _, value = lines[1].partition(" ")
        if status != "OK":
            raise RuntimeError(f"{line}: {lines[1]}")
        return value

    def report(self, command):
        """The status line and the rest of a multi-line reply, read until the compositor closes it."""
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(10)
        sock.connect(os.path.join(self.runtime, f"zoolander-{self.display}.sock"))
        sock.sendall(command.encode() + b"\n")
        sock.shutdown(socket.SHUT_WR)
        data = b""
        while chunk := sock.recv(1 << 20):
            data += chunk
        sock.close()
        _, status, body = data.decode().split("\n", 2)
        return status, body

    def eval(self, lua):
        return self.control("eval " + lua)

    def layout(self):
        return json.loads(self.eval("return zl.layout_info()"))

    def window(self, title, server_side=False):
        client = Toplevel(self.runtime, self.display, title, server_side=server_side)
        self.clients.append(client)
        return client

    def stop(self):
        for client in self.clients:
            client.close()
        alive = self.proc.poll() is None
        if alive:
            self.proc.terminate()
            try:
                self.proc.wait(10)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait()
        self.log.close()
        return alive


def windows(info):
    focus = info.get("focus")
    return [(w["title"], tuple(w["geom"]), w["floating"], w["a"] == focus) for w in info["windows"]]


def settle(comp):
    time.sleep(0.3)
    return comp.layout()


def case_runtime_setter_keeps_layout(comp):
    """A runtime setter re-applies config but keeps each workspace's own layout."""
    for title in ("a", "b", "c"):
        comp.window(title)
    before = settle(comp)
    assert before["layout"] == "master_stack", before["layout"]
    comp.eval("zl.set_dim({ inactive = true, strength = 0.2 })")
    after = settle(comp)
    print(f"  before {before['layout']} {windows(before)}")
    print(f"  after  {after['layout']} {windows(after)}")
    assert after["layout"] == "master_stack", f"layout became {after['layout']}"
    assert windows(after) == windows(before)


def case_reload_keeps_layout(comp):
    """`zoolanderctl reload` of an unchanged config keeps the live layout."""
    for title in ("a", "b", "c"):
        comp.window(title)
    comp.eval("zl.layout('layout_set', 'master_stack')")
    before = settle(comp)
    assert before["layout"] == "master_stack", before["layout"]
    comp.control("reload")
    after = settle(comp)
    print(f"  before {before['layout']} {windows(before)}")
    print(f"  after  {after['layout']} {windows(after)}")
    assert after["layout"] == "master_stack", f"layout became {after['layout']}"
    assert windows(after) == windows(before)


def case_floating_keeps_position(comp):
    """Floating windows keep their position across a config change."""
    comp.window("f")
    comp.eval("zl.move_floating(37, 23)")
    before = settle(comp)
    comp.eval("zl.set_dim({ inactive = true, strength = 0.3 })")
    after = settle(comp)
    print(f"  before {before['layout']} {windows(before)}")
    print(f"  after  {after['layout']} {windows(after)}")
    assert after["layout"] == "floating", f"layout became {after['layout']}"
    assert windows(after) == windows(before)


def case_explicit_layout_adopted(comp):
    """An explicit runtime zl.set_layout still reaches the focused workspace."""
    comp.window("a")
    comp.window("b")
    comp.eval("zl.set_layout('master_stack', 0.6, 1)")
    after = settle(comp)
    print(f"  after  {after['layout']}")
    assert after["layout"] == "master_stack", after["layout"]


def case_floating_layout_maps_on_top(comp):
    """A window that maps unfocused under a floating layout goes on top of the stack."""
    comp.eval("zl.workspace('2')")
    comp.window("c")
    comp.eval("zl.workspace('1')")
    comp.window("b")
    time.sleep(0.3)
    stack = comp.eval("local t = {} for _, w in ipairs(zl.get_windows()) do t[#t + 1] = w.title .. '@' .. w.workspace.name end return table.concat(t, ' ')")
    print(f"  stack, top first: {stack}")
    assert stack == "b@2 c@2", stack


def case_initial_config_runs_detached(comp):
    """Top-level actions in the initial config find no host, as before attach."""
    marker = os.path.join(comp.dir, "marker")
    time.sleep(1)
    exists = os.path.exists(marker)
    result = comp.eval("return tostring(initial_exec)")
    print(f"  marker exists: {exists}, exec_command returned {result}")
    assert not exists
    assert result == "false", result


def case_output_removed_after_removal(comp):
    """output_removed runs once the monitor is gone from the monitor list."""
    before = comp.eval("return zl.monitor_count()")
    manager = OutputManager(comp.runtime, comp.display)
    comp.clients.append(manager)
    names = sorted(n for n in manager.heads.values() if n)
    result = manager.disable(names[-1])
    time.sleep(0.5)
    seen = comp.eval("return tostring(seen)")
    print(f"  monitors before {before}, disabled {names[-1]}: {result}, handler saw {seen}")
    assert result == "succeeded", result
    assert seen == f"1:{names[-1]}", seen


def case_layout_hook_merges_dormant_output(comp):
    """A layout function that merges away the workspace of the parked output it is arranging leaves that output in place."""
    comp.window("a")
    settle(comp)
    assert comp.eval("return tostring(zl.move_window_direction('right'))") == "true"
    settle(comp)
    manager = OutputManager(comp.runtime, comp.display)
    comp.clients.append(manager)
    first, second = sorted(n for n in manager.heads.values() if n)
    # The second output goes last, so with nowhere to send them its windows stay parked in its WM;
    # bringing the first back adopts only the first's own workspaces.
    for disabled in ({first}, {first, second}, {second}):
        result = manager.apply(disabled)
        assert result == "succeeded", f"disabling {sorted(disabled)}: {result}"
        time.sleep(0.3)
    # The setter re-arranges every WM, the dormant one included; its layout function then merges
    # that WM's last workspace into the live "1" and repaints while the arrange still runs.
    comp.eval("armed = true zl.set_dim({ inactive = true, strength = 0.2 })")
    after = settle(comp)
    fired = comp.eval("return tostring(fired)")
    print(f"  merged from the layout function: {fired}, after {after['output']} {windows(after)}")
    assert fired == "true", "the layout function never ran on the dormant output"
    assert [w[0] for w in windows(after)] == ["a"], windows(after)


def case_exit_does_not_wait_for_xwayland(comp):
    """Quitting sends Xwayland SIGTERM and exits without waiting for it."""
    target = os.path.join(comp.dir, "display")
    comp.eval(f'zl.exec_command("echo $DISPLAY > {target}")')
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline and not (os.path.exists(target) and open(target).read().strip()):
        time.sleep(0.1)
    display = open(target).read().strip()
    x11 = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    x11.connect(f"/tmp/.X11-unix/X{display.lstrip(':')}")
    xwayland = None
    deadline = time.monotonic() + 10
    while xwayland is None and time.monotonic() < deadline:
        for pid in filter(str.isdigit, os.listdir("/proc")):
            try:
                stat = open(f"/proc/{pid}/stat").read()
            except OSError:
                continue
            name = stat[stat.index("(") + 1:stat.rindex(")")]
            ppid = int(stat[stat.rindex(")") + 2:].split()[1])
            if name == "Xwayland" and ppid == comp.proc.pid:
                xwayland = int(pid)
        time.sleep(0.1)
    assert xwayland, "Xwayland did not start"
    os.kill(xwayland, signal.SIGSTOP)
    started = time.monotonic()
    try:
        comp.control("quit")
        try:
            comp.proc.wait(10)
        except subprocess.TimeoutExpired:
            pass
        elapsed = time.monotonic() - started
        exited = comp.proc.poll() is not None
        print(f"  Xwayland {xwayland} stopped; compositor exited: {exited} after {elapsed:.1f}s, status {comp.proc.returncode}")
        assert exited, "compositor still waiting for Xwayland"
    finally:
        os.kill(xwayland, signal.SIGKILL)
        x11.close()
        if comp.proc.poll() is None:
            comp.proc.kill()
            comp.proc.wait()


def case_theme_change_keeps_layout(comp):
    """An Otter theme change refreshes decorations without touching layouts."""
    a = comp.window("a", server_side=True)
    comp.window("b", server_side=True)
    before = settle(comp)
    sizes = a.configures[-1]
    for name, text in (("colors.conf", "accent = \"#FF0000\"\n"), ("layout.conf", "window_buttons = :c\n"), ("spacing.conf", "titlebar_height = 40\n")):
        with open(os.path.join(comp.theme, name), "w") as f:
            f.write(text)
    with open(os.path.join(comp.theme, "theme.conf"), "w") as f:
        f.write("colors_path = colors.conf\nlayout_path = layout.conf\nspacing_path = spacing.conf\n")
    time.sleep(1)
    after = comp.layout()
    print(f"  before {before['layout']} a configured {sizes}")
    print(f"  after  {after['layout']} a configured {a.configures[-1]}")
    assert after["layout"] == "master_stack", f"layout became {after['layout']}"
    assert a.configures[-1] != sizes, "theme change sent no new configure"


def case_undo_restores_layout(comp):
    """Undoing a layout switch restores the layout and re-arranges the windows."""
    for title in ("a", "b", "c"):
        comp.window(title)
    before = settle(comp)
    comp.eval("zl.layout('layout_set', 'master_stack')")
    switched = settle(comp)
    result = comp.eval("return zl.layout('undo')")
    after = settle(comp)
    print(f"  before {before['layout']} {windows(before)}")
    print(f"  switched {switched['layout']}, undo {result}")
    print(f"  after  {after['layout']} {windows(after)}")
    assert switched["layout"] == "master_stack" and windows(switched) != windows(before)
    assert result == "done", result
    assert after["layout"] == before["layout"], f"layout stayed {after['layout']}"
    assert windows(after) == windows(before)


def case_rules_refresh_before_arrange(comp):
    """A reload that adds a float rule arranges the remaining tiles around it at once."""
    comp.window("a")
    comp.window("b")
    before = settle(comp)
    with open(comp.config_path, "a") as f:
        f.write('zl.add_window_rule("app_id", "^(a)$", { float = true })\n')
    comp.control("reload")
    after = settle(comp)
    print(f"  before {windows(before)}")
    print(f"  after  {windows(after)}")
    a = next(w for w in after["windows"] if w["title"] == "a")
    b_before = next(w for w in before["windows"] if w["title"] == "b")
    b_after = next(w for w in after["windows"] if w["title"] == "b")
    assert a["floating"], "rule did not float a"
    assert b_after["geom"][2] > b_before["geom"][2], f"b still {b_after['geom']}"


def case_move_window_to_monitor(comp):
    """Moving the only tile right sends it to the next monitor's workspace."""
    comp.window("a")
    before = settle(comp)
    moved = comp.eval("return tostring(zl.move_window_direction('right'))")
    after = settle(comp)
    print(f"  before {before['output']} ws {before['workspace']} {windows(before)}")
    print(f"  moved {moved}, after {after['output']} ws {after['workspace']} {windows(after)}")
    assert moved == "true", moved
    assert after["output"] != before["output"] and after["workspace"] != before["workspace"]
    assert windows(after) == [("a", (0, 0, 1024, 768), False, True)], windows(after)


VIRTUAL_KEYMAP = """xkb_keymap {
xkb_keycodes "v" { minimum = 8; maximum = 255; <AE01> = 10; };
xkb_types "v" { type "ONE_LEVEL" { modifiers = none; level_name[Level1] = "Any"; }; };
xkb_compat "v" { };
xkb_symbols "v" { key <AE01> { [ 1 ] }; };
};
"""


def case_virtual_key_survives_keymap_change(comp):
    """A virtual keyboard holding the largest key code survives the seat keymap changing."""
    client = Client(comp.runtime, comp.display)
    comp.clients.append(client)
    seat = client.bind("wl_seat", 1)
    manager = client.bind("zwp_virtual_keyboard_manager_v1", 1)
    keyboard = client.new_id()
    client.send(message(manager, 0, struct.pack("<II", seat, keyboard)))
    keymap = VIRTUAL_KEYMAP.encode() + b"\0"
    fd = os.memfd_create("virtual-keymap")
    os.write(fd, keymap)
    client.send(message(keyboard, 0, struct.pack("<II", 1, len(keymap))), [fd])
    os.close(fd)
    client.send(message(keyboard, 1, struct.pack("<III", 0, 0xFFFFFFFF, 1)))
    client.roundtrip()
    comp.eval("zl.set_keyboard({ layout = 'gb' })")
    client.roundtrip()


SPATIAL = ("canvas", "lanes", "accordion", "workbench", "pairs", "scrolling", "master_stack", "floating")
GOLDEN = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config_e2e_layouts.json")


def case_monitors_report(comp):
    """`zoolanderctl monitors` reports every output with its mode list."""
    status, report = comp.report("monitors")
    print("  " + status + "\n  " + "\n  ".join(report.split("\n")[:10]))
    assert status == "OK 2 outputs", status
    for size in ("1280x720", "1024x768"):
        assert f"mode: {size} @" in report, f"no {size} output in {report!r}"
        assert f"    {size} @" in report and " current" in report, f"no {size} mode listed in {report!r}"
    for field in ("monitor: make=", "layout: position", "scanout: format", "hdr: capable=", "render colour: transfer"):
        assert report.count(field) == 2, f"{field!r} not reported per output"


def case_clients_and_layers_report(comp):
    """`clients` and `layers` report a mapped window and a bar, as text and as JSON."""
    title = 'say "hi"\t\\ ünïcødé ☃'
    bar = LayerSurface(comp.runtime, comp.display, "e2e-bar", 2, 1 | 4 | 8, 30, 30, (2, 3, 4, 5))
    comp.clients.append(bar)
    comp.clients.append(Toplevel(comp.runtime, comp.display, title, app_id="org.zoo.e2e"))
    info = settle(comp)
    outputs = {o["name"]: o for o in json.loads(comp.report("monitors-json")[1])["outputs"]}
    for command in ("clients", "clients-json", "layers", "layers-json"):
        status, body = comp.report(command)
        print(f"  {command}: {status}\n    " + "\n    ".join(body.rstrip("\n").split("\n")))
    status, body = comp.report("clients")
    assert status == "OK 1 clients", status
    assert '"org.zoo.e2e"' in body and f"pid: {os.getpid()}" in body and "kind: native" in body, body
    status, body = comp.report("clients-json")
    assert status == "OK json" and body.count("\n") == 1, (status, body)
    (window,) = json.loads(body)
    geom = info["windows"][0]["geom"]
    origin = outputs[window["output"]]
    assert window["title"] == title and window["app_id"] == "org.zoo.e2e", window
    assert window["pid"] == os.getpid() and not window["xwayland"], window
    assert window["id"].startswith("zoo-toplevel-") and window["focused"] and not window["floating"], window
    assert window["workspace"] == str(info["workspace"]) and window["output"] == info["output"], (window, info)
    assert [window["x"] - origin["x"], window["y"] - origin["y"], window["width"], window["height"]] == geom, (window, geom)
    status, body = comp.report("layers")
    assert status == "OK 1 layers" and '"e2e-bar"' in body and "  top:" in body and "exclusive zone: 30" in body, (status, body)
    status, body = comp.report("layers-json")
    assert status == "OK json" and body.count("\n") == 1, (status, body)
    (layer,) = json.loads(body)
    origin = outputs[layer["output"]]
    assert layer["namespace"] == "e2e-bar" and layer["layer"] == "top" and layer["pid"] == os.getpid(), layer
    assert layer["exclusive_zone"] == 30 and layer["margin"] == {"top": 2, "right": 3, "bottom": 4, "left": 5}, layer
    assert layer["anchor"] == {"top": True, "bottom": False, "left": True, "right": True} and layer["mapped"], layer
    assert layer["keyboard_interactivity"] == "none", layer
    expected = [origin["x"] + 5, origin["y"] + 2, origin["logical_width"] - 8, 30]
    assert [layer["x"], layer["y"], layer["width"], layer["height"]] == expected, (layer, expected)


def case_layout_dump(comp):
    """Every layout arranges six windows exactly as recorded in config_e2e_layouts.json.

    ZL_RECORD=1 rewrites the file from the build under test."""
    for title in "abcdef":
        comp.window(title)
    dump = {}
    for kind in SPATIAL:
        comp.eval(f"zl.layout('layout_set', '{kind}')")
        info = settle(comp)
        dump[kind] = [[w["title"], w["geom"], w["shown"], w["place"], w["group"], w["order"]] for w in info["windows"]]
        print(f"  {kind}: {dump[kind]}")
    if os.environ.get("ZL_RECORD"):
        with open(GOLDEN, "w") as f:
            json.dump(dump, f, indent=1)
        return
    with open(GOLDEN) as f:
        golden = json.load(f)
    differ = [kind for kind in SPATIAL if dump[kind] != golden[kind]]
    assert not differ, f"layouts differ from the recording: {differ}"


BASE = """
zl.set_layout("dwindle", 0.6, 1)
"""

CASES = {
    "runtime_setter_keeps_layout": (case_runtime_setter_keeps_layout, BASE + 'zl.set_workspace_layout("1", "master_stack", 0.6, 1)\n'),
    "reload_keeps_layout": (case_reload_keeps_layout, BASE),
    "floating_keeps_position": (case_floating_keeps_position, BASE + 'zl.set_workspace_layout("1", "floating", 0.6, 1)\n'),
    "explicit_layout_adopted": (case_explicit_layout_adopted, BASE),
    "floating_layout_maps_on_top": (case_floating_layout_maps_on_top, BASE + 'zl.set_workspace_layout("1", "floating", 0.6, 1)\nzl.add_window_rule("app_id", "^(b)$", { workspace = "2", follow = false })\n'),
    "initial_config_runs_detached": (case_initial_config_runs_detached, BASE + 'initial_exec = zl.exec_command("touch @DIR@/marker")\n'),
    "output_removed_after_removal": (case_output_removed_after_removal, BASE + 'zl.on("output_removed", function(m) seen = zl.monitor_count() .. ":" .. m.name end)\n'),
    "theme_change_keeps_layout": (case_theme_change_keeps_layout, BASE + 'zl.set_workspace_layout("1", "master_stack", 0.6, 1)\nzl.set_ssd({ enabled = true, follow_theme = true, floating_workspaces_only = false })\n'),
    "layout_hook_merges_dormant_output": (case_layout_hook_merges_dormant_output, 'zl.set_layout(function(index, count, width, height)\n'
                                          '    if armed and not fired then fired = true zl.workspace("1") end\n'
                                          'end)\n'),
    "exit_does_not_wait_for_xwayland": (case_exit_does_not_wait_for_xwayland, BASE),
    "undo_restores_layout": (case_undo_restores_layout, BASE),
    "rules_refresh_before_arrange": (case_rules_refresh_before_arrange, BASE),
    "move_window_to_monitor": (case_move_window_to_monitor, BASE),
    "virtual_key_survives_keymap_change": (case_virtual_key_survives_keymap_change, BASE),
    "layout_dump": (case_layout_dump, BASE),
    "monitors_report": (case_monitors_report, BASE),
    "clients_and_layers_report": (case_clients_and_layers_report, BASE),
}


def main():
    binary = sys.argv[1]
    selected = sys.argv[2:] or list(CASES)
    failed = []
    for name in selected:
        run, config = CASES[name]
        comp = Compositor(binary, config)
        print(f"case {name}")
        try:
            run(comp)
        except Exception as err:
            failed.append(name)
            print(f"  FAIL {type(err).__name__}: {err}")
            print("  log: " + comp.output()[-1500:].replace("\n", "\n  log: "))
        finally:
            alive = comp.stop()
            if not alive and name != "exit_does_not_wait_for_xwayland":
                failed.append(name + " (compositor died)")
                print("  compositor died:\n" + comp.output()[-2000:])
    print("FAILED: " + ", ".join(failed) if failed else "all passed")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
