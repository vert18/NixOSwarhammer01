#!/bin/sh
# Starts ZOOLANDER in a throwaway session laid out like a game monitor with a rotated
# second monitor to its right, and runs mouselook_e2e.py against it.
# Runs on the headless backend; needs Xwayland and python-xlib.
# usage: mouselook_e2e.sh ZOOLANDER [TEST...]
set -eu
bin=${1:?usage: mouselook_e2e.sh ZOOLANDER [TEST...]}
shift
here=$(cd "$(dirname "$0")" && pwd)
work=$(mktemp -d)
mkdir -m 700 "$work/rt"
mkdir -p "$work/cfg/zoolander"
cat > "$work/cfg/zoolander/init.lua" <<'EOF'
zl.set_animations_enabled(false)
zl.output_rule({ output = "HEADLESS-1", width = 1280, height = 800, refresh = 60, x = 0, y = 0, scale = 1 })
zl.output_rule({ output = "HEADLESS-2", width = 1280, height = 800, refresh = 60, x = 1280, y = -300, scale = 1, transform = "90" })
zl.add_window_rule("title", "^(mouselook.*)$", { confine_cursor = true, fullscreen = true })
zl.add_window_rule("app_id", "War Thunder (Vulkan, 64bit)", { confine_cursor = true, force_game_hdr = true, fullscreen = true })
zl.on("startup", function() zl.exec_command('env > "$XDG_RUNTIME_DIR/child-env.tmp" && mv "$XDG_RUNTIME_DIR/child-env.tmp" "$XDG_RUNTIME_DIR/child-env"') end)
EOF
# War Thunder stands in as wsi_layer_client.c: an X11 Vulkan game whose HDR frames reach the compositor
# through the WSI layer's bypass surface.
mkdir -p "$work/layers"
(cd "$work" &&
	otr build "$here/../wsi/layer.otr" --release --lib shared -l wayland-client -l xcb -l X11-xcb -o libVkLayer_zoolander_wsi.so > /dev/null &&
	otr run "$here/../wsi/manifest.otr" -- "$work/libVkLayer_zoolander_wsi.so" > "$work/layers/zoolander_wsi.json")
cc -O2 "$here/wsi_layer_client.c" -o "$work/vk-client" -lvulkan -lxcb
export MOUSELOOK_VK_CLIENT="$work/vk-client" MOUSELOOK_VK_LAYERS="$work/layers"
export XDG_RUNTIME_DIR="$work/rt" XDG_CONFIG_HOME="$work/cfg"
"$bin" --headless --headless-size=1280x800 --headless-size2=1280x800 > "$work/zoolander.log" 2>&1 &
pid=$!
trap 'kill $pid 2>/dev/null; wait $pid 2>/dev/null; rm -rf "$work"' EXIT
for _ in $(seq 100); do test -f "$work/rt/child-env" && break; sleep 0.1; done
test -f "$work/rt/child-env" || { echo "zoolander never started its children" >&2; grep -v -e lua-widgets -e otter -e Wallpaper "$work/zoolander.log" | head -n 60 >&2; exit 1; }
for name in DISPLAY XAUTHORITY WAYLAND_DISPLAY; do
    value=$(sed -n "s/^$name=//p" "$work/rt/child-env")
    test -n "$value" || { echo "zoolander gave children no $name" >&2; cat "$work/zoolander.log" >&2; exit 1; }
    export "$name=$value"
done
python3 "$here/mouselook_e2e.py" "$@" >&2 || { status=$?; grep -v -e lua-widgets -e otter -e Wallpaper -e xkbcomp -e "^>" "$work/zoolander.log" | tail -n 40 >&2; exit $status; }
