#!/usr/bin/env python3
"""Real GL and Vulkan clients on the GPU's own driver, against a live compositor.

Their dma-bufs carry the fences of real rendering, implicit or explicit as Mesa chooses, and their
frame pacing is Mesa's: the paths a software run cannot reach. Each client must keep putting new
frames on screen: two captures of the output a second apart must differ, and the client must still
be running. A missing client binary is a failure, never a skip.

  weston-simple-egl   EGL (OpenGL ES), swap interval 1
  vkcube              Vulkan WSI, FIFO

Run inside the AMD test VM through tests/run.sh --vm --gpu.
"""
import os
import shutil
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from client_buffers_e2e import Client  # noqa: E402

CLIENTS = {
    "weston-simple-egl": ["weston-simple-egl"],
    "vkcube": ["vkcube", "--wsi", "wayland"],
}


def run(name, argv):
    if shutil.which(argv[0]) is None:
        raise RuntimeError(f"{argv[0]} is not installed in the test VM")
    proc = subprocess.Popen(argv, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    try:
        c = Client()
        time.sleep(2.0)
        first = c.capture()
        time.sleep(1.0)
        second = c.capture()
        if proc.poll() is not None:
            raise RuntimeError(f"{name} exited with {proc.returncode}: {proc.stderr.read().decode(errors='replace')[-400:]}")
        if len(second) < 8:
            raise AssertionError(f"{name}: the output shows {len(second)} colours, no client content")
        if first == second:
            raise AssertionError(f"{name}: the screen did not change in a second; frames stopped reaching it")
        print(f"{name}: kept drawing ({len(first ^ second)} colours changed in a second)")
    finally:
        proc.terminate()
        proc.wait(5)


def main():
    failed = False
    for name in sys.argv[1:] or list(CLIENTS):
        try:
            run(name, CLIENTS[name])
            print(f"PASS {name}")
        except Exception as err:
            print(f"FAIL {name}: {type(err).__name__}: {err}")
            failed = True
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
