#!/bin/sh
# Regenerates wayland.otr and wayland-tables.h, the layer's libwayland client bindings, with the
# scanner of the otr release the build uses: tools/wayland/scanner.otr of its source tree.
# usage: gen-wayland.sh <otr source tree> [zooland checkout]
set -eu
here=$(cd "$(dirname "$0")" && pwd)
zooland=${2:-$here/../../zooland}
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
otr build "$1/tools/wayland/scanner.otr" -o "$scratch/scanner"
# wl_compositor 4 has wl_surface.damage_buffer, all Mesa's WSI needs, and a cap keeps an older
# compositor's surfaces from receiving events these bindings lack.
"$scratch/scanner" --version wl_compositor=4 --version wl_subcompositor=1 \
    "$here/wayland.otr" /usr/share/wayland/wayland.xml "$zooland/protocols/zoolander-xwayland-bypass-v1.xml"
otr fmt "$here/wayland.otr"
