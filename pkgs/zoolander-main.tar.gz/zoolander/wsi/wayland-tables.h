/* Interface tables for otr's Wayland bindings, written by tools/wayland/scanner.otr. */
#include <stddef.h>
#include <errno.h>
#include <wayland-client-core.h>

static const struct wl_interface otr_wl_display_interface;
static const struct wl_interface otr_wl_registry_interface;
static const struct wl_interface otr_wl_callback_interface;
static const struct wl_interface otr_wl_compositor_interface;
static const struct wl_interface otr_wl_shm_pool_interface;
static const struct wl_interface otr_wl_shm_interface;
static const struct wl_interface otr_wl_buffer_interface;
static const struct wl_interface otr_wl_data_offer_interface;
static const struct wl_interface otr_wl_data_source_interface;
static const struct wl_interface otr_wl_data_device_interface;
static const struct wl_interface otr_wl_data_device_manager_interface;
static const struct wl_interface otr_wl_shell_interface;
static const struct wl_interface otr_wl_shell_surface_interface;
static const struct wl_interface otr_wl_surface_interface;
static const struct wl_interface otr_wl_seat_interface;
static const struct wl_interface otr_wl_pointer_interface;
static const struct wl_interface otr_wl_keyboard_interface;
static const struct wl_interface otr_wl_touch_interface;
static const struct wl_interface otr_wl_output_interface;
static const struct wl_interface otr_wl_region_interface;
static const struct wl_interface otr_wl_subcompositor_interface;
static const struct wl_interface otr_wl_subsurface_interface;
static const struct wl_interface otr_wl_fixes_interface;
static const struct wl_interface otr_zoolander_xwayland_bypass_manager_v1_interface;
static const struct wl_interface otr_zoolander_xwayland_bypass_app_v1_interface;
static const struct wl_interface otr_zoolander_xwayland_bypass_window_v1_interface;
static const struct wl_interface *otr_types_0[] = { &otr_wl_callback_interface,  };
static const struct wl_interface *otr_types_1[] = { &otr_wl_registry_interface,  };
static const struct wl_interface *otr_types_2[] = { NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_3[] = { NULL,  };
static const struct wl_interface *otr_types_4[] = { NULL, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_5[] = { NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_6[] = { NULL,  };
static const struct wl_interface *otr_types_7[] = { NULL,  };
static const struct wl_interface *otr_types_8[] = { &otr_wl_surface_interface,  };
static const struct wl_interface *otr_types_9[] = { &otr_wl_region_interface,  };
static const struct wl_interface *otr_types_10[] = { NULL };
static const struct wl_interface *otr_types_11[] = { &otr_wl_buffer_interface, NULL, NULL, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_12[] = { NULL };
static const struct wl_interface *otr_types_13[] = { NULL,  };
static const struct wl_interface *otr_types_14[] = { &otr_wl_shm_pool_interface, NULL, NULL,  };
static const struct wl_interface *otr_types_15[] = { NULL,  };
static const struct wl_interface *otr_types_16[] = { NULL };
static const struct wl_interface *otr_types_17[] = { NULL };
static const struct wl_interface *otr_types_18[] = { NULL };
static const struct wl_interface *otr_types_19[] = { NULL, NULL,  };
static const struct wl_interface *otr_types_20[] = { NULL, NULL,  };
static const struct wl_interface *otr_types_21[] = { NULL };
static const struct wl_interface *otr_types_22[] = { NULL,  };
static const struct wl_interface *otr_types_23[] = { NULL };
static const struct wl_interface *otr_types_24[] = { NULL, NULL,  };
static const struct wl_interface *otr_types_25[] = { NULL,  };
static const struct wl_interface *otr_types_26[] = { NULL,  };
static const struct wl_interface *otr_types_27[] = { NULL,  };
static const struct wl_interface *otr_types_28[] = { NULL };
static const struct wl_interface *otr_types_29[] = { NULL,  };
static const struct wl_interface *otr_types_30[] = { NULL, NULL,  };
static const struct wl_interface *otr_types_31[] = { NULL };
static const struct wl_interface *otr_types_32[] = { NULL,  };
static const struct wl_interface *otr_types_33[] = { NULL };
static const struct wl_interface *otr_types_34[] = { NULL };
static const struct wl_interface *otr_types_35[] = { NULL,  };
static const struct wl_interface *otr_types_36[] = { &otr_wl_data_source_interface, &otr_wl_surface_interface, &otr_wl_surface_interface, NULL,  };
static const struct wl_interface *otr_types_37[] = { &otr_wl_data_source_interface, NULL,  };
static const struct wl_interface *otr_types_38[] = { &otr_wl_data_offer_interface,  };
static const struct wl_interface *otr_types_39[] = { NULL, &otr_wl_surface_interface, NULL, NULL, &otr_wl_data_offer_interface,  };
static const struct wl_interface *otr_types_40[] = { NULL };
static const struct wl_interface *otr_types_41[] = { NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_42[] = { NULL };
static const struct wl_interface *otr_types_43[] = { &otr_wl_data_offer_interface,  };
static const struct wl_interface *otr_types_44[] = { NULL };
static const struct wl_interface *otr_types_45[] = { &otr_wl_data_source_interface,  };
static const struct wl_interface *otr_types_46[] = { &otr_wl_data_device_interface, &otr_wl_seat_interface,  };
static const struct wl_interface *otr_types_47[] = { NULL };
static const struct wl_interface *otr_types_48[] = { &otr_wl_shell_surface_interface, &otr_wl_surface_interface,  };
static const struct wl_interface *otr_types_49[] = { NULL,  };
static const struct wl_interface *otr_types_50[] = { &otr_wl_seat_interface, NULL,  };
static const struct wl_interface *otr_types_51[] = { &otr_wl_seat_interface, NULL, NULL,  };
static const struct wl_interface *otr_types_52[] = { NULL };
static const struct wl_interface *otr_types_53[] = { &otr_wl_surface_interface, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_54[] = { NULL, NULL, &otr_wl_output_interface,  };
static const struct wl_interface *otr_types_55[] = { &otr_wl_seat_interface, NULL, &otr_wl_surface_interface, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_56[] = { &otr_wl_output_interface,  };
static const struct wl_interface *otr_types_57[] = { NULL,  };
static const struct wl_interface *otr_types_58[] = { NULL,  };
static const struct wl_interface *otr_types_59[] = { NULL,  };
static const struct wl_interface *otr_types_60[] = { NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_61[] = { NULL };
static const struct wl_interface *otr_types_62[] = { NULL };
static const struct wl_interface *otr_types_63[] = { &otr_wl_buffer_interface, NULL, NULL,  };
static const struct wl_interface *otr_types_64[] = { NULL, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_65[] = { &otr_wl_callback_interface,  };
static const struct wl_interface *otr_types_66[] = { &otr_wl_region_interface,  };
static const struct wl_interface *otr_types_67[] = { &otr_wl_region_interface,  };
static const struct wl_interface *otr_types_68[] = { NULL };
static const struct wl_interface *otr_types_69[] = { &otr_wl_output_interface,  };
static const struct wl_interface *otr_types_70[] = { &otr_wl_output_interface,  };
static const struct wl_interface *otr_types_71[] = { NULL,  };
static const struct wl_interface *otr_types_72[] = { NULL,  };
static const struct wl_interface *otr_types_73[] = { NULL, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_74[] = { NULL, NULL,  };
static const struct wl_interface *otr_types_75[] = { NULL,  };
static const struct wl_interface *otr_types_76[] = { NULL,  };
static const struct wl_interface *otr_types_77[] = { &otr_wl_callback_interface,  };
static const struct wl_interface *otr_types_78[] = { NULL,  };
static const struct wl_interface *otr_types_79[] = { &otr_wl_pointer_interface,  };
static const struct wl_interface *otr_types_80[] = { &otr_wl_keyboard_interface,  };
static const struct wl_interface *otr_types_81[] = { &otr_wl_touch_interface,  };
static const struct wl_interface *otr_types_82[] = { NULL,  };
static const struct wl_interface *otr_types_83[] = { NULL };
static const struct wl_interface *otr_types_84[] = { NULL, &otr_wl_surface_interface, NULL, NULL,  };
static const struct wl_interface *otr_types_85[] = { NULL, &otr_wl_surface_interface, NULL, NULL,  };
static const struct wl_interface *otr_types_86[] = { NULL, &otr_wl_surface_interface,  };
static const struct wl_interface *otr_types_87[] = { NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_88[] = { NULL, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_89[] = { NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_90[] = { NULL };
static const struct wl_interface *otr_types_91[] = { NULL };
static const struct wl_interface *otr_types_92[] = { NULL,  };
static const struct wl_interface *otr_types_93[] = { NULL, NULL,  };
static const struct wl_interface *otr_types_94[] = { NULL, NULL,  };
static const struct wl_interface *otr_types_95[] = { NULL, NULL,  };
static const struct wl_interface *otr_types_96[] = { NULL, NULL,  };
static const struct wl_interface *otr_types_97[] = { NULL, NULL,  };
static const struct wl_interface *otr_types_98[] = { NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_99[] = { NULL, &otr_wl_surface_interface, NULL,  };
static const struct wl_interface *otr_types_100[] = { NULL, &otr_wl_surface_interface,  };
static const struct wl_interface *otr_types_101[] = { NULL, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_102[] = { NULL, NULL, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_103[] = { NULL };
static const struct wl_interface *otr_types_104[] = { NULL, NULL,  };
static const struct wl_interface *otr_types_105[] = { NULL, NULL, &otr_wl_surface_interface, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_106[] = { NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_107[] = { NULL, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_108[] = { NULL };
static const struct wl_interface *otr_types_109[] = { NULL };
static const struct wl_interface *otr_types_110[] = { NULL };
static const struct wl_interface *otr_types_111[] = { NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_112[] = { NULL, NULL,  };
static const struct wl_interface *otr_types_113[] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_114[] = { NULL, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_115[] = { NULL };
static const struct wl_interface *otr_types_116[] = { NULL,  };
static const struct wl_interface *otr_types_117[] = { NULL };
static const struct wl_interface *otr_types_118[] = { NULL,  };
static const struct wl_interface *otr_types_119[] = { NULL,  };
static const struct wl_interface *otr_types_120[] = { NULL };
static const struct wl_interface *otr_types_121[] = { NULL, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_122[] = { NULL, NULL, NULL, NULL,  };
static const struct wl_interface *otr_types_123[] = { NULL };
static const struct wl_interface *otr_types_124[] = { &otr_wl_subsurface_interface, &otr_wl_surface_interface, &otr_wl_surface_interface,  };
static const struct wl_interface *otr_types_125[] = { NULL };
static const struct wl_interface *otr_types_126[] = { NULL, NULL,  };
static const struct wl_interface *otr_types_127[] = { &otr_wl_surface_interface,  };
static const struct wl_interface *otr_types_128[] = { &otr_wl_surface_interface,  };
static const struct wl_interface *otr_types_129[] = { NULL };
static const struct wl_interface *otr_types_130[] = { NULL };
static const struct wl_interface *otr_types_131[] = { NULL };
static const struct wl_interface *otr_types_132[] = { &otr_wl_registry_interface,  };
static const struct wl_interface *otr_types_133[] = { &otr_wl_registry_interface, NULL,  };
static const struct wl_interface *otr_types_134[] = { NULL };
static const struct wl_interface *otr_types_135[] = { &otr_zoolander_xwayland_bypass_window_v1_interface, NULL,  };
static const struct wl_interface *otr_types_136[] = { &otr_zoolander_xwayland_bypass_app_v1_interface, NULL, NULL,  };
static const struct wl_interface *otr_types_137[] = { NULL,  };
static const struct wl_interface *otr_types_138[] = { NULL };
static const struct wl_interface *otr_types_139[] = { NULL,  };
static const struct wl_interface *otr_types_140[] = { &otr_wl_subsurface_interface, &otr_wl_surface_interface, NULL, NULL,  };
static const struct wl_interface *otr_types_141[] = { NULL };
static const struct wl_message otr_wl_display_requests[] = {
    { "sync", "n", otr_types_0 },
    { "get_registry", "n", otr_types_1 },
};
static const struct wl_message otr_wl_display_events[] = {
    { "error", "ous", otr_types_2 },
    { "delete_id", "u", otr_types_3 },
};
static const struct wl_interface otr_wl_display_interface = { "wl_display", 1, 2, otr_wl_display_requests, 2, otr_wl_display_events };
static inline const struct wl_interface *otr_iface_wl_display(void) { return &otr_wl_display_interface; }

static const struct wl_message otr_wl_registry_requests[] = {
    { "bind", "usun", otr_types_4 },
};
static const struct wl_message otr_wl_registry_events[] = {
    { "global", "usu", otr_types_5 },
    { "global_remove", "u", otr_types_6 },
};
static const struct wl_interface otr_wl_registry_interface = { "wl_registry", 1, 1, otr_wl_registry_requests, 2, otr_wl_registry_events };
static inline const struct wl_interface *otr_iface_wl_registry(void) { return &otr_wl_registry_interface; }

static const struct wl_message otr_wl_callback_requests[] = {
    { NULL, NULL, NULL },
};
static const struct wl_message otr_wl_callback_events[] = {
    { "done", "u", otr_types_7 },
};
static const struct wl_interface otr_wl_callback_interface = { "wl_callback", 1, 0, otr_wl_callback_requests, 1, otr_wl_callback_events };
static inline const struct wl_interface *otr_iface_wl_callback(void) { return &otr_wl_callback_interface; }

static const struct wl_message otr_wl_compositor_requests[] = {
    { "create_surface", "n", otr_types_8 },
    { "create_region", "n", otr_types_9 },
};
static const struct wl_message otr_wl_compositor_events[] = {
    { NULL, NULL, NULL },
};
static const struct wl_interface otr_wl_compositor_interface = { "wl_compositor", 4, 2, otr_wl_compositor_requests, 0, otr_wl_compositor_events };
static inline const struct wl_interface *otr_iface_wl_compositor(void) { return &otr_wl_compositor_interface; }

static const struct wl_message otr_wl_shm_pool_requests[] = {
    { "create_buffer", "niiiiu", otr_types_11 },
    { "destroy", "", otr_types_12 },
    { "resize", "i", otr_types_13 },
};
static const struct wl_message otr_wl_shm_pool_events[] = {
    { NULL, NULL, NULL },
};
static const struct wl_interface otr_wl_shm_pool_interface = { "wl_shm_pool", 3, 3, otr_wl_shm_pool_requests, 0, otr_wl_shm_pool_events };
static inline const struct wl_interface *otr_iface_wl_shm_pool(void) { return &otr_wl_shm_pool_interface; }

static const struct wl_message otr_wl_shm_requests[] = {
    { "create_pool", "nhi", otr_types_14 },
    { "release", "2", otr_types_16 },
};
static const struct wl_message otr_wl_shm_events[] = {
    { "format", "u", otr_types_15 },
};
static const struct wl_interface otr_wl_shm_interface = { "wl_shm", 3, 2, otr_wl_shm_requests, 1, otr_wl_shm_events };
static inline const struct wl_interface *otr_iface_wl_shm(void) { return &otr_wl_shm_interface; }

static const struct wl_message otr_wl_buffer_requests[] = {
    { "destroy", "", otr_types_17 },
};
static const struct wl_message otr_wl_buffer_events[] = {
    { "release", "", otr_types_18 },
};
static const struct wl_interface otr_wl_buffer_interface = { "wl_buffer", 1, 1, otr_wl_buffer_requests, 1, otr_wl_buffer_events };
static inline const struct wl_interface *otr_iface_wl_buffer(void) { return &otr_wl_buffer_interface; }

static const struct wl_message otr_wl_data_offer_requests[] = {
    { "accept", "u?s", otr_types_19 },
    { "receive", "sh", otr_types_20 },
    { "destroy", "", otr_types_21 },
    { "finish", "3", otr_types_23 },
    { "set_actions", "3uu", otr_types_24 },
};
static const struct wl_message otr_wl_data_offer_events[] = {
    { "offer", "s", otr_types_22 },
    { "source_actions", "3u", otr_types_25 },
    { "action", "3u", otr_types_26 },
};
static const struct wl_interface otr_wl_data_offer_interface = { "wl_data_offer", 4, 5, otr_wl_data_offer_requests, 3, otr_wl_data_offer_events };
static inline const struct wl_interface *otr_iface_wl_data_offer(void) { return &otr_wl_data_offer_interface; }

static const struct wl_message otr_wl_data_source_requests[] = {
    { "offer", "s", otr_types_27 },
    { "destroy", "", otr_types_28 },
    { "set_actions", "3u", otr_types_32 },
};
static const struct wl_message otr_wl_data_source_events[] = {
    { "target", "?s", otr_types_29 },
    { "send", "sh", otr_types_30 },
    { "cancelled", "", otr_types_31 },
    { "dnd_drop_performed", "3", otr_types_33 },
    { "dnd_finished", "3", otr_types_34 },
    { "action", "3u", otr_types_35 },
};
static const struct wl_interface otr_wl_data_source_interface = { "wl_data_source", 4, 3, otr_wl_data_source_requests, 6, otr_wl_data_source_events };
static inline const struct wl_interface *otr_iface_wl_data_source(void) { return &otr_wl_data_source_interface; }

static const struct wl_message otr_wl_data_device_requests[] = {
    { "start_drag", "?oo?ou", otr_types_36 },
    { "set_selection", "?ou", otr_types_37 },
    { "release", "2", otr_types_44 },
};
static const struct wl_message otr_wl_data_device_events[] = {
    { "data_offer", "n", otr_types_38 },
    { "enter", "uoff?o", otr_types_39 },
    { "leave", "", otr_types_40 },
    { "motion", "uff", otr_types_41 },
    { "drop", "", otr_types_42 },
    { "selection", "?o", otr_types_43 },
};
static const struct wl_interface otr_wl_data_device_interface = { "wl_data_device", 4, 3, otr_wl_data_device_requests, 6, otr_wl_data_device_events };
static inline const struct wl_interface *otr_iface_wl_data_device(void) { return &otr_wl_data_device_interface; }

static const struct wl_message otr_wl_data_device_manager_requests[] = {
    { "create_data_source", "n", otr_types_45 },
    { "get_data_device", "no", otr_types_46 },
    { "release", "4", otr_types_47 },
};
static const struct wl_message otr_wl_data_device_manager_events[] = {
    { NULL, NULL, NULL },
};
static const struct wl_interface otr_wl_data_device_manager_interface = { "wl_data_device_manager", 4, 3, otr_wl_data_device_manager_requests, 0, otr_wl_data_device_manager_events };
static inline const struct wl_interface *otr_iface_wl_data_device_manager(void) { return &otr_wl_data_device_manager_interface; }

static const struct wl_message otr_wl_shell_requests[] = {
    { "get_shell_surface", "no", otr_types_48 },
};
static const struct wl_message otr_wl_shell_events[] = {
    { NULL, NULL, NULL },
};
static const struct wl_interface otr_wl_shell_interface = { "wl_shell", 1, 1, otr_wl_shell_requests, 0, otr_wl_shell_events };
static inline const struct wl_interface *otr_iface_wl_shell(void) { return &otr_wl_shell_interface; }

static const struct wl_message otr_wl_shell_surface_requests[] = {
    { "pong", "u", otr_types_49 },
    { "move", "ou", otr_types_50 },
    { "resize", "ouu", otr_types_51 },
    { "set_toplevel", "", otr_types_52 },
    { "set_transient", "oiiu", otr_types_53 },
    { "set_fullscreen", "uu?o", otr_types_54 },
    { "set_popup", "ouoiiu", otr_types_55 },
    { "set_maximized", "?o", otr_types_56 },
    { "set_title", "s", otr_types_57 },
    { "set_class", "s", otr_types_58 },
};
static const struct wl_message otr_wl_shell_surface_events[] = {
    { "ping", "u", otr_types_59 },
    { "configure", "uii", otr_types_60 },
    { "popup_done", "", otr_types_61 },
};
static const struct wl_interface otr_wl_shell_surface_interface = { "wl_shell_surface", 1, 10, otr_wl_shell_surface_requests, 3, otr_wl_shell_surface_events };
static inline const struct wl_interface *otr_iface_wl_shell_surface(void) { return &otr_wl_shell_surface_interface; }

static const struct wl_message otr_wl_surface_requests[] = {
    { "destroy", "", otr_types_62 },
    { "attach", "?oii", otr_types_63 },
    { "damage", "iiii", otr_types_64 },
    { "frame", "n", otr_types_65 },
    { "set_opaque_region", "?o", otr_types_66 },
    { "set_input_region", "?o", otr_types_67 },
    { "commit", "", otr_types_68 },
    { "set_buffer_transform", "2i", otr_types_71 },
    { "set_buffer_scale", "3i", otr_types_72 },
    { "damage_buffer", "4iiii", otr_types_73 },
};
static const struct wl_message otr_wl_surface_events[] = {
    { "enter", "o", otr_types_69 },
    { "leave", "o", otr_types_70 },
};
static const struct wl_interface otr_wl_surface_interface = { "wl_surface", 4, 10, otr_wl_surface_requests, 2, otr_wl_surface_events };
static inline const struct wl_interface *otr_iface_wl_surface(void) { return &otr_wl_surface_interface; }

static const struct wl_message otr_wl_seat_requests[] = {
    { "get_pointer", "n", otr_types_79 },
    { "get_keyboard", "n", otr_types_80 },
    { "get_touch", "n", otr_types_81 },
    { "release", "5", otr_types_83 },
};
static const struct wl_message otr_wl_seat_events[] = {
    { "capabilities", "u", otr_types_78 },
    { "name", "2s", otr_types_82 },
};
static const struct wl_interface otr_wl_seat_interface = { "wl_seat", 11, 4, otr_wl_seat_requests, 2, otr_wl_seat_events };
static inline const struct wl_interface *otr_iface_wl_seat(void) { return &otr_wl_seat_interface; }

static const struct wl_message otr_wl_pointer_requests[] = {
    { "set_cursor", "u?oii", otr_types_84 },
    { "release", "3", otr_types_90 },
};
static const struct wl_message otr_wl_pointer_events[] = {
    { "enter", "uoff", otr_types_85 },
    { "leave", "uo", otr_types_86 },
    { "motion", "uff", otr_types_87 },
    { "button", "uuuu", otr_types_88 },
    { "axis", "uuf", otr_types_89 },
    { "frame", "5", otr_types_91 },
    { "axis_source", "5u", otr_types_92 },
    { "axis_stop", "5uu", otr_types_93 },
    { "axis_discrete", "5ui", otr_types_94 },
    { "axis_value120", "8ui", otr_types_95 },
    { "axis_relative_direction", "9uu", otr_types_96 },
    { "warp", "11ff", otr_types_97 },
};
static const struct wl_interface otr_wl_pointer_interface = { "wl_pointer", 11, 2, otr_wl_pointer_requests, 12, otr_wl_pointer_events };
static inline const struct wl_interface *otr_iface_wl_pointer(void) { return &otr_wl_pointer_interface; }

static const struct wl_message otr_wl_keyboard_requests[] = {
    { "release", "3", otr_types_103 },
};
static const struct wl_message otr_wl_keyboard_events[] = {
    { "keymap", "uhu", otr_types_98 },
    { "enter", "uoa", otr_types_99 },
    { "leave", "uo", otr_types_100 },
    { "key", "uuuu", otr_types_101 },
    { "modifiers", "uuuuu", otr_types_102 },
    { "repeat_info", "4ii", otr_types_104 },
};
static const struct wl_interface otr_wl_keyboard_interface = { "wl_keyboard", 11, 1, otr_wl_keyboard_requests, 6, otr_wl_keyboard_events };
static inline const struct wl_interface *otr_iface_wl_keyboard(void) { return &otr_wl_keyboard_interface; }

static const struct wl_message otr_wl_touch_requests[] = {
    { "release", "3", otr_types_110 },
};
static const struct wl_message otr_wl_touch_events[] = {
    { "down", "uuoiff", otr_types_105 },
    { "up", "uui", otr_types_106 },
    { "motion", "uiff", otr_types_107 },
    { "frame", "", otr_types_108 },
    { "cancel", "", otr_types_109 },
    { "shape", "6iff", otr_types_111 },
    { "orientation", "6if", otr_types_112 },
};
static const struct wl_interface otr_wl_touch_interface = { "wl_touch", 11, 1, otr_wl_touch_requests, 7, otr_wl_touch_events };
static inline const struct wl_interface *otr_iface_wl_touch(void) { return &otr_wl_touch_interface; }

static const struct wl_message otr_wl_output_requests[] = {
    { "release", "3", otr_types_117 },
};
static const struct wl_message otr_wl_output_events[] = {
    { "geometry", "iiiiissi", otr_types_113 },
    { "mode", "uiii", otr_types_114 },
    { "done", "2", otr_types_115 },
    { "scale", "2i", otr_types_116 },
    { "name", "4s", otr_types_118 },
    { "description", "4s", otr_types_119 },
};
static const struct wl_interface otr_wl_output_interface = { "wl_output", 4, 1, otr_wl_output_requests, 6, otr_wl_output_events };
static inline const struct wl_interface *otr_iface_wl_output(void) { return &otr_wl_output_interface; }

static const struct wl_message otr_wl_region_requests[] = {
    { "destroy", "", otr_types_120 },
    { "add", "iiii", otr_types_121 },
    { "subtract", "iiii", otr_types_122 },
};
static const struct wl_message otr_wl_region_events[] = {
    { NULL, NULL, NULL },
};
static const struct wl_interface otr_wl_region_interface = { "wl_region", 4, 3, otr_wl_region_requests, 0, otr_wl_region_events };
static inline const struct wl_interface *otr_iface_wl_region(void) { return &otr_wl_region_interface; }

static const struct wl_message otr_wl_subcompositor_requests[] = {
    { "destroy", "", otr_types_123 },
    { "get_subsurface", "noo", otr_types_124 },
};
static const struct wl_message otr_wl_subcompositor_events[] = {
    { NULL, NULL, NULL },
};
static const struct wl_interface otr_wl_subcompositor_interface = { "wl_subcompositor", 1, 2, otr_wl_subcompositor_requests, 0, otr_wl_subcompositor_events };
static inline const struct wl_interface *otr_iface_wl_subcompositor(void) { return &otr_wl_subcompositor_interface; }

static const struct wl_message otr_wl_subsurface_requests[] = {
    { "destroy", "", otr_types_125 },
    { "set_position", "ii", otr_types_126 },
    { "place_above", "o", otr_types_127 },
    { "place_below", "o", otr_types_128 },
    { "set_sync", "", otr_types_129 },
    { "set_desync", "", otr_types_130 },
};
static const struct wl_message otr_wl_subsurface_events[] = {
    { NULL, NULL, NULL },
};
static const struct wl_interface otr_wl_subsurface_interface = { "wl_subsurface", 1, 6, otr_wl_subsurface_requests, 0, otr_wl_subsurface_events };
static inline const struct wl_interface *otr_iface_wl_subsurface(void) { return &otr_wl_subsurface_interface; }

static const struct wl_message otr_wl_fixes_requests[] = {
    { "destroy", "", otr_types_131 },
    { "destroy_registry", "o", otr_types_132 },
    { "ack_global_remove", "2ou", otr_types_133 },
};
static const struct wl_message otr_wl_fixes_events[] = {
    { NULL, NULL, NULL },
};
static const struct wl_interface otr_wl_fixes_interface = { "wl_fixes", 2, 3, otr_wl_fixes_requests, 0, otr_wl_fixes_events };
static inline const struct wl_interface *otr_iface_wl_fixes(void) { return &otr_wl_fixes_interface; }

static const struct wl_message otr_zoolander_xwayland_bypass_manager_v1_requests[] = {
    { "destroy", "", otr_types_134 },
    { "get_window", "nu", otr_types_135 },
    { "get_app", "nss", otr_types_136 },
};
static const struct wl_message otr_zoolander_xwayland_bypass_manager_v1_events[] = {
    { NULL, NULL, NULL },
};
static const struct wl_interface otr_zoolander_xwayland_bypass_manager_v1_interface = { "zoolander_xwayland_bypass_manager_v1", 1, 3, otr_zoolander_xwayland_bypass_manager_v1_requests, 0, otr_zoolander_xwayland_bypass_manager_v1_events };
static inline const struct wl_interface *otr_iface_zoolander_xwayland_bypass_manager_v1(void) { return &otr_zoolander_xwayland_bypass_manager_v1_interface; }

static const struct wl_message otr_zoolander_xwayland_bypass_app_v1_requests[] = {
    { "destroy", "", otr_types_138 },
};
static const struct wl_message otr_zoolander_xwayland_bypass_app_v1_events[] = {
    { "mode", "u", otr_types_137 },
};
static const struct wl_interface otr_zoolander_xwayland_bypass_app_v1_interface = { "zoolander_xwayland_bypass_app_v1", 1, 1, otr_zoolander_xwayland_bypass_app_v1_requests, 1, otr_zoolander_xwayland_bypass_app_v1_events };
static inline const struct wl_interface *otr_iface_zoolander_xwayland_bypass_app_v1(void) { return &otr_zoolander_xwayland_bypass_app_v1_interface; }

static const struct wl_message otr_zoolander_xwayland_bypass_window_v1_requests[] = {
    { "set_content", "noii", otr_types_140 },
    { "destroy", "", otr_types_141 },
};
static const struct wl_message otr_zoolander_xwayland_bypass_window_v1_events[] = {
    { "mode", "u", otr_types_139 },
};
static const struct wl_interface otr_zoolander_xwayland_bypass_window_v1_interface = { "zoolander_xwayland_bypass_window_v1", 1, 2, otr_zoolander_xwayland_bypass_window_v1_requests, 1, otr_zoolander_xwayland_bypass_window_v1_events };
static inline const struct wl_interface *otr_iface_zoolander_xwayland_bypass_window_v1(void) { return &otr_zoolander_xwayland_bypass_window_v1_interface; }

static inline int otr_wayland_errno(void) { return errno; }
