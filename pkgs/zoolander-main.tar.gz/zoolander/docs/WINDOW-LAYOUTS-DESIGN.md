# Spatial layout behavior contract

This document describes the spatial layout behavior implemented by
Zoolander. [WINDOW-LAYOUTS.md](WINDOW-LAYOUTS.md) is the user guide. This page
records the state model and invariants needed when changing the compositor.

## Model

Each workspace has one primary arrangement. Classic arrangements are
Dwindle, Master Stack, Grid, Monocle, Spiral, Scrolling, and Floating. The
spatial arrangements are Canvas, Lanes, Accordion, Workbench, and Pairs.

Side Shelves and Anchors are placements layered around a primary arrangement.
Islands are named Canvas groups. The eight user-facing presets combine those
parts:

| Preset | Primary arrangement | Added behavior |
| --- | --- | --- |
| Canvas | Canvas | Two-dimensional world and camera |
| Side Shelves | Floating on first selection | Left and right shelves |
| Islands | Canvas | Named groups and group chrome |
| Lanes | Lanes | Named scrolling rows or columns |
| Accordion | Accordion | Expanded member with preview trays |
| Workbench | Workbench | Primary member and edge tools |
| Pairs | Pairs | Two panes with member lists |
| Anchors | Canvas on first selection | Viewport-attached window |

Selecting a primary arrangement does not discard saved state for other
arrangements. A shelf or anchor can remain active while the primary
arrangement changes. Fullscreen suppresses both placements without deleting
their state. Special workspaces remain separate overlays.

## State and geometry

`space.otr` stores per-workspace camera, placement, group, shelf, and saved
arrangement state. Records use stable window addresses rather than owning
window pointers. Closing a window removes its records. Output removal moves
or parks workspace state before the output is destroyed; reconnect can
restore a dormant group by output identity.

A window has two kinds of geometry:

- `geom` is the real client rectangle and keeps the configured client size.
- `view` controls presentation through scale, clipping, visibility, and input
  acceptance.

Rendering and hit testing use the same view. Scaled previews therefore send
input to corresponding client coordinates. Hidden tabs and paged-out previews
take no client input. Clipping uses the render scissor while keeping the
window's own visible corners.

The main area is the output work area after persistent shelves reserve their
width. Anchors overlay that area and do not change its allocation. Gaps,
shelf width, fallback dimensions, width cap, snap distance, reveal margin,
and pan gesture count come from spatial config.

## Focus and actions

Layout actions resolve against focused output, workspace, window, and
placement at dispatch time. An unavailable direction returns `no_target`; it
does not fall through to an unrelated global action. Held move, resize, and
pan operations stop when their recorded window, layout, workspace, or output
context changes.

Common action families are:

- directional focus, move, and resize
- previous or next member, region, group, tab, or layout
- primary action and focus-primary
- group creation, membership, removal, renaming, and primary selection
- park, promote, anchor, shelf toggle, attach, detach, swap, and orientation
- inspect, center, reveal, pan, zoom, and undo
- command sheet and window picker

Canvas interprets the optional move or resize step directly. Other layouts
map those actions to their own ordering and divider operations. A completed
held edit is one undo entry. Undo stores a bounded history of 20 placement
edits and resolves windows by address; it never recreates a closed client.

The command sheet and window picker are compositor-drawn modal interfaces.
Chrome consumes its own pointer input. Search includes windows hidden in
tabs, trays, shelves, or off-screen world positions.

## Layout transitions

`layout/switch.otr` converts the visible arrangement into destination initial
state and restores saved state on later visits.

- Entering Canvas preserves each visible rectangle as a world rectangle.
  Windows stacked at one position spread deterministically, keeping the
  frontmost window in place.
- Entering Lanes derives rows from visible rectangles, ordered top to bottom,
  with members ordered along the lane axis.
- Entering a grouped layout creates deterministic initial membership from
  current stable order.
- Leaving a spatial arrangement restores classic tiling order even after
  spatial stacking changes.
- Manually floated windows may join a spatial arrangement. Dialogs, pinned
  windows, and windows floated by a rule remain floating.

Switching layout does not change a client's buffer size merely to create a
preview. Real configures occur only where the active arrangement gives the
client a new live rectangle.

## Canvas and Islands

Canvas stores window rectangles in world coordinates and a camera per
workspace. Empty world space is valid, so the camera is not clamped to the
occupied bounds. Directional focus includes off-screen windows and moves the
camera only enough to reveal the target with configured margin.

New unsized windows use `fallback_width`, `fallback_height`, and `width_cap`.
They are placed near focus without moving existing windows. Manual pointer
movement is one-to-one at current zoom. Edge snapping uses `snap`; Alt
suppresses it. Shift at drop requests the nearest free position. Escape
restores starting window and camera state.

Canvas supports pointer-centered zoom. High-resolution wheel deltas
accumulate into discrete steps. Zoom 0 restores 1:1 around focus. Scaled
windows remain interactive because input transformation follows the view.

Dragging empty space, Super+middle drag, direct pan actions, wheel gestures,
and touchpad gestures move the camera. Pointer-edge dwell can pan during a
window drag. A new pointer or touch interaction stops existing coast motion.

Edge counters report off-screen windows. `center`, `reveal`, and
inspection provide bounded ways back to a window without rewriting its world
position unnecessarily.

Islands use the same Canvas geometry. A group owns an ordered member set,
name, and derived outline. Group focus and movement operate on this stored
membership. Removing a group returns live members to ordinary Canvas
placement; it does not close clients.

## Side Shelves

A window parked left or right leaves the primary arrangement and enters an
ordered shelf. Its return record remembers enough primary placement to
promote it back when possible. If the remembered group no longer exists,
promotion uses the nearest valid main placement.

Persistent shelves reserve main-area width. Drawer presentation overlays the
main area. Auto mode selects presentation from available space. Shelf cards
use scaled live surfaces without resizing the client. Inspect and Open chrome
are compositor-owned input regions. Pointer wheel over the gutter scrolls the
shelf; wheel over client content remains client input.

## Lanes

Lanes are ordered groups with one camera along the member axis and another
across lanes. Horizontal mode creates rows whose members scroll left and
right; vertical mode creates columns whose members scroll up and down.

A sole lane fills the main area. Multiple lanes normally receive half the
cross-axis area, with compact-output fallback when that would be too small.
Members keep preferred size along the scrolling axis and fill the lane on the
cross axis. Directional move reorders within a lane or transfers between
lanes. Pointer drop on empty lane space transfers at drop position; drop on a
member swaps them.

## Accordion

Accordion has one expanded member and scaled live previews. Horizontal
orientation uses left and right trays; vertical orientation uses top and
bottom trays. The expanded window retains at least 65 percent of the primary
axis. Preview cards are bounded to 176 by 128 logical pixels.

Inactive clients retain their last real expanded size. A preview changes only
the view, never client geometry. When all previews do not fit, trays page
around the selected member and expose omitted count. Selecting a preview
changes the expanded member and consumes the chrome click.

Resize changes relevant layout allocation. It must not compound preview scale
into client geometry. Orientation changes recompute trays from stored real
sizes.

## Workbench

A workbench contains one primary member and tools attached to left, right, or
bottom edges. Each edge may contain multiple tools as tabs; only its selected
tool is visible. Attachments stay one level deep.

The primary receives the remaining central rectangle. Directional resize
changes the adjacent attachment divider. Focus-primary selects the primary;
tab and group actions select tools or workbenches without changing membership.
Running the primary action while primary is already focused selects the front
tool in fixed edge order: right, bottom, then left. That rule is deterministic
and does not depend on focus history.

Attachments shrink before taking the primary below 60 percent of main-area
width or height. Stored divider sizes remain available when space returns.

## Pairs

Pairs contain two panes with ordered member lists. One member in each pane is
visible. Orientation places panes side by side or stacked. Divider ratio is
stored with the pair and constrained by available main area.

Directional move transfers or reorders members. `tab` selects a member within
a pane, `primary` switches panes, `swap` exchanges pane roles, and
`orientation` rotates the split. Pointer drop on a pane performs supported
swap behavior; separate replace and add-behind drop targets are not exposed.

## Anchors

An anchor attaches a window to a viewport corner while the world beneath it
moves. Its state stores corner and offsets in logical output coordinates.
Moving an anchor changes those offsets rather than its Canvas world position.
Unanchoring returns it through saved primary placement.

Output size or scale changes resolve saved corner against the new work area
and keep enough chrome visible for recovery. An anchor moved from a removed
output remains reachable on a surviving output with its placement state
intact.

## Output and workspace lifecycle

Workspace identity, layout state, and placement records survive output
removal. Special-workspace windows move to a live output before a removed
output group can become dormant. Same-name workspace records merge without
duplicating ownership. If reclaiming the last regular workspace would leave
an output without one, the output receives a regular fallback workspace.

When all outputs are absent, compositor keeps dormant workspace state without
arranging against invalid geometry. Reacquisition attaches state to the new
output and arranges after valid mode and scale are known. Active grabs and
modal references tied to a removed output are cancelled before its state is
destroyed.

## Implementation map

The files are in `otr/`.

| Files | Responsibility |
| --- | --- |
| `space.otr`, `spatial.otr` | Stored state, dispatch, shared ordering, view and reveal helpers |
| `layout/switch.otr` | Arrangement transitions and saved-state restoration |
| `layout/canvas.otr`, `layout/lanes.otr`, `layout/accordion.otr`, `layout/workbench.otr`, `layout/pairs.otr`, `layout/shelf.otr` | Arrangement and placement geometry |
| `layout/ops.otr`, `layout/place_ops.otr`, `layout/group_ops.otr`, `layout/lane_ops.otr`, `layout/presets.otr` | Action implementations |
| `layout/drag.otr`, `layout/desk_input.otr` | Pointer operations, snapping, drop targets, panning, and chrome input |
| `layout/undo.otr` | Bounded edit history |
| `layout/chrome*.otr`, `command_sheet*.otr`, `window/picker*.otr`, `chrome_text.otr` | Compositor-drawn interfaces |
| `layout/info.otr`, `layout/hint.otr` | JSON inspection and transient action feedback |
| `workspace/layouts.otr`, `workspace/outputs.otr`, `output/lifecycle.otr` | Workspace selection, output removal, dormant state, and reconnection |

Geometry modules do not own clients. During arrangement they initialize and
reconcile stored layout, placement, selection, and presentation state. Action
and lifecycle modules handle explicit commands and output changes; render and
hit-test code consume the resulting geometry and view state.
