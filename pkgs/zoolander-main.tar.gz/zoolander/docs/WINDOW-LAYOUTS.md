# Spatial window layouts

This guide covers the eight spatial layouts, the keys that drive them and
their Lua API. The behavior contract they implement is
[WINDOW-LAYOUTS-DESIGN.md](WINDOW-LAYOUTS-DESIGN.md).

The `require("layouts")` helpers and keys below belong to the repository's
`config/ferreo` profile. They are not built-in `zl` functions. The `zl.*`
calls documented here are available to every config.

## Choosing a layout

Super+L steps the focused workspace to its next layout (Super+Shift+L goes
back): Dwindle, Master, Grid, Monocle, Spiral, Scrolling and Floating, then
the eight choices below (canvas, shelves, islands, lanes, accordion,
workbench, pairs, anchors). Side Shelves, Islands and Anchors are an
arrangement plus a feature; stepping away from one turns off what it turned
on (its shelves, its island, its anchor). `require("layouts").setup{
layouts = { "dwindle", "canvas", "shelves", "lanes" } }` limits the cycle to
your own list. Or choose one from the command sheet (Super+Ctrl+Space, then
1–8), with `zl.layout("layout_set", 0, "islands")`, or per workspace in the
config:

```lua
zl.set_workspace_layout("3", "canvas", 0.6, 1)   -- or shelves, islands, lanes, accordion, workbench, pairs, anchors
zl.set_layout("shelves")                         -- the default for workspaces without a rule
```

A layout from the config arrives the way `layout_set` does, and its feature
keeps working for windows that come later. Side Shelves turns its shelves on
straight away. On Islands every window that opens on or moves onto the
workspace joins the layout's island, and the first one makes it. On Anchors
the first such window is anchored while none is.

| # | Choice | What it gives you |
| --- | --- | --- |
| 1 | Canvas | A two-dimensional desk. Windows keep their size and place; a per-workspace camera shows part of it. |
| 2 | Side Shelves | Floating windows in the middle, live app shelves on both edges. After first use, shelves can sit beside any layout. |
| 3 | Islands | Canvas with named groups (island outlines and labels). |
| 4 | Lanes | Named rows. Each row scrolls sideways; one vertical camera moves between rows. |
| 5 | Accordion | One window expanded; the others are live previews in compact side trays. |
| 6 | Workbench | A primary window with tools attached on its left, right and bottom edges, as tabs. |
| 7 | Pairs | Two panes side by side (or stacked). Each pane has its own list of windows. |
| 8 | Anchors | Canvas, with the focused window pinned to a corner of the screen while the view moves. |

Shelves and anchors are placements, not arrangements, so they work with every
layout, including the classic tilers.

Switching layouts starts from what is on screen. Canvas keeps every window
exactly where it is shown and lets it move freely from there; windows that
were stacked (coming from Floating or Monocle) spread out, the frontmost
keeping its place. Side Shelves fits floating windows between the shelves. Lanes turns
the rows you see into lanes, top to bottom, each ordered left to right; a
lane fills the screen alone and half of it beside others, and its windows
fill the lane's height at their own widths. Going back to a classic tiler
restores the order it had, whatever the spatial layouts did to the
stacking meanwhile. Windows you floated by hand (an Alt+titlebar drag, Super+S)
join the new layout; dialogs, pinned windows and windows floated by a rule
stay floating.

Lanes run as rows by default. Super+Alt+O turns them into columns (and
back): each lane then scrolls up and down, the camera moves sideways
between lanes, and the arrow keys turn with them. A workspace can start
with columns from the config, as Scrolling does:
`zl.set_workspace_layout("3", "lanes", 0.6, 1, "vertical")`.

Scrolling puts each window in a column of its own on a strip that scrolls
past the screen edge (tab groups share one column). Super+R steps the
focused column through the widths of `zl.set_scrolling{ width_presets = {
1/3, 2/3, 1 } }` and Super+Shift+R steps back, wrapping round; every column
keeps its own width, and new ones open at the `zl.set_layout` ratio.
Super+Alt+Shift+arrows move the focused column along the strip
(`zl.move_column`), and Super+Ctrl+Alt+arrows send it to the output that way
(`zl.move_column_to_monitor`, which also takes an output name), right of the
column focused there. The strip runs sideways; `zl.set_layout("scrolling",
0.5, 1, "perpendicular")` runs it across the way workspaces slide, so up and
down with the default sideways slide.

## Keys

The `ferreo` profile loads these from `config/ferreo/layouts.lua`. The action
families stay the same everywhere, and their meaning follows the focused
window's layout and placement:

| Keys | Action |
| --- | --- |
| Super+arrows | Focus a neighbour. On Canvas this includes windows off screen, and the view follows with the least movement. In Lanes, left/right moves within a lane and up/down moves between lanes. |
| Super+Shift+arrows | Move or reorder: translate on Canvas, reorder in lanes and preview trays, transfer between lanes or panes, move a workbench tool to another edge. |
| Super+Alt+arrows | Resize the window or the relevant divider (pair split, workbench attachment, lane height, shelf width). |
| Super+L / Super+Shift+L | Next or previous layout for this workspace. `require("layouts").setup{ announce = function(name) ... end }` replaces the toast with your own OSD or notification. |
| Super+[ / Super+] | Previous or next unit: window, lane, workbench, pane member or shelf card. |
| Super+Alt+Return | The layout's primary action: center (Canvas), maximize/restore (Accordion), focus the primary (Workbench), switch pane (Pairs), open a shelf app in the main area. |
| Super+Alt+Tab | Cycle focus regions: main area, left shelf, right shelf, anchors. |
| Super+Ctrl+Return | Inspect the focused window at a readable size. Esc returns it. |
| Super+Ctrl+Space | Command sheet. Every action is listed here, with its keys or the reason it is unavailable. |
| Super+Ctrl+Tab | Window picker: every window on the workspace, including collapsed previews, background tabs, shelved apps and windows far off on the canvas. Type to search; Tab widens the search to all outputs. |
| Super+Alt+1 / 2 | Park the focused window in the left or right shelf. |
| Super+Alt+A | Anchor or unanchor. Super+A stays sticky pin. |
| Super+Alt+G / N | New island, lane or pair. A new lane takes the focused window with it (unless it is alone in its lane). In Workbench, detach into a new workbench. |
| Super+Alt+[ / ] | Previous or next group: island, lane, workbench or pair. |
| Super+Alt+X / O / T | Swap panes / toggle orientation (Pairs, Accordion, Lanes rows or columns) / attach or detach a workbench tool. |
| Super+Alt+S | Turn shelves on or off. |
| Super+Alt+U | Undo the last layout change. The history holds 20 edits; a held key counts as one. |
| Super+Ctrl+Shift+Left/Right | Move the window to the adjacent workspace. The contextual profile moves this off Super+Shift+Left/Right; `profile = "legacy"` keeps the old keys. |

When an action has nothing to act on in that direction, you get a short hint,
such as "No window to the left". It never falls through to a different action.
Held move, resize and pan keys repeat. A repeat stops as soon as its context
changes (a different window, layout, workspace or output), so a held key never
starts acting on something new.

In the command sheet, with an empty search box, single keys run commands:
`1`–`8` choose a layout. `P`, `M` and `R` enter Pan, Move and Resize modes.
In those modes, arrows step 20 px (100 with Shift, 1 with Ctrl), Enter keeps
the result and Esc puts everything back. `O` opens the window picker and `U`
undoes. Typing anything else searches.

## Pointer

- **Super+left drag** moves a Canvas window or an anchor 1:1. It snaps to
  neighbouring edges within 12 px; hold Alt to place it freely. It lands
  exactly where you drop it, overlapping or not. Hold Shift as you let go
  to tidy it into the nearest free spot instead (outlined while Shift is
  held). Dragging against a screen edge pans the view after a short dwell.
  Esc cancels the drag and restores the view.
- **Dragging empty desk** (left button, with or without Super) or
  **Super+middle drag** anywhere pans the Canvas or Lanes view. The pointer
  moves with your hand while the desk follows it. A grabbing-hand cursor
  marks the drag, and a flick coasts on after release. **Super+Ctrl+wheel**
  pans too; add Shift for horizontal.
- **Three-finger swipe** on a touchpad pans Canvas and Lanes 1:1 and coasts
  on release; touching the pad again stops it. On those layouts the
  workspace/overview swipe moves up to four fingers, so both stay
  reachable; other layouts keep it on three. `zl.set_spatial{ pan_fingers
  = 4 }` picks another count (0 turns it off).
- **Two-finger scroll over empty desk** pans too (the mouse wheel does in
  Lanes). Over an app, the app scrolls. The choice is made when a scroll
  starts and kept until it ends, so a window sliding under the pointer
  never takes the scroll over.
- **Zoom a Canvas** with the mouse wheel over empty desk, Super+wheel
  anywhere, or Super+Ctrl+= / - / 0 (0 goes back to 1:1 around the focused
  window). High-resolution wheel events accumulate into one zoom step per
  notch. Zoom follows the pointer. Zoomed out, windows are scaled
  pictures that still take clicks and typing; the focused one is ringed.
  In a config, `require("layouts").zoom_or(steps, fallback)` zooms on a
  Canvas and runs `fallback` elsewhere, e.g. Super+wheel switching
  workspaces on other layouts.
- **Dragging a window onto empty space in another lane** moves it into that
  lane, placed by where you drop it; dropping it on a window swaps the two.
- **Holding Super with the pointer at a screen edge** pans the view that way
  after a short dwell, faster the longer you hold. Release Super or move away
  to stop. At an edge shared with another monitor the pointer is held so
  the edge pans like any other; push on firmly to cross to that monitor.
  The same holds while dragging a Canvas window.
- **Dropping a window on a shelf** parks it. Shelf cards have **Inspect** and
  **Open** buttons. Clicking a card focuses the app inside it. Wheel over a
  shelf's gutter scrolls the shelf; over an app, the app scrolls.
- Accordion previews keep each app at its real client size. Wide outputs use
  left/right trays; vertical orientation uses top/bottom trays. A workspace
  rule's axis fixes the trays: `zl.set_workspace_layout("1", "accordion", 0.6,
  1, "vertical")`. Previews
  stack within each tray, leaving at least 65% of the layout axis for the
  expanded window. Extra previews page around the selected window.
- Clicking an **accordion preview**, a **workbench or pair tab**, a **lane
  heading** or an **island label** selects it. The click never reaches an app.
- On Canvas, **edge counters** show how many windows are off screen in each
  direction; click one to jump there. If the focused window is off screen, a
  pill offers to bring it back.

## Lua API

```lua
zl.layout(action [, a [, b]])      -- "done" | "no_target" | "unavailable"
zl.layout_context()                -- { layout=, entry=, placement=, spatial=, has_window= }
zl.layout_info()                   -- JSON snapshot of the focused workspace
zl.set_spatial({
    fallback_width = 0.667,        -- new unsized windows: share of the main area
    fallback_height = 0.75,
    width_cap = 1440,              -- 0 = no cap
    shelf_mode = "auto",           -- "persistent" | "drawer"
    shelf_width = 0,               -- 0 = adaptive (1/6 of the width, 240..480)
    snap = 12,                     -- edge snapping distance, 0 = off
    reveal_margin = 48,            -- visible margin when revealing a window
    pan_fingers = 3,               -- touchpad swipe that pans, 0 = off
})
zl.set_reduced_motion(true)        -- spatial travel and scale changes become instant
zl.set_animation_leaf("camera", { duration = 170, curve = ... })
zl.set_animation_leaf("layout", { duration = 180, curve = ... })
```

`fallback_width` and `fallback_height` accept 0.2..1, `width_cap` 0..16384,
`shelf_width` 0..1200, `snap` 0..64, `reveal_margin` 0..200, and
`pan_fingers` 0..5.

`action` is one of: `focus`, `move`, `resize` (a = "left" | "right" | "up" |
"down"), `cycle` (a = "next" | "prev"), `primary`, `region`, `inspect`,
`pan` (a, b = pixels), `center`, `reveal`, `park` (a = "left" | "right"),
`promote`, `anchor`, `shelves`, `undo`, `preset` (a = 1..8), `layout_cycle`
(a = 1 or -1; text "quiet" skips the toast), `group_new`
(a = name), `group_add`, `group_remove`, `group_cycle`, `group_rename`,
`set_primary`, `attach` (a = 1 left, 2 right, 3 bottom), `detach`, `swap`,
`orientation`, `tab`, `commands`, `windows`, `pan_direct` (a, b = pixels,
without animation), `layout_set` (text = layout name; a = 1 skips
the toast), and `zoom` (a = notches, positive in; 0 = 1:1). The optional `b`
argument changes the step for `move` and `resize` on Canvas; other layouts use
their own divider and ordering rules.

`zl.layout_context()` lets a config bind a key differently per layout:

```lua
zl.bind(L + S, zl.KEY_LEFT, function()
    if zl.layout_context().spatial then return zl.layout("move", "left") end
    return move_to_previous_workspace()
end)
```

Tests and scripts can drive a running compositor over IPC:

```sh
zoolanderctl eval 'return zl.layout("preset", 5)'
zoolanderctl eval 'return zl.layout_info()'
```

## How it fits together

The files are in `otr/`.

| File | Responsibility |
| --- | --- |
| `space.otr` | Per-window placement record and the per-workspace store: camera, groups, shelves. No window pointers, so no dangling references. |
| `spatial.otr` | Arrangement dispatch, shared ordering, reveal and presentation helpers. |
| `layout_{canvas,lanes,accordion,workbench,pairs,shelf}.otr` | Pure geometry for each arrangement and placement. |
| `layout/switch.otr` | Entry, exit, and saved-state conversion when the primary layout changes. |
| `layout/ops.otr`, `layout/place_ops.otr`, `layout/group_ops.otr`, `layout/presets.otr` | The action families and edits, resolved against the focused context. |
| `layout/undo.otr` | Bounded undo history, restored by window address. |
| `layout/drag.otr`, `layout/desk_input.otr` | Pointer moves, snapping, drop targets, auto-pan, chrome clicks and panning. |
| `layout/lane_ops.otr` | Lane creation, removal, focus and row transfer operations. |
| `layout/hint.otr` | Timed layout hints and their fade state. |
| `layout/info.otr` | JSON snapshot used by `zl.layout_info()`. |
| `layout/chrome*.otr`, `command_sheet*.otr`, `window/picker*.otr`, `chrome_text.otr` | Compositor-drawn chrome and overlays. |

A window's `geom` always keeps its real client size. How it is shown is a
separate `view`: a uniform scale (shelf cards, Accordion previews, inspection),
a clip (lane bands, a main area shortened by shelves), hidden (background
tabs, paged-out previews) or no client input (Accordion previews). Drawing
and hit-testing read the same view, so the pointer lands where the pixels
are, including in popups of a scaled app. A clipped window is cut with a render scissor, so it keeps its
own rounded corners wherever they are visible.

## Known limits

- Compositor chrome is drawn text. It is not yet exposed through an
  accessibility tree.
- Shelves reserve space on the output they are on. A sticky shelf app follows
  the existing pin semantics and is not duplicated onto other monitors.
- When Workbench's primary action runs on the already focused primary, it
  focuses the front tool on the right edge, then bottom, then left.
- Pointer drags onto pair panes swap members. Separate *replace* and *add
  behind* drop targets are not implemented yet; use Super+Shift+arrows.
