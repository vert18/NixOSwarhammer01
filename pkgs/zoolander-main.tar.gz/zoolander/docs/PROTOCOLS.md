# Protocols

These are the Wayland globals Zoolander advertises, with the highest version
it offers. The protocol code lives in `zooland`; Zoolander decides which
globals to register and who may see them.

"Privileged" globals are hidden from clients that connect through
`wp_security_context_manager_v1`, which is how Flatpak and other sandboxes
connect. Every other local client sees them.

A headless session advertises 76 globals with one output. A DRM session with
the Vulkan renderer adds the six in [Hardware](#hardware) for 82.

## Core

| Interface | Version | Notes |
|---|---|---|
| `wl_compositor` | 7 | |
| `wl_subcompositor` | 1 | |
| `wl_shm` | 3 | ARGB8888 and XRGB8888 |
| `wl_seat` | 11 | One seat |
| `wl_output` | 4 | One per enabled output |
| `wl_data_device_manager` | 4 | |
| `wl_fixes` | 2 | |
| `xdg_wm_base` | 7 | |
| `zxdg_output_manager_v1` | 3 | |
| `zxdg_decoration_manager_v1` | 2 | |
| `org_kde_kwin_server_decoration_manager` | 1 | |
| `zwlr_layer_shell_v1` | 5 | Privileged |
| `ext_session_lock_manager_v1` | 1 | Privileged |
| `xwayland_shell_v1` | 1 | Shown only to Zoolander's own Xwayland |

## Surfaces and presentation

| Interface | Version | Notes |
|---|---|---|
| `wp_viewporter` | 1 | |
| `wp_fractional_scale_manager_v1` | 1 | |
| `wp_single_pixel_buffer_manager_v1` | 1 | |
| `wp_content_type_manager_v1` | 1 | |
| `wp_alpha_modifier_v1` | 1 | |
| `ext_background_effect_manager_v1` | 1 | Blur behind a surface |
| `wp_tearing_control_manager_v1` | 1 | |
| `wp_fifo_manager_v1` | 1 | |
| `wp_commit_timing_manager_v1` | 1 | |
| `wp_presentation` | 2 | |
| `wp_color_manager_v1` | 3 | ICC and parametric descriptions. A surface's preferred description is its output's. For a `force_game_hdr` window on an output scanning SDR it is the output's HDR-mode description instead (PQ, BT.2020), and its PQ is converted to SDR |
| `wp_color_representation_manager_v1` | 1 | Premultiplied and straight alpha. BT.601, BT.709 and BT.2020 in full and limited range only when the renderer imports YCbCr dmabufs |
| `frog_color_management_factory_v1` | 1 | Mapped onto `wp_color_manager_v1`; the last request before a commit wins. `preferred_metadata` follows the same preferred description |
| `zoolander_xwayland_bypass_manager_v1` | 1 | Zoolander's own, in `zooland/protocols/zoolander-xwayland-bypass-v1.xml`, for its Vulkan layer; see [Xwayland bypass](#xwayland-bypass) |

## Windows

| Interface | Version | Notes |
|---|---|---|
| `xdg_activation_v1` | 1 | |
| `xdg_wm_dialog_v1` | 1 | |
| `xdg_system_bell_v1` | 1 | |
| `xdg_toplevel_icon_manager_v1` | 1 | |
| `xdg_toplevel_tag_manager_v1` | 1 | Window rules can match the tag; `zl.get_windows` reports it |
| `zxdg_exporter_v2`, `zxdg_importer_v2` | 1 | |
| `zxdg_exporter_v1`, `zxdg_importer_v1` | 1 | Share handles with v2 |
| `gtk_shell1` | 7 | |
| `org_kde_kwin_appmenu_manager` | 1 | |
| `ext_foreign_toplevel_list_v1` | 1 | Privileged |
| `zwlr_foreign_toplevel_manager_v1` | 3 | Privileged |
| `hyprland_toplevel_mapping_manager_v1` | 1 | Privileged |
| `ext_workspace_manager_v1` | 1 | |
| `xdg_toplevel_drag_manager_v1` | 1 | Tab tear-off: the dragged toplevel follows the pointer |
| `xdg_session_manager_v1` | 1 | Only with an absolute `XDG_STATE_HOME` or `HOME` to keep sessions in |

## Input

| Interface | Version | Notes |
|---|---|---|
| `zwp_pointer_constraints_v1` | 1 | |
| `zwp_relative_pointer_manager_v1` | 1 | |
| `zwp_pointer_gestures_v1` | 3 | |
| `wp_cursor_shape_manager_v1` | 2 | |
| `wp_pointer_warp_v1` | 1 | |
| `zwp_input_timestamps_manager_v1` | 1 | Microsecond libinput time; millisecond time for virtual devices |
| `zwp_tablet_manager_v2` | 2 | |
| `zwp_text_input_manager_v3` | 2 | |
| `zwp_text_input_manager_v1` | 1 | |
| `zwp_text_input_manager_v2` | 1 | |
| `zwp_input_method_manager_v2` | 1 | Privileged |
| `zwp_input_method_v1` | 1 | Privileged. One input method per seat across v1 and v2 |
| `zwp_input_panel_v1` | 1 | Privileged |
| `zwp_keyboard_shortcuts_inhibit_manager_v1` | 1 | Privileged |
| `zwp_virtual_keyboard_manager_v1` | 1 | Privileged |
| `zwlr_virtual_pointer_manager_v1` | 2 | Privileged |
| `ext_transient_seat_manager_v1` | 1 | Privileged. Each seat has its own pointer and software cursor and follows the main keyboard focus |
| `zwp_idle_inhibit_manager_v1` | 1 | |
| `ext_idle_notifier_v1` | 2 | |
| `hyprland_global_shortcuts_manager_v1` | 1 | Privileged |

## Clipboard, capture and outputs

| Interface | Version | Notes |
|---|---|---|
| `zwp_primary_selection_device_manager_v1` | 1 | |
| `ext_data_control_manager_v1` | 1 | Privileged |
| `zwlr_data_control_manager_v1` | 2 | Privileged |
| `zwlr_screencopy_manager_v1` | 3 | Privileged |
| `ext_output_image_capture_source_manager_v1` | 1 | Privileged |
| `ext_foreign_toplevel_image_capture_source_manager_v1` | 1 | Privileged |
| `hyprland_workspace_image_capture_source_manager_v1` | 1 | Privileged. Sources take an `ext_workspace_handle_v1` and give frames the size of the workspace's output, rendered offscreen, so a hidden workspace captures too. `windows_only` draws its windows and their popups on a transparent background; `everything` adds the backdrop, layer surfaces and pinned windows. Frames are paced by that output's repaints like output capture, and never include the cursor. A removed workspace gives transparent, empty frames |
| `ext_image_copy_capture_manager_v1` | 1 | Privileged |
| `zoolander_image_copy_capture_size_manager_v1` | 1 | Privileged. Zoolander's own, in `zooland/protocols/zoolander-image-copy-capture-size-v1.xml`. `set_max_size` on a session's size object fits its buffer size inside a maximum, aspect ratio kept and never scaled up, and the renderer draws the source scaled down straight into the small SHM or dma-buf buffer. For thumbnails and previews |
| `zwlr_output_manager_v1` | 4 | Privileged |
| `zwlr_output_power_manager_v1` | 1 | Privileged |
| `wp_security_context_manager_v1` | 1 | Privileged |

## Hardware

These need the DRM backend. The renderer and the device decide the rest.

| Interface | Version | Registered when |
|---|---|---|
| `zwp_linux_dmabuf_v1` | 6 | The renderer imports dmabufs (Vulkan with the dma-buf and DRM-modifier extensions) |
| `wl_drm` | 2 | Same, and the device has a render node. Names the render node, and buffers come through `create_prime_buffer` |
| `wp_linux_drm_syncobj_manager_v1` | 1 | The device supports syncobj timelines |
| `zwlr_gamma_control_manager_v1` | 1 | Privileged. An output has a gamma LUT |
| `wp_drm_lease_device_v1` | 1 | Privileged. Always on DRM, even before a headset or other non-desktop connector is plugged in |
| `zwlr_export_dmabuf_manager_v1` | 1 | Privileged. The Vulkan renderer draws the outputs into exported scanout images; frames are the scanout buffer itself. Not offered when frames are copied into dumb buffers |

## Xwayland bypass

`zoolander_xwayland_bypass_v1` lets an X11 client present a window's content
through a `wl_surface` of its own, which can carry a `wp_color_manager_v1`
description and HDR metadata where X11 cannot. Zoolander's Vulkan layer,
`VK_LAYER_ZOOLANDER_wsi`, is its client; it follows gamescope's
`gamescope_xwayland` and `gamescope_swapchain.override_window_content`.

- `get_window(id, x11_window)` follows a top-level window of Zoolander's
  Xwayland. The window object sends `mode` at once and on every change: `hdr`
  while a `force_game_hdr` rule matches the window, `x11` otherwise, also on an
  output in HDR mode. Only the process that owns the X11 window (its XRes
  client pid, else `_NET_WM_PID`, against the Wayland client's peer pid) gets
  `hdr`, so no client can cover another's window. Games pick their swapchain
  before they map their window, so for a window Zoolander does not manage
  yet the rules are matched against its X11 class and title, as they will be
  once it maps. An unknown window stays `x11`.
- `set_content(id, surface, x, y)` makes `surface` a `wl_subsurface` of the X11
  window's own surface at `x`, `y` (a Wine child window's place in its
  toplevel), above it, mapped as soon as it has a buffer. It follows the
  window's position, stacking, workspace, visibility and outputs, gets its
  frame callbacks, presentation feedback and damage like any sub-surface, and
  is composited with its own image description. Input still goes to the X11
  window wherever the surface's input region is empty, which the layer sets.
  The sub-surface starts desynchronized. Before the window maps, the surface
  is held, with its `wl_subsurface` ignoring requests, and is shown once the
  window has its Xwayland surface.
  A surface with another role is a `bad_surface` error; a second call on one
  window object is `content_exists`. In `x11` mode the new `wl_subsurface` is
  inert.
- `get_app(id, app_id, title)` answers once with the `mode` that the window
  rules alone would give a window with that app_id and title, before the app
  has windows. The layer uses it to set `DXVK_HDR=1`.

