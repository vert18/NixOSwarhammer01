zl.set_blur({ size = 2 })

zl.set_blur({ size = 99 })
