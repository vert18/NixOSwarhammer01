zl.on("startup", function() zl.exec_command("never") end)
require("blur")
