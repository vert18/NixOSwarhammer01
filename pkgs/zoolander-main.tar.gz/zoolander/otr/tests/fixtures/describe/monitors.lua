zl.output_rule({
    output = "DP-2",
    width = 3840,
    height = 2160,
    refresh = 240,
    scale = 2,
})
