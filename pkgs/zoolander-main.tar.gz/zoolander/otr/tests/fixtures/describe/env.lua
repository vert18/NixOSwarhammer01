zl.set_env("MOZ_ENABLE_WAYLAND", "1")
zl.set_env("XCURSOR_SIZE", "24")
