-- The shape of a real config: init.lua requiring helper modules.
require("env")
require("monitors")
zl.set_presentation({ vrr = 2, hdr = "auto" })
zl.set_window_style({
    gaps_in = 3,
    shadow = { enabled = false, color = "#00000073" },
})
require("exec")
require("keybinds")
require("windows")
