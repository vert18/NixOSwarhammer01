local function bind(description, action, options)
    local modifiers = 0
    local key
    for token in description:gmatch("[^+]+") do
        local value = token:match("^%s*(.-)%s*$"):lower()
        if value == "shift" then modifiers = modifiers + zl.MOD_SHIFT
        elseif value == "super" then modifiers = modifiers + zl.MOD_LOGO
        else key = value end
    end
    local keysym = (key == "return" and zl.KEY_RETURN) or string.byte(key)
    local id = zl.bind(modifiers, keysym, action, options)
    return id
end

local function command(value)
    return function() return zl.exec_command(value) end
end

bind("SUPER + Q", command("otter-term"), { description = "Terminal" })
bind("SUPER + SHIFT + Return", command("otter-launcher"), { locked = true })
for i = 1, 3 do
    bind("SUPER + " .. i, function() return zl.workspace(tostring(i)) end)
end
bind("SUPER + 1", function() end, { description = "Replaced" })
