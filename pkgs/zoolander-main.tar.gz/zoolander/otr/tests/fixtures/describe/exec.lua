local function run(command)
    assert(zl.exec_command(command))
end

zl.on("startup", function()
    run("otter-bar &")
    run("otter-osd &")
end)
