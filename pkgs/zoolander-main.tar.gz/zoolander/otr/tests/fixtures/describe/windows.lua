local function rule(match, pattern, float)
    assert(zl.add_window_rule(match, pattern, float or false))
end

rule("app_id", "^(launcher)$", true)
