-- Gives every monitor the persistent workspaces first..first+count-1 and
-- keeps the active one across reloads, like a split-workspace profile.
local module = {}
local first, count

local function map(monitor)
    local last = first + count - 1
    for index = first, last do
        assert(zl.workspace_on_monitor(monitor.name, tostring(index)))
        assert(zl.set_workspace_persistent(tostring(index), true))
    end
    local current = tonumber(monitor.active_workspace.name)
    local keep = current and current >= first and current <= last
    assert(zl.workspace_on_monitor(monitor.name, tostring(keep and current or first)))
end

function module.setup(options)
    first, count = options.first, options.count
    zl.on("config_reloaded", function()
        for index = 0, zl.monitor_count() - 1 do map(zl.monitor_info(index)) end
    end)
    zl.on("output_added", map)
end

function module.go(index)
    return function() return zl.workspace(tostring(first + index - 1)) end
end

return module
