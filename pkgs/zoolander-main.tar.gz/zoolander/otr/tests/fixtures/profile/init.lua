-- Profile-shaped config for otr/tests/e2e_hotreload_config_test.otr: a require()'d module plus
-- the settings a real desktop profile makes. The test asserts these exact
-- values, so change both together.

local workspaces = require("workspaces")
workspaces.setup({ first = 11, count = 5 })

zl.set_layout("dwindle", 0.6, 1)
zl.set_dwindle({
    preserve_split = true,
    smart_split = false,
    smart_resizing = true,
    force_split = 0,
    split_width_multiplier = 1.0,
})
zl.set_keyboard({ repeat_rate = 50, repeat_delay = 300, numlock = true })
zl.set_pointer({ left_handed = false, accel_profile = "flat", follow_mouse = 2 })
zl.set_presentation({ allow_tearing = true, immediate_fullscreen = true, vrr = 2, direct_scanout = true, hdr = "auto" })
zl.output_rule({ output = "DP-3", width = 3840, height = 2160, refresh = 240, x = 0, y = 0, scale = 2 })
zl.output_rule({ output = "DP-2", width = 2560, height = 1440, refresh = 240, x = 1920, y = 0, scale = 1 })
zl.set_window_style({
    gaps_in = 3,
    gaps_out = 6,
    border_size = 2,
    active_border = "#dbab96ff",
    active_border_end = "#dbab96ff",
    active_border_angle = 0,
    inactive_border = "#201e1eff",
    inactive_border_end = "#201e1eff",
    inactive_border_angle = 0,
    rounding = 20,
    rounding_power = 4,
    active_opacity = 0.98,
    inactive_opacity = 0.95,
    fullscreen_opacity = 1.0,
    shadow = {
        enabled = true,
        range = 35,
        sharp = 0,
        render_power = 4,
        offset_x = 0,
        offset_y = 12,
        scale = 1.05,
        color = "#00000073",
        color_inactive = "#00000073",
    },
})
zl.set_env("XDG_CURRENT_DESKTOP", "Zoolander")

assert(zl.add_window_rule("app_id", "^(gamescope)$", false, false, false, true))
assert(zl.add_window_rule("app_id", "^(steam_app_.*)$", false, false, false, false, true))
assert(zl.add_window_rule("app_id", "^(.*\\.exe)$", false, false, false, false, false, "game"))

zl.bind(zl.MOD_LOGO, zl.KEY_LEFT, workspaces.go(2))
zl.bind(zl.MOD_LOGO + zl.MOD_SHIFT, zl.KEY_UP, workspaces.go(4))
