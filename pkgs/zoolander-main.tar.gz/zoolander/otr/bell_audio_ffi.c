#include "bell_audio_ffi.h"

const struct spa_pod *zoolander_spa_stereo_f32_format(void *storage, size_t size, uint32_t rate)
{
    struct spa_pod_builder builder = SPA_POD_BUILDER_INIT(storage, size);
    struct spa_audio_info_raw info = {
        .format = SPA_AUDIO_FORMAT_F32,
        .rate = rate,
        .channels = 2,
        .position = { SPA_AUDIO_CHANNEL_FL, SPA_AUDIO_CHANNEL_FR },
    };
    return spa_format_audio_raw_build(&builder, SPA_PARAM_EnumFormat, &info);
}
