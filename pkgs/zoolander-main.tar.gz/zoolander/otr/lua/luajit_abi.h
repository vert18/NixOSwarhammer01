#ifndef ZOOLANDER_LUAJIT_ABI_H
#define ZOOLANDER_LUAJIT_ABI_H
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
#include "zlua_protected.h"
#endif
