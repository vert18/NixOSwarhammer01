#include "zlua_protected.h"
#include <lauxlib.h>
#include <lualib.h>
#include <limits.h>

/* A private negative registry key cannot collide with luaL_ref's positive keys. */
#define DISPATCH_KEY (-0x5a4c5541)

enum operation {
    PUSH_HANDLER, PUSH_CLOSURE, PUSH_STRING, PUSH_TOKEN, PUSH_NIL, PUSH_INTEGER,
    PUSH_NUMBER, PUSH_BOOLEAN, PUSH_VALUE, CREATE_TABLE, GET_FIELD, SET_FIELD, RAW_GET,
    RAW_SET, NEXT, REF, UNREF, TO_STRING, CALL, LOAD_BUFFER, RAISE, OPEN_LIBS
};

struct operation_args {
    enum operation operation;
    lua_CFunction function;
    const char *text;
    const char *string;
    size_t length;
    lua_Integer integer;
    lua_Number number;
    uintptr_t token;
    int a, b, result, status;
    lua_State *state;
    int depth;
};

/* Only Lua-operation arguments live here, never an application/root pointer.
 * Native pcall returns on every Lua error, so nested calls restore this pointer. */
static _Thread_local struct operation_args *pending;

int zlua_failure(int status) {
    return status > 0 ? -status : status;
}

static int handler_gate(lua_State *L) {
    lua_CFunction *handler = lua_touserdata(L, lua_upvalueindex(1));
    int result = (*handler)(L);
    if (result >= 0)
        return result;
    /* The Otr handler, its mutable context loan, and its owned cleanup are gone. */
    if (result == ZLUA_ERRSTACK)
        return luaL_error(L, "protected Lua operation could not reserve stack space");
    if (result == ZLUA_NOT_READY)
        return luaL_error(L, "protected Lua bridge was not initialized");
    return lua_error(L);
}

static int frame_depth(lua_State *L) {
    lua_Debug frame;
    int depth = 0;
    while (lua_getstack(L, depth, &frame))
        ++depth;
    return depth;
}

static int dispatch(lua_State *L) {
    struct operation_args *op = pending;
    /* Call hooks run before this body and must not redirect its pending work. */
    if (!op || op->state != L || frame_depth(L) != op->depth)
        return luaL_error(L, "protected Lua dispatcher called outside an operation");
    pending = NULL;
    switch (op->operation) {
    case PUSH_HANDLER: {
        lua_CFunction *handler = lua_newuserdata(L, sizeof(*handler));
        *handler = op->function;
        lua_pushcclosure(L, handler_gate, 1);
        return 1;
    }
    case PUSH_CLOSURE:
        lua_pushcclosure(L, op->function, op->a);
        return 1;
    case PUSH_STRING:
        lua_pushlstring(L, op->text, op->length);
        return 1;
    case PUSH_TOKEN:
        lua_pushlightuserdata(L, (void *)op->token);
        return 1;
    case PUSH_NIL:
        lua_pushnil(L);
        return 1;
    case PUSH_INTEGER:
        lua_pushinteger(L, op->integer);
        return 1;
    case PUSH_NUMBER:
        lua_pushnumber(L, op->number);
        return 1;
    case PUSH_BOOLEAN:
        lua_pushboolean(L, op->a);
        return 1;
    case PUSH_VALUE:
        lua_pushvalue(L, 1);
        return 1;
    case CREATE_TABLE:
        lua_createtable(L, op->a, op->b);
        return 1;
    case GET_FIELD:
        lua_getfield(L, 1, op->text);
        return 1;
    case SET_FIELD:
        lua_setfield(L, 1, op->text);
        return 0;
    case RAW_GET:
        lua_rawgeti(L, 1, op->a);
        return 1;
    case RAW_SET:
        lua_rawseti(L, 1, op->a);
        return 0;
    case NEXT:
        op->result = lua_next(L, 1);
        return op->result ? 2 : 0;
    case REF:
        op->result = luaL_ref(L, 1);
        return 0;
    case UNREF:
        luaL_unref(L, 1, op->a);
        return 0;
    case TO_STRING:
        op->string = lua_tolstring(L, 1, &op->length);
        lua_pushvalue(L, 1);
        return 1;
    case CALL:
        lua_call(L, op->a, op->b);
        return lua_gettop(L);
    case LOAD_BUFFER:
        op->status = luaL_loadbufferx(L, op->text, op->length, op->string, "t");
        if (op->status)
            return lua_error(L);
        return 1;
    case RAISE:
        lua_pushlstring(L, op->text, op->length);
        return lua_error(L);
    case OPEN_LIBS:
        luaL_openlibs(L);
        return 0;
    }
    return 0;
}

static int prepare(lua_State *L) {
    lua_pushcclosure(L, dispatch, 0);
    lua_rawseti(L, LUA_REGISTRYINDEX, DISPATCH_KEY);
    return 0;
}

int zlua_prepare(lua_State *L) {
    if (!lua_checkstack(L, LUA_MINSTACK))
        return ZLUA_ERRSTACK;
    /* Unlike pushcclosure followed by pcall, cpcall protects creation of the
     * bootstrap closure and LuaJIT's lightuserdata interning as well. */
    return lua_cpcall(L, prepare, NULL);
}

static int absolute_index(lua_State *L, int index) {
    return index > 0 || index <= LUA_REGISTRYINDEX ? index : lua_gettop(L) + index + 1;
}

static int invoke(lua_State *L, struct operation_args *op, int object, int tail, int consume) {
    int top = lua_gettop(L);
    int object_index = object ? absolute_index(L, object) : 0;
    int status, i;
    struct operation_args *outer;
    /* LuaJIT checkstack catches its own growth failure. The remaining outer
     * operations only read/copy slots within this reserved space. */
    if (!lua_checkstack(L, tail + LUA_MINSTACK))
        return ZLUA_ERRSTACK;
    lua_rawgeti(L, LUA_REGISTRYINDEX, DISPATCH_KEY);
    if (lua_tocfunction(L, -1) != dispatch) {
        lua_pop(L, 1);
        return ZLUA_NOT_READY;
    }
    if (object)
        lua_pushvalue(L, object_index);
    for (i = top - tail + 1; i <= top; ++i)
        lua_pushvalue(L, i);
    op->state = L;
    op->depth = frame_depth(L) + 1;
    outer = pending;
    pending = op;
    status = lua_pcall(L, tail + (object != 0), LUA_MULTRET, 0);
    pending = outer;
    if (status)
        return status == LUA_ERRMEM ? status : (op->status ? op->status : status);
    /* Commit consumption only on success. remove and shrinking settop neither
     * allocate nor invoke Lua; error paths leave original inputs plus the error. */
    for (i = 0; i < consume; ++i)
        lua_remove(L, top - consume + 1);
    return 0;
}

int zlua_pushhandler(lua_State *L, lua_CFunction handler) {
    struct operation_args op = { .operation = PUSH_HANDLER, .function = handler };
    return invoke(L, &op, 0, 0, 0);
}

int zlua_pushcclosure(lua_State *L, lua_CFunction function, int upvalues) {
    struct operation_args op = { .operation = PUSH_CLOSURE, .function = function, .a = upvalues };
    return invoke(L, &op, 0, upvalues, upvalues);
}

int zlua_pushlstring(lua_State *L, const char *bytes, size_t length) {
    struct operation_args op = { .operation = PUSH_STRING, .text = bytes, .length = length };
    return invoke(L, &op, 0, 0, 0);
}

int zlua_pushlightuserdata(lua_State *L, uintptr_t token) {
    struct operation_args op = { .operation = PUSH_TOKEN, .token = token };
    return invoke(L, &op, 0, 0, 0);
}

int zlua_pushnil(lua_State *L) {
    struct operation_args op = { .operation = PUSH_NIL };
    return invoke(L, &op, 0, 0, 0);
}

int zlua_pushinteger(lua_State *L, lua_Integer value) {
    struct operation_args op = { .operation = PUSH_INTEGER, .integer = value };
    return invoke(L, &op, 0, 0, 0);
}

int zlua_pushnumber(lua_State *L, lua_Number value) {
    struct operation_args op = { .operation = PUSH_NUMBER, .number = value };
    return invoke(L, &op, 0, 0, 0);
}

int zlua_pushboolean(lua_State *L, int value) {
    struct operation_args op = { .operation = PUSH_BOOLEAN, .a = value };
    return invoke(L, &op, 0, 0, 0);
}

int zlua_pushvalue(lua_State *L, int index) {
    struct operation_args op = { .operation = PUSH_VALUE };
    return invoke(L, &op, index, 0, 0);
}

int zlua_createtable(lua_State *L, int array, int record) {
    struct operation_args op = { .operation = CREATE_TABLE, .a = array, .b = record };
    return invoke(L, &op, 0, 0, 0);
}

int zlua_getfield(lua_State *L, int index, const char *key) {
    struct operation_args op = { .operation = GET_FIELD, .text = key };
    return invoke(L, &op, index, 0, 0);
}

int zlua_setfield(lua_State *L, int index, const char *key) {
    struct operation_args op = { .operation = SET_FIELD, .text = key };
    return invoke(L, &op, index, 1, 1);
}

int zlua_rawgeti(lua_State *L, int index, int key) {
    struct operation_args op = { .operation = RAW_GET, .a = key };
    return invoke(L, &op, index, 0, 0);
}

int zlua_rawseti(lua_State *L, int index, int key) {
    struct operation_args op = { .operation = RAW_SET, .a = key };
    return invoke(L, &op, index, 1, 1);
}

int zlua_next(lua_State *L, int index, int *more) {
    struct operation_args op = { .operation = NEXT };
    int status = invoke(L, &op, index, 1, 1);
    if (!status)
        *more = op.result;
    return status;
}

int zlua_ref(lua_State *L, int index, int *reference) {
    struct operation_args op = { .operation = REF };
    int status = invoke(L, &op, index, 1, 1);
    if (!status)
        *reference = op.result;
    return status;
}

int zlua_unref(lua_State *L, int index, int reference) {
    struct operation_args op = { .operation = UNREF, .a = reference };
    return invoke(L, &op, index, 0, 0);
}

int zlua_tolstring(lua_State *L, int index, const char **bytes, size_t *length) {
    int slot = absolute_index(L, index);
    struct operation_args op = { .operation = TO_STRING };
    int status = invoke(L, &op, index, 0, 0);
    if (!status) {
        if (op.string)
            lua_replace(L, slot);
        else
            lua_pop(L, 1);
        *bytes = op.string;
        *length = op.length;
    }
    return status;
}

int zlua_settop(lua_State *L, int index) {
    int top = lua_gettop(L);
    if (index > top && (index == INT_MAX || !lua_checkstack(L, index - top + 1)))
        return ZLUA_ERRSTACK;
    lua_settop(L, index);
    return 0;
}

int zlua_call(lua_State *L, int arguments, int results) {
    struct operation_args op = { .operation = CALL, .a = arguments, .b = results };
    return invoke(L, &op, 0, arguments + 1, arguments + 1);
}

int zlua_loadbuffer(lua_State *L, const char *bytes, size_t length, const char *name) {
    struct operation_args op = { .operation = LOAD_BUFFER, .text = bytes, .length = length, .string = name };
    return invoke(L, &op, 0, 0, 0);
}

int zlua_error(lua_State *L, const char *bytes, size_t length) {
    struct operation_args op = { .operation = RAISE, .text = bytes, .length = length };
    return invoke(L, &op, 0, 0, 0);
}

int zlua_openlibs(lua_State *L) {
    struct operation_args op = { .operation = OPEN_LIBS };
    return invoke(L, &op, 0, 0, 0);
}
