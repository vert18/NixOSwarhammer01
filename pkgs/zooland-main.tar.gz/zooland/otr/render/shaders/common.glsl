// The per-quad record every pipeline reads, and the rounded-clip coverage.
// Positions are target pixels with a top-left origin, as gl_FragCoord is.

// One instance of a 4-vertex strip. p0..p3 mean what the kind's shader says.
struct Quad {
    vec4 dst;      // x, y, w, h
    vec4 p0;
    vec4 p1;
    vec4 p2;
    vec4 p3;
    vec4 clip_box; // x, y, w, h
    vec4 misc;     // clip radius, clip power, per-kind extras
    uvec4 idx;     // texture, flags, conversion, TEX_BOX taps
};

// The vertex stage reads the record and hands it on as flat inputs, so a
// fragment loads nothing from memory but its texels: a per-fragment
// storage-buffer read doubled the cost of a full-screen blit on AMD.
#ifdef QUAD_VERTEX
layout(std430, set = 1, binding = 0) readonly buffer Quads { Quad quads[]; };
#define QUAD_IO flat out
#else
#define QUAD_IO flat in
#endif
layout(location = 1) QUAD_IO vec4 vP0;
layout(location = 2) QUAD_IO vec4 vP1;
layout(location = 3) QUAD_IO vec4 vP2;
layout(location = 4) QUAD_IO vec4 vP3;
layout(location = 5) QUAD_IO vec4 vClipBox;
layout(location = 6) QUAD_IO vec4 vMisc;
layout(location = 7) QUAD_IO uvec4 vIdx;

#ifndef QUAD_VERTEX
// The drawing quad's record; `dst` is not passed on.
Quad flatQuad() {
    return Quad(vec4(0.0), vP0, vP1, vP2, vP3, vClipBox, vMisc, vIdx);
}
#endif

layout(constant_id = 0) const bool CLIP = false;
layout(constant_id = 1) const bool CONVERT = false;

float superellipseNorm(vec2 q, float power) {
    power = clamp(power, 2.0, 10.0);
    if (power == 2.0) return length(q);
    if (power == 4.0) { vec2 q2 = q * q; return sqrt(sqrt(dot(q2, q2))); }
    return pow(pow(q.x, power) + pow(q.y, power), 1.0 / power);
}

// Signed distance from `pos` to the outline of a box with superellipse
// corners, negative inside; rounded_box.otr on the CPU.
float roundedBoxDistance(vec2 pos, vec4 box, float radius, float power) {
    vec2 halfSize = box.zw * 0.5;
    float cornerRadius = clamp(radius, 0.0, min(halfSize.x, halfSize.y));
    vec2 q = abs(pos - (box.xy + halfSize)) - (halfSize - vec2(cornerRadius));
    return superellipseNorm(max(q, vec2(0.0)), power) + min(max(q.x, q.y), 0.0) - cornerRadius;
}

// Antialiased coverage of the quad's rounded clip at `pos`; 0 outside it.
float clipCoverage(Quad q, vec2 pos) {
    vec2 clipHalf = q.clip_box.zw * 0.5;
    vec2 clipEdge = abs(pos - (q.clip_box.xy + clipHalf));
    if (any(greaterThan(clipEdge, clipHalf))) return 0.0;
    float clipRadius = min(max(q.misc.x, 0.0), min(clipHalf.x, clipHalf.y));
    if (clipRadius > 0.0) {
        vec2 c = max(clipEdge - (clipHalf - vec2(clipRadius)), vec2(0.0)) / clipRadius;
        if (c.x > 0.0 && c.y > 0.0) return clamp((1.0 - superellipseNorm(c, q.misc.y)) * clipRadius + 0.5, 0.0, 1.0);
    }
    return 1.0;
}
