#version 460
// One quad per instance: a 4-vertex strip over `dst`, with the texture
// coordinate an affine map of the offset into it.
#define QUAD_VERTEX
#include "common.glsl"

layout(push_constant) uniform Push {
    vec2 ndc_scale; // 2 / target size
} push;

layout(location = 0) out vec2 vUV;

void main() {
    Quad q = quads[gl_InstanceIndex];
    // Strip order: top-left, bottom-left, top-right, bottom-right.
    vec2 offset = vec2(gl_VertexIndex >> 1, gl_VertexIndex & 1) * q.dst.zw;
    gl_Position = vec4((q.dst.xy + offset) * push.ndc_scale - 1.0, 0.0, 1.0);
    // p0.xy: uv at the dst origin; p1: du/dx, du/dy, dv/dx, dv/dy.
    vUV = q.p0.xy + vec2(dot(q.p1.xy, offset), dot(q.p1.zw, offset));
    vP0 = q.p0;
    vP1 = q.p1;
    vP2 = q.p2;
    vP3 = q.p3;
    vClipBox = q.clip_box;
    vMisc = q.misc;
    vIdx = q.idx;
}
