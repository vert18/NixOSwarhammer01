#version 460
// p0, p1: premultiplied start and end colours; p2: gradient space box;
// p3.xy: direction. With BORDER, the ring of width p3.z inside the clip.
#include "common.glsl"
#include "color.glsl"

layout(constant_id = 2) const bool BORDER = false;

layout(location = 0) out vec4 outColor;

vec4 gradientColor(Quad q, vec2 d) {
    vec2 direction = q.p3.xy;
    float directionLength = length(direction);
    direction = directionLength > 0.0 ? direction / directionLength : vec2(1.0, 0.0);
    float extent = max(dot(abs(direction), q.p2.zw * 0.5), 0.5);
    float position = dot(d - (q.p2.xy + q.p2.zw * 0.5), direction) / (2.0 * extent) + 0.5;
    return mix(q.p0, q.p1, clamp(position, 0.0, 1.0));
}

void main() {
    Quad q = flatQuad();
    vec2 d = gl_FragCoord.xy;
    float coverage = 1.0;
    // A border is the clip's ring, so it is always clipped.
    if (CLIP || BORDER) {
        coverage = clipCoverage(q, d);
        if (coverage <= 0.0) discard;
    }
    vec4 c = gradientColor(q, d);
    if (BORDER) {
        vec2 halfSize = q.clip_box.zw * 0.5;
        float width = clamp(q.p3.z, 0.0, min(halfSize.x, halfSize.y));
        vec2 innerHalf = max(halfSize - vec2(width), vec2(0.0));
        vec2 edge = abs(d - (q.clip_box.xy + halfSize));
        float innerCoverage = 0.0;
        if (all(lessThanEqual(edge, innerHalf)) && innerHalf.x > 0.0 && innerHalf.y > 0.0) {
            float radius = min(max(q.misc.x - width, 0.0), min(innerHalf.x, innerHalf.y));
            innerCoverage = 1.0;
            if (radius > 0.0) {
                vec2 r = max(edge - (innerHalf - vec2(radius)), vec2(0.0)) / radius;
                if (r.x > 0.0 && r.y > 0.0) innerCoverage = clamp((1.0 - superellipseNorm(r, q.misc.y)) * radius + 0.5, 0.0, 1.0);
            }
        }
        if (innerCoverage >= 1.0) discard;
        c *= 1.0 - innerCoverage;
    }
    if (CONVERT) c = convertColor(c, q.idx.z);
    outColor = c * coverage;
}
