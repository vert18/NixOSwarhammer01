#version 460
// p0.z: alpha multiplier; idx.x: bindless image; idx.y: TEX_* flags.
// Built a second time with YCBCR defined, sampling set 2's combined
// image sampler whose immutable sampler carries the conversion.
#extension GL_EXT_nonuniform_qualifier : require
#include "common.glsl"
#include "color.glsl"

#ifdef YCBCR
layout(set = 2, binding = 0) uniform sampler2D ycbcrImage;
#else
#include "bindless.glsl"
// The draw's one texture, by push constant: uniform across the draw, so
// the descriptor is loaded once per wave up front. Without it the index
// comes from each quad, NonUniform, and AMD wraps every sample in a
// waterfall loop around a descriptor load.
layout(constant_id = 5) const bool UNIFORM_TEXTURE = false;
layout(push_constant) uniform Push {
    vec2 ndc_scale;
    uint texture_index;
    uint sampler_index;
} push;
#endif

const uint TEX_LINEAR = 1u;
// Sampled alpha is 1: the client declared these texels opaque. Formats
// without alpha need no flag: their views swizzle alpha to ONE.
const uint TEX_OPAQUE = 2u;
const uint TEX_STRAIGHT_ALPHA = 4u;
// A large downscale: one linear sample per destination pixel would skip
// most texels and alias, so average a grid of them across its footprint.
const uint TEX_BOX = 8u;

layout(location = 0) in vec2 vUV;
layout(location = 0) out vec4 outColor;

#ifndef YCBCR
// p1 is the texture coordinate's step per destination pixel along x and y.
// Without TEX_BOX one tap at the pixel's centre; with it idx.w holds the
// taps per axis (x | y << 16). Each linear tap averages a 2x2 texel square,
// so taps two texels apart cover the footprint as a box filter. One sample
// site keeps one NonUniform image operand.
vec4 sampleQuad(Quad q, uint flags) {
    uint taps = (flags & TEX_BOX) != 0u ? q.idx.w : 0x10001u;
    int nx = int(taps & 0xffffu);
    int ny = int(taps >> 16);
    vec2 ax = vec2(q.p1.x, q.p1.z);
    vec2 ay = vec2(q.p1.y, q.p1.w);
    vec4 sum = vec4(0.0);
    for (int j = 0; j < ny; j++) {
        for (int i = 0; i < nx; i++) {
            vec2 at = vec2((float(i) + 0.5) / float(nx) - 0.5, (float(j) + 0.5) / float(ny) - 0.5);
            vec2 uv = vUV + ax * at.x + ay * at.y;
            // One draw batches quads of many textures, so the index varies per
            // instance; the combined sampler needs the qualifier as well as its
            // parts, or the sample itself is not marked NonUniform.
            if (UNIFORM_TEXTURE) sum += texture(sampler2D(images[push.texture_index], samplers[push.sampler_index]), uv);
            else sum += texture(nonuniformEXT(sampler2D(images[nonuniformEXT(q.idx.x)], samplers[nonuniformEXT(flags & TEX_LINEAR)])), uv);
        }
    }
    return sum / float(nx * ny);
}
#endif

void main() {
    Quad q = flatQuad();
    float coverage = 1.0;
    if (CLIP) {
        coverage = clipCoverage(q, gl_FragCoord.xy);
        if (coverage <= 0.0) discard;
    }
    uint flags = q.idx.y;
#ifdef YCBCR
    vec4 s = texture(ycbcrImage, vUV);
#else
    vec4 s = sampleQuad(q, flags);
#endif
    if ((flags & TEX_OPAQUE) != 0u) s.a = 1.0;
    if ((flags & TEX_STRAIGHT_ALPHA) != 0u) s.rgb *= s.a;
    vec4 c = s * q.p0.z;
    if (CONVERT) c = convertColor(c, q.idx.z);
    outColor = c * coverage;
}
