// Set 0: both samplers, then every sampled image, indexed by quad or push
// constant.

layout(set = 0, binding = 0) uniform sampler samplers[2]; // nearest, linear
layout(set = 0, binding = 1) uniform texture2D images[];
