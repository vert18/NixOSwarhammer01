#version 460
// p0: premultiplied colour; p1: caster box; p2: cut-out box;
// p3: corner radius, corner power, falloff range, sharpness;
// misc.z: falloff exponent.
#include "common.glsl"
#include "color.glsl"

layout(location = 0) out vec4 outColor;

void main() {
    Quad q = flatQuad();
    vec2 d = gl_FragCoord.xy;
    float coverage = 1.0;
    if (CLIP) {
        coverage = clipCoverage(q, d);
        if (coverage <= 0.0) discard;
    }
    float distance = max(roundedBoxDistance(d, q.p1, q.p3.x, q.p3.y), 0.0);
    float range = max(q.p3.z, 0.001);
    if (distance >= range || roundedBoxDistance(d, q.p2, q.p3.x, q.p3.y) <= 0.0) discard;
    float soft = pow(1.0 - distance / range, clamp(q.misc.z, 1.0, 8.0));
    float hard = 1.0 - step(range * 0.5, distance);
    vec4 c = q.p0 * mix(soft, hard, clamp(q.p3.w, 0.0, 1.0));
    if (CONVERT) c = convertColor(c, q.idx.z);
    outColor = c * coverage;
}
