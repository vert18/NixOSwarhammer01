#version 460
// p0: premultiplied colour.
#include "common.glsl"
#include "color.glsl"

layout(location = 0) out vec4 outColor;

void main() {
    Quad q = flatQuad();
    float coverage = 1.0;
    if (CLIP) {
        coverage = clipCoverage(q, gl_FragCoord.xy);
        if (coverage <= 0.0) discard;
    }
    vec4 c = q.p0;
    if (CONVERT) c = convertColor(c, q.idx.z);
    outColor = c * coverage;
}
